<?php

namespace App\Http\Controllers;

use App\Models\Competition;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;


class CompetitionController extends Controller
{
    // Show the create competition form
    public function create()
    {
        return view('client.competition.createcompetition'); // Path to your Blade file
    }

    // Store the competition data
    public function store(Request $request)
    {
        $request->validate([
            'main_name' => 'required|string|max:255',
            'sub_name' => 'required|string|max:255',
        ]);

        Competition::create([
            'user_id' => Auth::id(), // ID of the logged-in user
            'main_name' => $request->main_name,
            'sub_name' => $request->sub_name,
        ]);

        return redirect()->route('competition.list')->with('success', 'Competition created successfully!');
    }

    public function index()
    {
        $competitions = Competition::where('user_id', Auth::id())->get(); // Fetch competitions for logged-in user
        return view('client.competition.competitionlist', compact('competitions'));
    }

    // Show edit form for a competition
    public function setSession(Request $request)
    {
        $request->validate([
            'competition_id' => 'required|exists:competitions,id',
        ]);

        // Store the competition ID in the session
        Session::put('competition_id', $request->competition_id);

        return redirect()->route('competition.edit');
    }

    // Edit competition using session ID
    public function edit()
    {
        $competitionId = Session::get('competition_id');

        if (!$competitionId) {
            return redirect()->route('competition.list')->with('error', 'No competition selected for editing.');
        }

        $competition = Competition::findOrFail($competitionId);

        return view('client.competition.editcompetition', compact('competition'));
    }

    // Update competition
    public function update(Request $request)
    {
        $competitionId = Session::get('competition_id');

        if (!$competitionId) {
            return redirect()->route('competition.list')->with('error', 'No competition selected for updating.');
        }

        $request->validate([
            'main_name' => 'required|string|max:255',
            'sub_name' => 'required|string|max:255',
        ]);

        $competition = Competition::findOrFail($competitionId);

        $competition->update([
            'main_name' => $request->main_name,
            'sub_name' => $request->sub_name,
        ]);

        // Clear the session after updating
        Session::forget('competition_id');

        return redirect()->route('competition.list')->with('success', 'Competition updated successfully!');
    }


    // Delete a competition
    public function destroy($id)
    {
        $competition = Competition::findOrFail($id);
        $competition->delete();

        return redirect()->route('competition.list')->with('success', 'Competition deleted successfully!');
    }
}
