<?php

namespace App\Http\Controllers;

use App\Models\Judge;
// use App\Models\Competition;
use App\Models\Competition;
use Illuminate\Http\Request;
use App\Models\PointCategory;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;

class JudgeController extends Controller
{
    /**
     * Display a listing of the judges.
     */
    public function index()
    {
        // $judges = Judge::with(['competition', 'pointCategories'])->get();
        $judges = Judge::all();
        return view('client.judge.list', compact('judges'));
    }

    /**
     * Show the form for creating a new judge.
     */
    public function create()
    {
        // Fetch point categories for the logged-in user
        $pointCategories = PointCategory::where('user_id', auth()->id())->get();

        // Fetch all competitions and pass them to the view
        $competitions = Competition::all();

        return view('client.judge.create', compact('competitions', 'pointCategories'));
    }


    /**
     * Store a newly created judge in storage.
     */
    public function store(Request $request)
    {
        try {
            // Hash the password before storing
            $request->merge(['password' => Hash::make($request->password)]);

            // Convert the point_category_id to an array (if it's not already)
            $pointCategoryIds = $request->input('point_category_id', []);

            // Create the judge
            $judge = Judge::create([
                'full_name' => $request->input('full_name'),
                'id_card_number' => $request->input('id_card_number'),
                'address' => $request->input('address'),
                'island_city' => $request->input('island_city'),
                'work_office' => $request->input('work_office'),
                'phone_number' => $request->input('phone_number'),
                'competition_id' => $request->input('competition_id'),
                'point_category_id' => json_encode($pointCategoryIds),  // Store as JSON
                'bell_option' => $request->input('bell_option'),
                'email' => $request->input('email'),
                'password' => $request->input('password'),
            ]);

            // Redirect to judge list with success message
            return redirect()->route('judges.index')->with('success', 'Judge created successfully!');
        } catch (\Exception $e) {
            // Log the error
            \Log::error('Error creating judge: ' . $e->getMessage());

            // Redirect back with error message
            return redirect()->back()->with('error', 'Failed to create judge. Please try again.');
        }
    }
    public function update(Request $request, $id)
    {
        try {
            $judge = Judge::findOrFail($id);

            // Check if password is being updated
            if ($request->filled('password')) {
                // Hash the new password
                $request->merge(['password' => Hash::make($request->password)]);
            } else {
                // Remove password from request to prevent overwriting
                $request->request->remove('password');
            }

            // Convert the point_category_id to an array (if it's not already)
            $pointCategoryIds = $request->input('point_category_id', []);

            // Update judge details
            $judge->update([
                'full_name' => $request->input('full_name'),
                'id_card_number' => $request->input('id_card_number'),
                'address' => $request->input('address'),
                'island_city' => $request->input('island_city'),
                'work_office' => $request->input('work_office'),
                'phone_number' => $request->input('phone_number'),
                'competition_id' => $request->input('competition_id'),
                'point_category_id' => json_encode($pointCategoryIds),  // Store as JSON
                'bell_option' => $request->input('bell_option'),
                'email' => $request->input('email'),
                'password' => $request->input('password'),
            ]);

            // Redirect to judge list with success message
            return redirect()->route('judges.index')->with('success', 'Judge updated successfully!');
        } catch (\Exception $e) {
            // Log the error
            \Log::error('Error updating judge: ' . $e->getMessage());

            // Redirect back with error message
            return redirect()->back()->with('error', 'Failed to update judge. Please try again.');
        }
    }


    /**
     * Remove the specified judge from storage.
     */
    public function destroy($id)
    {
        try {
            $judge = Judge::findOrFail($id);

            // Delete the judge
            $judge->delete();

            // Redirect to judge list with success message
            return redirect()->route('judges.index')->with('success', 'Judge deleted successfully!');
        } catch (\Exception $e) {
            \Log::error('Error deleting judge: ' . $e->getMessage());
            return redirect()->route('judges.index')->with('error', 'Failed to delete judge. Please try again.');
        }
    }

    /**
     * Show the form for editing the specified judge.
     */
    public function edit($id)
    {
        $judge = Judge::findOrFail($id);
        return view('client.judge.edit', compact('judge'));
    }



}
