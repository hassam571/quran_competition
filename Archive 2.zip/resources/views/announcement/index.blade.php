<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Competition Template</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    body {
      font-family: Arial, sans-serif;
    }

    .header {
      background-color: #36a79b;
      color: white;
      text-align: center;
      padding: 20px;
      border-radius: .8rem;
    }

    .content {
      border: 1px solid #36a79b;
      border-top: none;
      padding: 20px;
      border-radius: 0 0 10px 10px;
      margin-top: 1rem;
      box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
      border-radius: .8rem;
    }

    .content .label {
      font-weight: bold;
    }

    .content .value {
      color: #36a79b;
      font-weight: bold;
    }

    .row {
      margin-bottom: 10px;
    }
  </style>
    <style>


        .sponsored-header {
      background-color: #36a79b;
      color: white;
      text-align: center;
      padding: 15px;
      font-size: 20px;
      border-radius: 1rem;

    }

    .sponsored-content {
        margin-top: 1rem;

        box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
      border: 1px solid #36a79b;
      border-top: none;
      border-radius: 1rem;
      padding: 20px;
      background-color: white;
    }

    .slider-container {
      display: flex;
      gap: 15px;
      overflow-x: hidden;
      scroll-snap-type: x mandatory;
      padding: 10px 0;
    }
    .slider-container img {
  flex: 0 0 calc(25% - 15px); /* Show 4 images at a time */
  max-width: calc(25% - 15px); /* Responsive width */
  max-height: 150px; /* Adjust the maximum height */
  height: auto; /* Maintain aspect ratio */
  object-fit: cover; /* Crop images if needed */
  border-radius: 8px; /* Rounded corners */
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  scroll-snap-align: center; /* Center snapping */
  box-shadow: rgba(0, 0, 0, 0.15) 0px 2px 8px;

}


    .pagination {
      display: flex;
      justify-content: center;
      gap: 1.5rem;
      margin-top: 1rem;
    }

    .pagination span {
      width: 3rem;
      height: 1.5rem;
      background-color: #666;
      border-radius: 1rem;
      display: inline-block;
      cursor: pointer;
    }

    .pagination span.active {
      background-color: #36a79b;
    }

        @media (max-width: 576px) {
          .slider-container img {
            max-width: 100px;
          }
        }
      </style>
  <style>
    .custom-button {
        display: inline-block;
        width: 50px;
        height: 50px;
        border-radius: 12px;
        text-align: center;
        line-height: 50px;
        font-size: 18px;
        font-weight: bold;
        text-decoration: none;
        transition: all 0.3s ease;
    }

    /* Button with white background and green border */
    .custom-button-white {
        background-color: #fff;
        border: 2px solid #18c49d;
        color: #18c49d;
    }

    .custom-button-white:hover {
        background-color: #18c49d;
        color: #fff;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    /* Button with green background */
    .custom-button-green {
        background-color: #18c49d;
        color: #fff;
        border: none;
    }

    .custom-button-green:hover {
        background-color: #14a67d;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }
</style>
</head>
<body>
    <div class="container mt-5">



        @foreach ($competitors as $competitor)
        <div class="header">
            <h2>{{ $competitor->competition_main_name }}</h2>
            <h5>{{ $competitor->competition_sub_name }}</h5>
        </div>
        <div id="bell-announcements" class="mt-4">
          <!-- Notifications will be dynamically inserted here -->
      </div>
        <div class="content">
            <div class="row">
                <div class="col-6 label">Competitor Name:</div>
                <div class="col-6 value">{{ $competitor->full_name }}</div>
            </div>
            <div class="row">
                <div class="col-6 label">Address:</div>
                <div class="col-6 value">{{ $competitor->address }}</div>
            </div>
            <div class="row">
                <div class="col-6 label">Island / City:</div>
                <div class="col-6 value">{{ $competitor->island_city }}</div>
            </div>
            <div class="row">
                <div class="col-6 label">Age Category:</div>
                <div class="col-6 value">{{ $competitor->ageCategory->name ?? 'N/A' }}</div>
            </div>
            <div class="row">
                <div class="col-6 label">Side Category:</div>
                <div class="col-6 value">{{ $competitor->sideCategory->name ?? 'N/A' }}</div>
            </div>
            <div class="row">
                <div class="col-6 label">Read Category:</div>
                <div class="col-6 value">{{ $competitor->readCategory->name ?? 'N/A' }}</div>
            </div>




            @foreach($questions as $question)
            <div class="row">
              <div  id="questions-container">

          </div>
        </div>


    @endforeach











        </div>
        @endforeach
    </div>




    <div class="container mt-5">
        <div class="sponsored-header">
            Sponsored By
        </div>
        <div class="sponsored-content">
            <div id="sponsorSlider" class="slider-container">
                @foreach ($sponsors as $sponsor)
                    <img src="{{ asset($sponsor->logo) }}" alt="{{ $sponsor->name }}">
                @endforeach
            </div>
            <div class="pagination" id="paginationContainer"></div>
        </div>
    </div>



    <div class="container mt-5">
        <div class="d-flex gap-3 justify-content-end">
            <!-- Button 1 -->
            <a href="{{ route('announcement.index') }}" class="custom-button custom-button-green">S1</a>

            <!-- Button 2 -->
            <a href="{{ route('announcement.winners') }}" class="custom-button custom-button-white">S2</a>
        </div>
    </div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

























  <script>
    const slider = document.getElementById('sponsorSlider');
    const slides = Array.from(slider.children);
    const paginationContainer = document.getElementById('paginationContainer');
    const itemsPerPage = 4; // Number of images to display at once
    const totalPages = Math.ceil(slides.length / itemsPerPage);
    let currentIndex = 0;

    // Create pagination buttons dynamically
    function createPagination() {
      for (let i = 0; i < totalPages; i++) {
        const dot = document.createElement('span');
        dot.dataset.index = i;
        if (i === 0) dot.classList.add('active');
        paginationContainer.appendChild(dot);
        dot.addEventListener('click', () => {
          currentIndex = i;
          showSlide(i);
        });
      }
    }

    // Show slide based on index
    function showSlide(index) {
      const slideWidth = slides[0].offsetWidth + 15; // Slide width + gap
      slider.scrollTo({
        left: slideWidth * index * itemsPerPage,
        behavior: 'smooth',
      });
      updatePagination(index);
    }

    // Update pagination dots
    function updatePagination(index) {
      const dots = paginationContainer.children;
      for (let i = 0; i < dots.length; i++) {
        dots[i].classList.remove('active');
      }
      dots[index].classList.add('active');
    }

    // Initialize slider and pagination
    createPagination();
    showSlide(currentIndex);
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

<script>
function fetchActiveBells() {
  fetch('{{ route('announcement.bells') }}')
      .then(response => response.json())
      .then(data => {
          const bellContainer = document.getElementById('bell-announcements');
          bellContainer.innerHTML = ''; // Clear previous notifications

          if (data.length === 0) {
              bellContainer.innerHTML = '';
          } else {
              data.forEach(notification => {
                  const div = document.createElement('div');
                  div.className = 'alert alert-info text-center';
                  div.style.marginBottom = '10px';
                  div.innerHTML = `
                      <strong>${notification.competitor_name}</strong> - The bell is ringing for
                      <strong>${notification.competition_name}</strong>!
                  `;
                  bellContainer.appendChild(div);
              });
          }
      })
      .catch(error => console.error('Error fetching bells:', error));
}

// Fetch active bells every 5 seconds
setInterval(fetchActiveBells, 500);

</script>
<script>
  document.addEventListener('DOMContentLoaded', function () {
    const questionContainer = document.getElementById('questions-container');

    // Function to fetch questions from the server
    function fetchQuestions() {
        fetch('{{ route('announcement.fetch-questions') }}')
            .then(response => response.json())
            .then(questions => {
                // Clear existing questions
                questionContainer.innerHTML = '';

                // If no questions are found, show a message
                if (questions.length === 0) {
                    questionContainer.innerHTML = '<p>No questions available currently.</p>';
                    return;
                }

                // Iterate over questions and render them
                questions.forEach(question => {
                    const questionDiv = document.createElement('div');
                    questionDiv.className = 'content';
                    questionDiv.innerHTML = `
                        <div class="row">
                            <div class="col-6 label">Question Title:</div>
                            <div class="col-6 value">${question.question_name}</div>
                        </div>
                        <div class="row">
                            <div class="col-6 label">Hardness:</div>
                            <div class="col-6 value">${question.hardness}%</div>
                        </div>
                    `;
                    questionContainer.appendChild(questionDiv);
                });
            })
            .catch(error => console.error('Error fetching questions:', error));
    }

    // Fetch questions initially and every 3 seconds
    fetchQuestions();
    setInterval(fetchQuestions, 3000);
  });
</script>


</html>
