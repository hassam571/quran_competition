@extends('layouts.app')
@section('content')
<div class="container">
    <div class="header">Create Questions</div>
    <div class="button-group">
        <a href="{{ route('questions.create') }}" class="btn btn-outline-success active-button">
            Create Questions
        </a>
        <a href="{{ route('questions.list') }}" class="btn btn-outline-success">Question List</a>
    </div>
    {{-- <div class="form-container"> --}}
        @if ($errors->any())
            <div class="alert alert-danger alert-custom animate__animated animate__fadeInDown" role="alert">
                <ul class="mb-0">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
















        <form id="manualForm" action="{{ route('questions.store') }}" method="POST" class="d-block">
            @csrf
            <div class="form-group mb-3">
                <label for="competition_id" class="form-label">Competition</label>
                <select class="form-control" id="competition_id" name="competition_id" required>
                    <option value="">Select Competition</option>
                    @foreach($competitions as $competition)
                        <option value="{{ $competition->id }}" {{ old('competition_id') == $competition->id ? 'selected' : '' }}>
                            {{ $competition->main_name }}
                        </option>
                    @endforeach
                </select>

            </div>

            <div class="form-group">
                <label for="question_name">Question Name</label>
                <input type="text" class="form-control" id="question_name" name="question_name" placeholder="Enter Question Name" required />
            </div>

            <div class="form-group mb-3">
                <label for="age_category_id" class="form-label">Age Category</label>
                <select class="form-control" id="age_category_id" name="age_category_id" required>
                    <option value="">Select Age Category</option>
                    @foreach($ageCategories as $ageCategory)
                        <option value="{{ $ageCategory->id }}" {{ old('age_category_id') == $ageCategory->id ? 'selected' : '' }}>
                            {{ $ageCategory->name }}
                        </option>
                    @endforeach
                                        <option value="1">Default</option>


                </select>
            </div>

            <div class="form-group mb-3">
                <label for="side_category_id" class="form-label">Side Category</label>
                <select class="form-control" id="side_category_id" name="side_category_id" required>
                    <option value="">Select Side Category</option>
                    @foreach($sideCategories as $sideCategory)
                        <option value="{{ $sideCategory->id }}" {{ old('side_category_id') == $sideCategory->id ? 'selected' : '' }}>
                            {{ $sideCategory->name }}
                        </option>
                    @endforeach
                                        <option value="1">Default</option>


                </select>
            </div>

            <div class="form-group mb-3">
                <label for="read_category_id" class="form-label">Read Category</label>
                <select class="form-control" id="read_category_id" name="read_category_id" required>
                    <option value="">Select Read Category</option>
                    @foreach($readCategories as $readCategory)
                        <option value="{{ $readCategory->id }}" {{ old('read_category_id') == $readCategory->id ? 'selected' : '' }}>
                            {{ $readCategory->name }}
                        </option>
                    @endforeach


                </select>
            </div>
            <div class="form-group">
                <label for="book_number">Book Numbers</label>
                <select class="form-control" id="book_number" name="book_number[]" multiple required>
                   <option value="" selected>Select Book Number</option>
                        <option value="1">آلم (Alif Lam Meem)</option>
                        <option value="2">سَيَقُولُ (Sayakool)</option>
                        <option value="3">تِلْكَ رُسُلُ (Tilka Rusulu)</option>
                        <option value="4">لَن تَنَالُوا (Lan Tana Loo)</option>
                        <option value="5">وَقَالَ الَّذِينَ (Wa Qala Al-Ladhina)</option>
                        <option value="6">يُؤْمِنُونَ بِمَا (Yu'minuna Bima)</option>
                        <option value="7">إِنَّا فَتَحْنَا لَكَ (Inna Fatahna Laka)</option>
                        <option value="8">قُلْ هُوَ اللَّذِي (Qul Huwa Al-Ladhi)</option>
                        <option value="9">لَا يَكُونُ (La Yakunu)</option>
                        <option value="10">فَذُوقُوا بِمَا (Fadhuku Bima)</option>
                        <option value="11">وَفِي رِسَالَتِهِ (Wa Fi Risalati)</option>
                        <option value="12">فَاعْتَبِرُوا يَا أُوْلِي (Fa'tabiru Ya Auli)</option>
                        <option value="13">أَصَابَتْهُمْ (Asabat-hum)</option>
                        <option value="14">وَإِنَّا فَتَحْنَا (Wa Inna Fatahna)</option>
                        <option value="15">تُدْنِي إِلَى (Tudni Ila)</option>
                        <option value="16">يَعْمَلُونَ مَعَكُمْ (Ya'maluna Ma'akum)</option>
                        <option value="17">وَلَا تَحْزَنُوا (Wa La Tahzanoo)</option>
                        <option value="18">إِنَّكُمْ أَفْضَلُ (Innakum Afzaloo)</option>
                        <option value="19">وَقَدْ تَجَدَّدَ (Wa Qad Tajaddada)</option>
                        <option value="20">وَفِي ذَارِهِمْ (Wa Fi Dharihim)</option>
                        <option value="21">إِذَا سَمِعُوا (Iza Sami'u)</option>
                        <option value="22">وَعِدْنَاهُمْ (Wa 'Idnahum)</option>
                        <option value="23">وَالَّذِينَ يَجْحَدُونَ (Waladhina Yajhaduna)</option>
                        <option value="24">وَقَالُوا لِمَن (Wa Qalu Liman)</option>
                        <option value="25">فِي كِتَابِهِمْ (Fi Kitabihim)</option>
                        <option value="26">مُدْنِيَنْ (Mudninan)</option>
                        <option value="27">الَّذِينَ يُؤْمِنُونَ (Alladhina Yu'minuna)</option>
                        <option value="28">وَمَنْ يُؤْمِنْ (Wa Man Yu'min)</option>
                        <option value="29">وَسَمِعَ قَوْمُ (Wa Sami'a Qawmu)</option>
                        <option value="30">أَمَّا يَتَسَاءَلُونَ (Amma Yatasa’aloon)</option>
                </select>
            </div>
            <div class="form-group">
                <label for="surah">Surah Number</label>
                <select class="form-control" id="surah" name="surah" required>
                    <option value="">Select Surah</option>
                </select>
            </div>

            <div class="form-group">
                <label for="from_ayat_number">From Ayat Number</label>
                <input type="number" class="form-control" id="from_ayat_number" name="from_ayat_number" required min="1" placeholder="Enter From Ayat Number">
            </div>

            <div class="form-group">
                <label for="to_ayat_number">To Ayat Number</label>
                <input type="number" class="form-control" id="to_ayat_number" name="to_ayat_number" required min="1" placeholder="Enter To Ayat Number">
            </div>


            <div class="form-group">
                <label for="hardness">Hardness of this Question (%)</label>
                <input type="number" class="form-control" id="hardness" name="hardness" placeholder="Hardness of this Question %" min="0" max="100" required />
            </div>

            <button type="submit" class="btn btn-save">Save</button>
        </form>



<script>
document.addEventListener("DOMContentLoaded", function () {
    const bookDropdown = document.getElementById("book_number");
    const surahDropdown = document.getElementById("surah");

    bookDropdown.addEventListener("change", function () {
        const selectedJuz = Array.from(this.selectedOptions).map(option => option.value).join(',');

        // Clear existing Surah options
        surahDropdown.innerHTML = '<option value="">Select Surah</option>';

        if (selectedJuz) {
            // Fetch Surahs for the selected Juz numbers
            fetch(`/get-surahs?juz_no=${selectedJuz}`)
                .then(response => response.json())
                .then(surahs => {
                    // Populate the Surah dropdown
                    surahs.forEach(surah => {
                        const option = document.createElement("option");
                        option.value = surah.surah_no;
                        option.textContent = `${surah.surah_no} - ${surah.surah_name_ar} (${surah.surah_name_roman})`;
                        surahDropdown.appendChild(option);
                    });
                })
                .catch(error => console.error('Error fetching Surahs:', error));
        }
    });
});

// document.addEventListener("DOMContentLoaded", function () {
//     const bookDropdown = document.getElementById("book_number");
//     const surahDropdown = document.getElementById("surah");

//     bookDropdown.addEventListener("change", function () {
//         const selectedJuz = this.value;

//         // Clear existing Surah options
//         surahDropdown.innerHTML = '<option value="">Select Surah</option>';

//         if (selectedJuz) {
//             // Fetch Surahs for the selected Juz
//             fetch(`/get-surahs?juz_no=${selectedJuz}`)
//                 .then(response => response.json())
//                 .then(surahs => {
//                     // Populate the Surah dropdown
//                     surahs.forEach(surah => {
//                         const option = document.createElement("option");
//                         option.value = surah.surah_no;
//                         option.textContent = `${surah.surah_no} - ${surah.surah_name_ar} (${surah.surah_name_roman})`;
//                         surahDropdown.appendChild(option);
//                     });
//                 })
//                 .catch(error => console.error('Error fetching Surahs:', error));
//         }
//     });
// });

</script>















        <hr>









        <h3 class="mt-5">Bulk Upload Questions</h3>

        <form id="bulkForm" action="{{ route('questions.bulkUpload') }}" method="POST" enctype="multipart/form-data" class="form-container mt-4">
            @csrf
            <div class="form-group mb-3">
                <label for="bulkFile" class="form-label">Upload CSV File</label>
                <input type="file" class="form-control" id="bulkFile" name="file" required />
            </div>
            <button type="submit" class="btn btn-save">Upload</button>
        </form>
</div>

<script>

</script>
@endsection
