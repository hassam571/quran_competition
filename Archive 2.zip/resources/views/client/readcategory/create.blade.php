<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create Read Category</title>
  <link rel="stylesheet" href="css/CreateReadCategory.css">
  <style>
    /* Reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    /* Body Styling */
    body {
      font-family: 'Arial', sans-serif;
      background-color: #f9f9f9;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    /* Header Styling */
    .header {
      background-color: #00bfa6;
      color: white;
      padding: 15px 20px;
      border-radius: 10px;
      margin-bottom: 20px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      width: 100%;
    }

    .header h1 {
      font-size: 18px;
      text-align: center;
    }

    .back-btn {
      background: none;
      border: none;
      color: white;
      font-size: 18px;
      cursor: pointer;
      position: absolute;
      left: 20px;
      top: 15px;
    }

    /* Container */
    .container {
      flex-grow: 1;
      width: 100%;
      max-width: 1200px;
      margin: 0 auto;
      padding: 10px;
      text-align: center;
    }

    /* Tabs Styling */
    .tabs {
      display: block;
      text-align: center;
      margin-bottom: 20px;
    }

    .tab-btn {
      font-size: 14px;
      padding: 10px 15px;
      border-radius: 20px;
      border: 2px solid #00bfa6;
      background-color: white;
      color: #00bfa6;
      cursor: pointer;
      transition: all 0.3s ease-in-out;
      display: inline-block;
    }

    .tab-btn.active {
      background-color: #00bfa6;
      color: white;
    }

    .tab-btn:hover {
      background-color: #008f79;
      color: white;
    }

    /* Form Container */
    .form-container {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      padding: 20px;
      margin-bottom: 30px;
      text-align: left;
    }

    .read-category-form {
      margin-top: 10px;
    }

    .read-category-form input {
      width: 100%;
      padding: 12px;
      font-size: 14px;
      border: 1px solid #ddd;
      border-radius: 10px;
      outline: none;
      transition: border-color 0.3s ease-in-out;
      margin-bottom: 15px;
    }

    .read-category-form input:focus {
      border-color: #00bfa6;
    }

    .read-category-form .save-btn {
      display: block;
      width: 100%;
      background-color: #00bfa6;
      color: white;
      padding: 12px;
      font-size: 16px;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      transition: background-color 0.3s ease-in-out;
    }

    .read-category-form .save-btn:hover {
      background-color: #008f79;
    }

    /* Footer */
    .footer {
      background-color: #00bfa6;
      text-align: center;
      border: 2px solid #fff;
      border-radius: 10px;
      padding: 20px 15px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      margin-top: auto;
      width: 100%;
    }

    .footer-content {
      font-size: 14px;
      color: #fff;
      line-height: 1.8;
    }

    /* Responsive Design for Footer */
    @media (min-width: 768px) {
      .footer {
        padding: 25px 20px;
      }

      .footer-content {
        font-size: 16px;
      }
    }
  </style>
</head>
<body>

  <!-- Header -->
  <header class="header">
    <button class="back-btn" onclick="window.history.back()"><i class="fas fa-arrow-left"></i></button>
    <h1>Create Read Category</h1>
  </header>

  <!-- Container for the main content -->
  <div class="container">
    <!-- Tabs -->
    <div class="tabs">
      <button class="tab-btn active">Create Read Category</button>
      <a href="{{ route('readcategory.list') }}" class="tab-btn">Read Category List</a>
    </div>

    <!-- Form Section -->
    <div class="form-container">
      @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
      @endif

      <form class="read-category-form" method="POST" action="{{ route('readcategory.store') }}">
        @csrf
        <input type="text" name="name" placeholder="Read Category Name" required>
        <button type="submit" class="btn save-btn">Save</button>
      </form>
    </div>
  </div>

  <!-- Footer -->
  <footer class="footer">
    <div class="footer-content">
      <p>Powered by Magey HR</p>
      <p>&copy; 2024 e NEN Development</p>
    </div>
  </footer>
</body>
</html>
