<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Read Category</title>
  <link rel="stylesheet" href="css/ReadCategoryList.css">
</head>
<style>
    /* Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  
  /* Body Styling */
  body {
    font-family: 'Arial', sans-serif;
    background-color: #f9f9f9;
    min-height: 100vh;
    padding: 10px;
    text-align: center;
  }
  
  /* Container */
  .container {
    width: 100%;
    max-width: 400px;
    margin: 0 auto; /* Center the container */
  }
  
  /* Header Styling */
  .header {
    display: block; /* Default display */
    background-color: #00bfa6;
    color: white;
    padding: 15px 20px;
    border-radius: 10px;
    margin-bottom: 20px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  }
  
  .header h1 {
    font-size: 18px;
    text-align: center;
  }
  
  .back-btn {
    float: left; /* Align the back button to the left */
    background: none;
    border: none;
    color: white;
    font-size: 18px;
    cursor: pointer;
  }
  
  /* Tabs Styling */
  .tabs {
    display: block; /* Default display */
    margin-bottom: 20px;
  }
  
  .tab-btn {
    font-size: 14px;
    padding: 10px 15px;
    border-radius: 20px;
    border: 2px solid #00bfa6;
    background-color: white;
    color: #00bfa6;
    cursor: pointer;
    transition: all 0.3s ease-in-out;
    display: inline-block; /* Makes buttons behave like inline elements */
  }
  
  .tab-btn.active {
    background-color: #00bfa6;
    color: white;
  }
  
  .tab-btn:hover {
    background-color: #008f79;
    color: white;
  }
  
  /* List Container */
  .list-container {
    background-color: white;
    border-radius: 10px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    padding: 20px;
    max-height: 400px; /* Set a fixed height for scrolling */
    overflow-y: auto; /* Enable scrolling when content overflows */
  }
  
  .list-title {
    background-color: #00bfa6;
    color: white;
    padding: 10px;
    text-align: center;
    border-radius: 10px;
    margin-bottom: 15px;
    font-size: 16px;
  }
  
  /* Category Cards */
  .category-card {
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 10px;
    margin-bottom: 10px;
    padding: 10px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  }
  
  .card-header p {
    font-size: 14px;
  }
  
  .card-header span {
    color: #00bfa6;
    font-weight: bold;
  }
  
  .card-header i {
    float: right;
    color: #888;
  }
  
  .card-actions {
    margin-top: 10px;
  }
  
  .delete-btn {
    background-color: #e74c3c;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 8px 12px;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
  }
  
  .delete-btn:hover {
    background-color: #c0392b;
  }
  
  .edit-btn {
    background-color: #00bfa6;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 8px 12px;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
  }
  
  .edit-btn:hover {
    background-color: #008f79;
  }
  
/* Footer */
.footer {
    text-align: center; /* Align the content of the footer */
    border: 2px solid #00bfa6;
    border-radius: 10px;
    padding: 20px 15px; /* Add padding for spacing */
    background-color: white;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    margin-top: 30px;
    width: 90%; /* Stretch to match content width */
    max-width: 400px; /* Prevent it from being too wide */
    margin-left: auto; /* Center horizontally */
    margin-right: auto; /* Center horizontally */
  }
  
  .footer-content {
    font-size: 14px;
    color: #00bfa6;
    line-height: 1.8; /* Add spacing between text lines */
  }
  
  /* Responsive Design for Footer */
  @media (min-width: 768px) {
    .footer {
      padding: 25px 20px; /* Increase padding on larger screens */
    }
  
    .footer-content {
      font-size: 16px; /* Slightly larger text for better readability */
    }
  }
  
  
</style>
<body>
  <div class="container">
    <!-- Header -->
    <header class="header">
      <button class="back-btn" onclick="window.history.back()"><i class="fas fa-arrow-left"></i></button>
      <h1>Edit Read Category</h1>
    </header>

    <!-- Form Section -->
    <div class="form-container">
      @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
      @endif

      <form method="POST" action="{{ route('readcategory.update') }}">
        @csrf
        <label for="name">Category Name</label>
        <input type="text" name="name" value="{{ $sideCategory->name }}" required>

        <button type="submit" class="btn save-btn">Save</button>
        <a href="{{ route('readcategory.list') }}" class="btn cancel-btn">Cancel</a>
      </form>
    </div>
  </div>

  <!-- Footer -->
  <footer class="footer">
    <div class="footer-content">
      <p>Powered by Magey HR</p>
      <p>&copy; 2024 e NEN Development</p>
    </div>
  </footer>
</body>
</html>
