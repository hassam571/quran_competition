<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Side Category List</title>
  <link rel="stylesheet" href="css/SideCategoryList.css">
</head>
<style>
  /* Reset */
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  /* Body Styling */
  body {
    font-family: 'Arial', sans-serif;
    background-color: #f9f9f9;
    display: flex;
    flex-direction: column;
    min-height: 100vh;
    padding: 0;
  }

  /* Header Styling */
  .header {
    width: 100%;
    background-color: #00bfa6;
    color: white;
    padding: 15px 20px;
    border-radius: 0 0 10px 10px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    display: flex;
    align-items: center;
  }

  .header h1 {
    flex-grow: 1;
    font-size: 18px;
    text-align: center;
  }

  .back-btn {
    background: none;
    border: none;
    color: white;
    font-size: 18px;
    cursor: pointer;
  }

  /* Main Content */
  .main-content {
    flex-grow: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: flex-start;
    padding: 20px;
  }

  /* Container */
  .container {
    width: 100%;
    max-width: 1200px;
    margin: 0 auto;
  }

  /* Tabs */
  .tabs {
    display: flex;
    justify-content: space-around;
    margin-bottom: 20px;
  }

  .tab-btn {
    font-size: 14px;
    padding: 10px 15px;
    border-radius: 20px;
    border: 2px solid #00bfa6;
    background-color: white;
    color: #00bfa6;
    cursor: pointer;
    transition: all 0.3s ease-in-out;
  }

  .tab-btn.active {
    background-color: #00bfa6;
    color: white;
  }

  .tab-btn:hover {
    background-color: #008f79;
    color: white;
  }

  /* List Container */
  .list-container {
    background-color: white;
    border-radius: 10px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    padding: 20px;
    max-height: 400px; /* Set a fixed height for scrolling */
    overflow-y: auto; /* Enable scrolling when content overflows */
  }

  .list-title {
    background-color: #00bfa6;
    color: white;
    padding: 10px;
    text-align: center;
    border-radius: 10px;
    margin-bottom: 15px;
    font-size: 16px;
  }

  /* Category Cards */
  .category-card {
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 10px;
    margin-bottom: 10px;
    padding: 10px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  }

  .card-header p {
    font-size: 14px;
  }

  .card-header span {
    color: #00bfa6;
    font-weight: bold;
  }

  .card-header i {
    float: right;
    color: #888;
  }

  .card-actions {
    margin-top: 10px;
  }

  .delete-btn {
    background-color: #e74c3c;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 8px 12px;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
  }

  .delete-btn:hover {
    background-color: #c0392b;
  }

  .edit-btn {
    background-color: #00bfa6;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 8px 12px;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
  }

  .edit-btn:hover {
    background-color: #008f79;
  }

  /* Footer Styling */
  .footer {
    width: 100%;
    background-color: #00bfa6;
    border-top: 2px solid #fff;
    padding: 15px;
    box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.1);
    text-align: center;
  }

  .footer-content {
    font-size: 14px;
    color: #fff;
  }

  /* Responsive Design */
  @media (max-width: 768px) {
    .tabs {
      flex-direction: column;
      align-items: center;
    }

    .tab-btn {
      width: 100%;
      margin-bottom: 10px;
    }

    .list-container {
      max-height: 300px;
    }
  }

  @media (max-width: 480px) {
    .header h1 {
      font-size: 16px;
    }

    .back-btn {
      font-size: 16px;
    }

    .tab-btn {
      padding: 8px 12px;
    }

    .footer-content {
      font-size: 12px;
    }
  }
</style>
<body>
  <!-- Header -->
  <header class="header">
    <button class="back-btn" onclick="window.history.back()"><i class="fas fa-arrow-left"></i></button>
    <h1>Side Category List</h1>
  </header>

  <!-- Main Content -->
  <div class="main-content">
    <div class="container">
      <!-- Tabs -->
      <div class="tabs">
        <a href="{{ route('sidecategory.create') }}" class="tab-btn">Create Side Category</a>
        <button class="tab-btn active" onclick="window.location.href='{{ route('sidecategory.list') }}'">Side Category List</button>
      </div>

      <!-- Side Category List -->
      <div class="list-container">
        @if(session('success'))
          <div class="alert alert-success">{{ session('success') }}</div>
        @endif

        <h2 class="list-title">Side Category List</h2>
        @foreach($sideCategories as $sideCategory)
          <div class="category-card">
            <div class="card-header">
              <p>Side Category: <span>{{ $sideCategory->name }}</span></p>
            </div>
            <div class="card-actions">
              <form action="{{ route('sidecategory.setSession') }}" method="POST" style="display:inline-block;">
                @csrf
                <input type="hidden" name="side_category_id" value="{{ $sideCategory->id }}">
                <button type="submit" class="btn edit-btn">Edit</button>
              </form>
              <form action="{{ route('sidecategory.delete') }}" method="POST" style="display:inline-block;">
                @csrf
                <input type="hidden" name="side_category_id" value="{{ $sideCategory->id }}">
                <button type="submit" class="btn delete-btn">Delete</button>
              </form>
            </div>
          </div>
        @endforeach

        @if($sideCategories->isEmpty())
          <p>No side categories found. Click "Create Side Category" to add one.</p>
        @endif
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer class="footer">
    <p>Powered by Magey HR</p>
    <p>&copy; 2024 e NEN Development</p>
  </footer>
</body>
</html>
