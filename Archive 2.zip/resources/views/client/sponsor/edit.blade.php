@extends('layouts.app')

@section('content')
    <div class="container my-5">
        <h2>Edit Sponsor</h2>

        <!-- Button Group -->
        <div class="button-group mb-4">
            <a href="{{ route('sponsors.create') }}" class="btn btn-outline-success">Create Sponsor</a>
            <a href="{{ route('sponsors.index') }}" class="btn btn-outline-success active-button">Sponsor List</a>
        </div>

        <!-- Success Message -->
        @if(session('success'))
            <div class="alert alert-success alert-custom animate__animated animate__fadeInDown" role="alert">
                {{ session('success') }}
            </div>
        @endif

        <!-- Error Message -->
        @if(session('error'))
            <div class="alert alert-danger alert-custom animate__animated animate__fadeInDown" role="alert">
                {{ session('error') }}
            </div>
        @endif

        <!-- The Form -->
        <form action="{{ route('sponsors.update', $sponsor->id) }}" method="POST" enctype="multipart/form-data" class="form-container mt-4">
            @csrf
            @method('PUT')
            <div class="form-group mb-3">
                <input type="text" class="form-control" name="name" placeholder="Sponsor Name" value="{{ old('name', $sponsor->name) }}" required>
            </div>
            <div class="form-group mb-3">
                <label for="competition_id" class="form-label">Competition</label>
                <select class="form-control" id="competition_id" name="competition_id" required>
                    <option value="">Select Competition</option>
                    <option value="1" {{ (old('competition_id', $sponsor->competition_id) == '1') ? 'selected' : '' }}>Default Competition</option>
                    <!-- Add more options as needed -->
                </select>
            </div>
            <div class="form-group mb-3">
                <label for="logo" class="form-label">Sponsor Logo</label>
                @if($sponsor->logo)
                    <p>Current Logo:</p>
                    <img src="{{ asset('storage/' . $sponsor->logo) }}" alt="Sponsor Logo" width="150">
                @endif
                <input type="file" class="form-control" id="logo" name="logo" accept="image/*">
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
@endsection
