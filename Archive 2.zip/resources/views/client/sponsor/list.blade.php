@extends('layouts.app')

@section('content')
    <div class="container my-5">
        <h2>Sponsor List</h2>

        <!-- Button Group -->
        <div class="button-group mb-4">
            <a href="{{ route('sponsors.create') }}" class="btn btn-outline-success">Create Sponsor</a>
            <a href="{{ route('sponsors.index') }}" class="btn btn-outline-success active-button">Sponsor List</a>
        </div>

        <!-- Success Message -->
        @if(session('success'))
            <div class="alert alert-success alert-custom animate__animated animate__fadeInDown" role="alert">
                {{ session('success') }}
            </div>
        @endif

        <!-- Error Message -->
        @if(session('error'))
            <div class="alert alert-danger alert-custom animate__animated animate__fadeInDown" role="alert">
                {{ session('error') }}
            </div>
        @endif

        <!-- Sponsor List -->
        {{-- <div class="list-container"> --}}
            <div class="list-header">Sponsor List</div>
            @forelse($sponsors as $sponsor)
                <div class="list-item mb-3 p-3 border rounded" onclick="toggleDetails(event, this)">
                    <p><strong>Sponsor Name:</strong> {{ $sponsor->name }}</p>
                    <span class="arrow">&#x25BC;</span>
                    <div class="details mt-2" style="display: none;">
                        <p><strong>Competition:</strong> {{ $sponsor->competition_id }}</p>
                        @if($sponsor->logo)
                        <p><strong>Logo:</strong></p>
                        <div class="logo-container">
                            <img src="{{ asset($sponsor->logo) }}" alt="Sponsor Logo">
                        </div>
                    @else
                        <p><strong>Logo:</strong> Not Uploaded</p>
                    @endif

                        <div class="button-group-inline mt-3">
                            <a href="{{ route('sponsors.edit', $sponsor->id) }}" class="btn btn-edit btn-warning">Edit</a>
                            <form action="{{ route('sponsors.destroy', $sponsor->id) }}" method="POST" style="display:inline-block;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-delete btn-danger" onclick="return confirm('Are you sure you want to delete this sponsor?')">Delete</button>
                            </form>
                            <a href="{{ route('sponsors.show', $sponsor->id) }}" class="btn btn-view btn-info">View</a>
                        </div>
                    </div>
                </div>
            @empty
                <p>No sponsors found.</p>
            @endforelse
        {{-- </div> --}}
    </div>

    <!-- JavaScript to toggle details -->
    <script>
        function toggleDetails(event, element) {
            // Prevent toggling when clicking on buttons or links
            if (event.target.tagName.toLowerCase() !== 'button' && event.target.tagName.toLowerCase() !== 'a') {
                const details = element.querySelector('.details');
                const isActive = element.classList.toggle('active');
                details.style.display = isActive ? 'block' : 'none';
            }
        }
    </script>
@endsection
