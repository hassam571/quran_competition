@extends('layouts.app')

@section('content')
    <div class="container my-5">
        <h2>View Sponsor</h2>

        <!-- Button Group -->
        <div class="button-group mb-4">
            <a href="{{ route('sponsors.create') }}" class="btn btn-outline-success">Create Sponsor</a>
            <a href="{{ route('sponsors.index') }}" class="btn btn-outline-success">Sponsor List</a>
        </div>

        <!-- Sponsor Details -->
        <div class="card">
            <div class="card-header">
                {{ $sponsor->name }}
            </div>
            <div class="card-body">
                <p><strong>Competition:</strong> {{ $sponsor->competition->name }}</p>
                @if($sponsor->logo)
                    <p><strong>Logo:</strong></p>
                    <img src="{{ asset('storage/' . $sponsor->logo) }}" alt="Sponsor Logo" width="150">
                @else
                    <p><strong>Logo:</strong> Not Uploaded</p>
                @endif
                <p><strong>Created At:</strong> {{ $sponsor->created_at->format('Y-m-d') }}</p>
                <p><strong>Updated At:</strong> {{ $sponsor->updated_at->format('Y-m-d') }}</p>
            </div>
        </div>
    </div>
@endsection
