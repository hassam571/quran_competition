@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Fetched Quran Verses</h2>

    <!-- Show error if any -->
    @if(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif

    <!-- Display verses -->
    @if(isset($verses) && count($verses) > 0)
        <ul class="list-group">
            @foreach($verses as $verse)
                <li class="list-group-item">
                    <p><strong>Verse {{ $verse->ayah_no_quran }} (Surah {{ $verse->surah_name_en }}):</strong></p>
                    <p><strong>Arabic:</strong> {{ $verse->ayah_ar }}</p>
                    <p><strong>Translation:</strong> {{ $verse->ayah_en }}</p>
                </li>
            @endforeach
        </ul>
    @else
        <p>No verses found for this range.</p>
    @endif
</div>
@endsection
