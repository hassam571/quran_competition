@extends('admin.layout.app')
@section('content')
<div class="container">
    <h2>Dashboard</h2>
    <p>Welcome to the Admin Panel Dashboard!</p>
</div>
@endsection
