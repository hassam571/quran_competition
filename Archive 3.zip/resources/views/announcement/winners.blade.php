<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Competition Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            width: 100%;
        }

        .header {
            background-color: #00bfa5;
            color: white;
            text-align: center;
            padding: 20px;
            border-radius: 0;
            width: 100%;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .header h1 {
            margin: 0;
            font-size: 24px;
        }

        .header h2 {
            margin: 5px 0 0;
            font-size: 18px;
            font-weight: normal;
        }

        .content-area {
            border: none;
            border-radius: 15px;
            width: 90%;
            max-width: 1200px;
            background: white;
            margin: 20px 0;
            padding: 30px;
            overflow-x: auto;
        }

        .row-wrapper {
            display: flex;
            gap: 15px;
            flex-wrap: nowrap;
        }

        .main-block {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-between;
            background-color: white;
            border: 2px solid #d4a026;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            padding: 20px;
            text-align: center;
            min-width: 300px;
            max-width: 300px;

        }

        .main-block .category {
            background-color: #d4a026;
            color: white;
            font-weight: bold;
            font-size: 18px;
            padding: 15px 10px;
            border-radius:1rem ;

            width: 100%;
        }

        .main-block .name {
            margin: 20px 0;
            font-weight: bold;
            font-size: 16px;
            color: black;
        }

        .main-block .footer {
            background-color: #d4a026;
            color: white;
            font-weight: bold;
            font-size: 16px;
            border-radius: 1rem ;
            padding: 10px 0;
            width: 100%;
        }


        .sponsor-title {
            text-align: center;
            background-color: #00bfa5;
            color: white;
            border-radius: 15px;
            width: 90%;
            max-width: 1200px;
            padding: 10px;
            margin-bottom: 5px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            font-size: 16px;
            font-weight: bold;
        }

        .sponsor-list {
            text-align: center;
            background-color: white;
            color: #00bfa5;
            border-radius: 15px;
            width: 90%;
            max-width: 1200px;
            padding: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            font-size: 14px;
        }

        #footer {
            font-size: 12px;
            padding: 10px 20px;
            background-color: #00bfa5;
            color: #fff;
            width: 100%;
            box-shadow: 0 -2px 4px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        #footer img {
            width: 30px;
            height: auto;
            margin-right: 5px;
        }

        #footer .footer-links {
            display: flex;
            gap: 10px;
        }

        #footer .footer-links div {
            background-color: #00bfa5;
            color: white;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 14px;
            font-weight: bold;
        }

        @media (max-width: 768px) {
            .content-area,
            .sponsor-title,
            .sponsor-list {
                width: 95%;
            }

            .main-block {
                font-size: 16px;
            }
        }
    </style>
        <style>
            .custom-button {
                display: inline-block;
                width: 50px;
                height: 50px;
                border-radius: 12px;
                text-align: center;
                line-height: 50px;
                font-size: 18px;
                font-weight: bold;
                text-decoration: none;
                transition: all 0.3s ease;
            }

            /* Button with white background and green border */
            .custom-button-white {
                background-color: #fff;
                border: 2px solid #18c49d;
                color: #18c49d;
            }

            .custom-button-white:hover {
                background-color: #18c49d;
                color: #fff;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            }

            /* Button with green background */
            .custom-button-green {
                background-color: #18c49d;
                color: #fff;
                border: none;
            }

            .custom-button-green:hover {
                background-color: #14a67d;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            }



            .main-block.gold {
    border-color: #d4a026;
}
.main-block.gold .category, .main-block.gold .footer {
    background-color: #d4a026;
    color: #fff;
}

.main-block.silver {
    border-color: #b0b0b0;
}
.main-block.silver .category, .main-block.silver .footer {
    background-color: #b0b0b0;
    color: #000;
}

.main-block.black {
    border-color: #000;
}
.main-block.black .category, .main-block.black .footer {
    background-color: #000;
    color: #fff;
}

.main-block.blue {
    border-color: #007bff;
}
.main-block.blue .category, .main-block.blue .footer {
    background-color: #007bff;
    color: #fff;
}

        </style>
</head>

<body>

    <div class="content-area">
        <div class="row-wrapper" id="winners-container">
            <p>Loading winners...</p>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            function fetchWinners() {
                $.ajax({
                    url: '{{ route('ajax.winners') }}', // AJAX endpoint
                    method: 'GET',
                    success: function(winners) {
                        const container = $('#winners-container');
                        container.empty(); // Clear the existing content

                        if (winners.length === 0) {
                            container.html('<p>No winners announced yet.</p>');
                            return;
                        }

                        // Update main and sub titles
                        $('#main-title').text(winners[0]?.main_name || 'Competition Name');
                        $('#sub-title').text(winners[0]?.sub_name || 'Sub Name');

                        // Render each winner dynamically
                        winners.forEach(winner => {
                            const rankClass = winner.rank == 1 ? 'gold' :
                                (winner.rank == 2 ? 'silver' :
                                    (winner.rank == 3 ? 'black' : 'blue'));

                            const rankText = winner.rank == 1 ? 'st' :
                                (winner.rank == 2 ? 'nd' :
                                    (winner.rank == 3 ? 'rd' : 'th'));

                            const winnerHtml = `
                                <div class="main-block ${rankClass}">
                                    <div class="category">
                                        ${winner.rank}${rankText} Place in
                                        <br>${winner.main_name}
                                        <br>${winner.sub_name}
                                    </div>
                                    <div class="name">
                                        ${winner.full_name}
                                        <br>(${winner.id_card_number})
                                    </div>
                                    <div class="footer">Congratulations</div>
                                </div>
                            `;
                            container.append(winnerHtml);
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error('Error fetching winners:', error);
                        $('#winners-container').html(
                            '<p>Error loading winners. Please try again later.</p>');
                    }
                });
            }

            // Fetch winners every 5 seconds
            fetchWinners();
            setInterval(fetchWinners, 5000);
        });
    </script>

    <div class="sponsor-title">
        Sponsored By
    </div>
    <div class="sponsor-list">
        Vaffushi Pharmacy - Breakdown Cafe’ - Westbeach Restaurant
    </div>

    <div class="container mt-5">
        <div class="d-flex gap-3 justify-content-end">
            <!-- Button 1 -->
            <a href="{{ route('announcement.index') }}" class="custom-button custom-button-white">S1</a>

            <!-- Button 2 -->
            <a href="{{ route('announcement.winners') }}" class="custom-button custom-button-green ">S2</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
