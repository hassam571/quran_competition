<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Age Category</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="css/EditAgeCategory.css">
  <style>
  /* Reset */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* Body Styling */
body {
  font-family: 'Arial', sans-serif;
  background-color: #f9f9f9;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 10px;
  text-align: center;
}

/* Header Styling (Full Width) */
.header {
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #00bfa6;
  color: white;
  padding: 15px 20px;
  border-radius: 10px;
  margin-bottom: 20px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  width: 100%; /* Full width */
  position: fixed;
  top: 0;
  left: 0;
  z-index: 1000;
}

/* Header Title */
.header h1 {
  font-size: 18px;
  text-align: center;
}

/* Back Button */
.back-btn {
  background: none;
  border: none;
  color: white;
  font-size: 18px;
  cursor: pointer;
  position: absolute;
  left: 15px;
  top: 50%;
  transform: translateY(-50%);
}

/* Tabs Styling */
.tabs {
  display: flex;
  justify-content: space-around;
  margin-top: 80px; /* Account for fixed header */
  margin-bottom: 20px;
}

.tab-btn {
  font-size: 14px;
  padding: 10px 15px;
  border-radius: 20px;
  border: 2px solid #00bfa6;
  background-color: white;
  color: #00bfa6;
  cursor: pointer;
  transition: all 0.3s ease-in-out;
}

.tab-btn.active {
  background-color: #00bfa6;
  color: white;
}

.tab-btn:hover {
  background-color: #008f79;
  color: white;
}

/* Content Container */
.container {
  width: 100%; /* Full width for container */
  max-width: 1000px; /* Retain max-width for content area */
  margin: 0 auto;
  flex-grow: 1;
  padding: 20px;
}

/* Form Container */
.form-container {
  background-color: white;
  border-radius: 10px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-bottom: 30px;
}

/* Form Styling */
.age-category-form {
  display: flex;
  flex-direction: column;
  gap: 15px;
  align-items: center;
}

.age-category-form input {
  width: 100%;
  padding: 12px;
  font-size: 14px;
  border: 1px solid #ddd;
  border-radius: 10px;
  outline: none;
  transition: border-color 0.3s ease-in-out;
}

.age-category-form input:focus {
  border-color: #00bfa6;
}

.age-category-form .save-btn {
  background-color: #00bfa6;
  color: white;
  padding: 12px;
  font-size: 16px;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  transition: background-color 0.3s ease-in-out;
}

.age-category-form .save-btn:hover {
  background-color: #008f79;
}

/* Footer Styling (Full Width) */
.footer {
  text-align: center;
  border: 2px solid #fff;
  border-radius: 10px;
  padding: 15px 10px;
  background-color: #00bfa6;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  margin-top: 30px;
  width: 100%; /* Full width */
  position: fixed;
  bottom: 0;
  left: 0;
}

.footer-content {
  font-size: 14px;
  color: #fff;
  line-height: 1.8;
}

/* Responsive Design */
@media (min-width: 768px) {
  .header h1 {
    font-size: 20px;
  }

  .tab-btn {
    font-size: 16px;
    padding: 12px 20px;
  }

  .age-category-form input {
    font-size: 16px;
    padding: 15px;
  }

  .age-category-form .save-btn {
    font-size: 18px;
    padding: 15px;
  }

  .footer-content {
    font-size: 16px;
  }
}
  

  </style>
</head>
<body>
  <!-- Header -->
  <header class="header">
    <button class="back-btn" onclick="window.history.back()"><i class="fas fa-arrow-left"></i></button>
    <h1>Edit Age Category</h1>
  </header>

  <!-- Container -->
  <div class="container">
    <!-- Tabs -->
    <div class="tabs">
      <button class="tab-btn" onclick="window.location.href='{{ route('agecategory.create') }}'">Create Age Category</button>
      <button class="tab-btn active">Edit Age Category</button>
    </div>

    <!-- Form Section -->
    <div class="form-container">
      @if (session('success'))
        <div>{{ session('success') }}</div>
      @endif

      <form method="POST" action="{{ route('agecategory.update') }}" class="age-category-form">
        @csrf
        <label for="name">Age Category</label>
        <input type="text" id="name" name="name" value="{{ $ageCategory->name }}" placeholder="Age Category" required>
        <button type="submit" class="save-btn">Save</button>
      </form>
    </div>
  </div>

  <!-- Footer -->
  <footer class="footer">
    <div class="footer-content">
      <p>Powered by Magey HR</p>
      <p>&copy; 2024 e NEN Development</p>
    </div>
  </footer>
</body>
</html>
