<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Age Category List</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="css/AgeCategoryList.css">
  <style>
    /* Reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    /* Body Styling */
    body {
      font-family: 'Arial', sans-serif;
      background-color: #f9f9f9;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    /* Full width and responsive container */
    .container {
      flex-grow: 1;
      display: flex;
      flex-direction: column;
      width: 100%;
    }

    /* Header Styling */
    .header {
      display: flex;
      align-items: center;
      background-color: #00bfa6;
      color: white;
      padding: 15px 20px;
      border-radius: 10px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      position: sticky;
      top: 0;
      z-index: 100;
      width: 100%;
    }

    .header h1 {
      flex-grow: 1;
      font-size: 18px;
      text-align: center;
    }

    .back-btn {
      background: none;
      border: none;
      color: white;
      font-size: 18px;
      cursor: pointer;
    }

    /* Main Content Styling */
    .main-content {
      flex-grow: 1;
      width: 100%;
      padding: 20px;
      display: flex;
      flex-direction: column;
      align-items: center;
      overflow-y: auto;
    }

    /* Tabs Styling */
    .tabs {
      display: flex;
      justify-content: center;
      width: 100%;
      margin-bottom: 20px;
    }

    .tab-btn {
      font-size: 14px;
      padding: 10px 20px;
      border-radius: 20px;
      border: 2px solid #00bfa6;
      background-color: white;
      color: #00bfa6;
      cursor: pointer;
      transition: all 0.3s ease-in-out;
    }

    .tab-btn.active {
      background-color: #00bfa6;
      color: white;
    }

    .tab-btn:hover {
      background-color: #008f79;
      color: white;
    }

    /* Age Category List Container */
    .list-container {
      width: 100%;
    }

    .category-card {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      margin-bottom: 20px;
      padding: 15px;
      text-align: left;
      width: 100%;
    }

    .card-header {
      font-size: 16px;
      margin-bottom: 10px;
    }

    .card-actions {
      display: flex;
      justify-content: space-between;
      margin-top: 10px;
    }

    .card-actions .btn {
      background-color: #00bfa6;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      transition: background-color 0.3s ease-in-out;
    }

    .card-actions .btn:hover {
      background-color: #008f79;
    }

    /* Danger Button (Delete) */
    .card-actions .btn.delete-btn {
      background-color: #e74c3c;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      transition: background-color 0.3s ease-in-out;
    }

    .card-actions .btn.delete-btn:hover {
      background-color: #c0392b;
    }

    /* Footer Styling */
    .footer {
      width: 100%;
      text-align: center;
      border: 2px solid #fff;
      border-radius: 10px;
      padding: 15px 10px;
      background-color: #00bfa6;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      margin-top: 30px;
      position: relative;
      bottom: 0;
    }

    .footer-content {
      font-size: 14px;
      color: #fff;
      line-height: 1.8;
    }

    /* Responsive Design */
    @media (min-width: 768px) {
      .header h1 {
        font-size: 20px;
      }

      .tab-btn {
        font-size: 16px;
        padding: 12px 20px;
      }

      .category-card {
        padding: 20px;
      }

      .card-actions .btn {
        padding: 12px 24px;
        font-size: 16px;
      }

      .footer-content {
        font-size: 16px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <!-- Header -->
    <header class="header">
      <button class="back-btn" onclick="window.history.back()"><i class="fas fa-arrow-left"></i></button>
      <h1>Age Category List</h1>
    </header>

    <!-- Main Content -->
    <div class="main-content">
      <!-- Tabs -->
      <div class="tabs">
        <button class="tab-btn" onclick="window.location.href='{{ route('agecategory.create') }}'">Create Age Category</button>
        <button class="tab-btn active">Age Category List</button>
      </div>

      <!-- Age Category List -->
      <div class="list-container">
        <h2 class="list-title">Age Category List</h2>
        @foreach ($ageCategories as $ageCategory)
          <div class="category-card">
            <div class="card-header">
              <p>Age Category: <span>{{ $ageCategory->name }}</span></p>
            </div>
            <div class="card-actions">
              <form action="{{ route('agecategory.setSession') }}" method="POST" style="display:inline-block;">
                @csrf
                <input type="hidden" name="age_category_id" value="{{ $ageCategory->id }}">
                <button type="submit" class="btn edit-btn">Edit</button>
              </form>
              <form action="{{ route('agecategory.delete') }}" method="POST" style="display:inline-block;">
                @csrf
                <input type="hidden" name="age_category_id" value="{{ $ageCategory->id }}">
                <button type="submit" class="btn delete-btn">Delete</button>
              </form>
            </div>
          </div>
        @endforeach

        @if ($ageCategories->isEmpty())
          <p>No age categories found. Click "Create Age Category" to add one.</p>
        @endif
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer class="footer">
    <div class="footer-content">
      <p>Powered by Magey HR</p>
      <p>&copy; 2024 e NEN Development</p>
    </div>
  </footer>
</body>
</html>
