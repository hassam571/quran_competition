<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Host List</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Roboto', sans-serif;
        }

        body {
            background-color: #ffffff;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            min-height: 100vh;
            padding: 0;
        }

        .container {
            width: 100%;
            max-width: 1000px;
            background-color: #ffffff;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
            margin-top: 20px;
            margin-bottom: 20px;
        }

        .header {
    background-color: #4dbb94;
    color: #ffffff;
    border-radius: 10px;
    padding: 10px;
    margin-bottom: 20px;
    font-size: 26px;
    font-weight: 500;
    text-align: center;  /* Add this line to center the text */
}


        .button-group {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            justify-content: center;
        }

        .button-group .btn {
            border-radius: 30px;
            font-size: 16px;
            transition: background-color 0.3s, color 0.3s;
            padding: 10px 20px;
        }

        .active-button {
            background-color: #4dbb94;
            color: #ffffff;
        }

        .list-container {
            padding: 15px;
            background-color: #ffffff;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            max-height: 400px;
            overflow-y: auto;
        }

        .list-item {
            background-color: #f7f8fa;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            position: relative;
            cursor: pointer;
        }

        .list-item .details {
            display: none;
            padding-top: 10px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-top: 10px;
            padding: 15px;
        }

        .list-item.active .details {
            display: block;
        }

        .arrow {
            font-size: 18px;
            color: #4dbb94;
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            transition: transform 0.3s;
        }

        .list-item.active .arrow {
            transform: translateY(-50%) rotate(180deg);
        }

        .button-group-inline {
            display: flex;
            gap: 10px;
            margin-top: 10px;
            justify-content: center;
        }

        .btn-complete, .btn-result {
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            padding: 10px 20px;
        }

        .btn-complete {
            background-color: #4dbb94;
            color: #ffffff;
        }

        .btn-result {
            background-color: #007bff;
            color: #ffffff;
        }

        .footer {
            width: 100%;
            text-align: center;
            padding: 10px;
            background-color: #4dbb94;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 30px;
        }

        .footer-content {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
            font-size: 14px;
            color: #fff;
        }

        .footer-logo {
            height: 30px;
            width: 30px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                padding: 10px;
            }
            .header {
                font-size: 22px;
                padding: 15px;
            }
            .button-group {
                flex-direction: column;
                gap: 10px;
            }
            .list-container {
                padding: 10px;
            }
            .list-item {
                padding: 10px;
            }
        }

        @media (max-width: 480px) {
            .header {
                font-size: 20px;
                padding: 10px;
            }
            .button-group .btn {
                font-size: 14px;
                padding: 8px 16px;
            }
            .btn-complete, .btn-result {
                font-size: 12px;
                padding: 8px 15px;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        Host List
    </header>

    <div class="container">
        <div class="button-group">
            <a href="{{ route('host.create') }}" class="btn btn-outline-success">Host a Competition</a>
            <a href="{{ route('competitions.list') }}" class="btn btn-outline-success active-button">Competitions</a>
            <a href="{{ route('host.announce') }}" class="btn btn-outline-success">Announce Winners</a>
        </div>

        <div class="list-container">
            @foreach($hosts as $host)
            <div class="list-item" onclick="this.classList.toggle('active')">
                <p><strong>Competition Main Name:</strong> {{ $host->main_name }}</p>
                <span class="arrow">&#x25BC;</span>
                <div class="details">
                    <p><strong>Competition Sub Name:</strong> {{ $host->sub_name }}</p>
                    <p><strong>Host ID:</strong> {{ $host->host_id }}</p>
                    <p><strong>Password:</strong> **********</p>

                    @if($host->status == 'active')
                        <p><strong>Host Date:</strong> {{ \Carbon\Carbon::parse($host->created_at)->format('d-m-Y') }}</p>
                        <!-- Form for Continue button -->
                        <form action="{{ route('host.continue', $host->id) }}" method="POST" style="display: inline;">
                            @csrf
                            @method('POST')
                            <button type="submit" class="btn btn-complete">Continue</button>
                        </form>
                    @elseif($host->status == 'done')
                        <p><strong>Host Date:</strong> {{ \Carbon\Carbon::parse($host->created_at)->format('d-m-Y') }}</p>
                        <p><strong>Completed Date:</strong> {{ \Carbon\Carbon::parse($host->updated_at)->format('d-m-Y') }}</p>
                    @endif

                    <!-- Always show Result button -->
                    <div class="button-group-inline">
                        <button class="btn btn-result">Result</button>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>

    <footer class="footer">
        <div class="footer-content">
            <img src="nen_logo.png" alt="Logo" class="footer-logo">
            <p>Powered by Magey HR</p>
            <p>Copyright 2024 © NEN Development</p>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
