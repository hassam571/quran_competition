@extends('layouts.app')

@section('content')
    <div class="container my-5">
        <h2>Judge List</h2>

        <!-- Button Group -->
        <div class="button-group mb-4">
            <a href="{{ route('judges.create') }}" class="btn btn-outline-success">Create Judge</a>
            <a href="{{ route('judges.index') }}" class="btn btn-outline-success active-button">Judge List</a>
        </div>

        <!-- Success Message -->
        @if(session('success'))
            <div class="alert alert-success alert-custom animate__animated animate__fadeInDown" role="alert">
                {{ session('success') }}
            </div>
        @endif

        <!-- Error Message -->
        @if(session('error'))
            <div class="alert alert-danger alert-custom animate__animated animate__fadeInDown" role="alert">
                {{ session('error') }}
            </div>
        @endif

        <!-- Judge List -->
        <div class="list-container">
            <div class="list-header">Judge List</div>
            @forelse($judges as $judge)
                <div class="list-item mb-3 p-3 border rounded" onclick="toggleDetails(event, this)">
                    <p><strong>Name of the Judge:</strong> {{ $judge->full_name }}</p>
                    <span class="arrow">&#x25BC;</span>
                    <div class="details mt-2" style="display: none;">
                        <p><strong>ID Card Number:</strong> {{ $judge->id_card_number }}</p>
                        <p><strong>Address:</strong> {{ $judge->address }}</p>
                        <p><strong>Island / City:</strong> {{ $judge->island_city }}</p>
                        <p><strong>Work Office:</strong> {{ $judge->work_office }}</p>
                        <p><strong>Phone Number:</strong> {{ $judge->phone_number }}</p>
                        <p><strong>Competition Name:</strong> {{ $judge->competition_id }}</p>
                        <p><strong>Point Category:</strong> {{ $judge->pointCategory_id ?? 'Default' }}</p>
                        <p><strong>Bell Option:</strong> {{ $judge->bell_option }}</p>
                        <p><strong>Email Address:</strong> {{ $judge->email }}</p>
                        <!-- Password is not displayed for security reasons -->
                        <div class="button-group-inline mt-3">
                            <a href="{{ route('judges.edit', $judge->id) }}" class="btn btn-edit btn-warning">Edit</a>
                            <form action="{{ route('judges.destroy', $judge->id) }}" method="POST" style="display:inline-block;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-delete btn-danger" onclick="return confirm('Are you sure you want to delete this judge?')">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            @empty
                <p>No judges found.</p>
            @endforelse
        </div>
    </div>

    <!-- JavaScript to toggle details -->
    <script>
        function toggleDetails(event, element) {
            // Prevent toggling when clicking on buttons or links
            if (event.target.tagName.toLowerCase() !== 'button' && event.target.tagName.toLowerCase() !== 'a') {
                const details = element.querySelector('.details');
                const isActive = element.classList.toggle('active');
                details.style.display = isActive ? 'block' : 'none';
            }
        }
    </script>
@endsection
