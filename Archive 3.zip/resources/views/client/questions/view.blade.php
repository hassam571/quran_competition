@extends('layouts.app')
@section('content')
<div class="container">
    <div class="header">View Question Details</div>
    <div class="button-group">
        <a href="{{ route('questions.create') }}" class="btn btn-outline-success">Create Questions</a>
        <a href="{{ route('questions.list') }}" class="btn btn-outline-success">Question List</a>
    </div>

    <div class="question-details-card">
        <h3>{{ $question->question_name }}</h3>
        <ul>
            <li><strong>Competition Name:</strong> {{ $question->competition_name }}</li>
            <li><strong>Age Category:</strong> {{ $question->age_category }}</li>
            <li><strong>Side Category:</strong> {{ $question->side_category }}</li>
            <li><strong>Read Category:</strong> {{ $question->read_category }}</li>
            <li><strong>Book Number:</strong> {{ $question->book_number }}</li>
            <li><strong>Surah:</strong> {{ $question->surah_no }} - {{ $question->surah_name_ar }} ({{ $question->surah_name_roman }})</li>
            <li><strong>From Ayat Number:</strong> {{ $question->from_ayat_number }}</li>
            <li><strong>To Ayat Number:</strong> {{ $question->to_ayat_number }}</li>
            <li><strong>Hardness:</strong> {{ $question->hardness }}%</li>
        </ul>
    </div>
</div>
@endsection
