<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create Side Category</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="css/CreateSideCategory.css">
</head>
<style>
    /* Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
  
/* Body Styling */
html, body {
    height: 100%; /* Full height for body */
    width: 100%; /* Full width for body */
}

body {
    font-family: 'Arial', sans-serif;
    background-color: #f9f9f9;
    display: flex; /* Flexbox layout */
    flex-direction: column; /* Stack content vertically */
    justify-content: space-between; /* Push footer to bottom */
    padding: 0; /* Remove padding */
}

/* Full-width container */
.container {
    width: 100%; /* Make container full width */
    max-width: 100%; /* Ensure it takes up full width */
    text-align: center;
    flex-grow: 1; /* Allow content to grow and push the footer down */
    padding: 20px; /* Add some padding */
}

/* Header */
.header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    background-color: #00bfa6;
    color: white;
    padding: 15px 20px;
    border-radius: 10px;
    margin-bottom: 20px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    width: 100%; /* Full width */
}
  
.header h1 {
    font-size: 18px;
    text-align: center;
    margin: 0 auto; /* Center the header title */
    flex-grow: 1; /* Make sure it takes up available space */
}

.back-btn {
    background: none;
    border: none;
    color: white;
    font-size: 18px;
    cursor: pointer;
}

/* Tabs */
.tabs {
    display: flex;
    justify-content: space-around;
    margin-bottom: 20px;
    width: 100%; /* Full width */
}

.tab-btn {
    font-size: 14px;
    padding: 10px 15px;
    border-radius: 20px;
    border: 2px solid #00bfa6;
    background-color: white;
    color: #00bfa6;
    cursor: pointer;
    transition: all 0.3s ease-in-out;
    width: 100%; /* Full width for tabs */
}
  
.tab-btn.active {
    background-color: #00bfa6;
    color: white;
}
  
.tab-btn:hover {
    background-color: #008f79;
    color: white;
}

/* Form Container */
.form-container {
    background-color: white;
    border-radius: 10px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    padding: 20px;
    margin-bottom: 30px;
    border: 2px solid whitesmoke;
    width: 100%; /* Full width */
}

/* Side Category Form */
.side-category-form {
    display: flex;
    flex-direction: column;
    gap: 15px;
    width: 100%; /* Full width */
}
  
.side-category-form input {
    padding: 12px;
    font-size: 14px;
    border: 1px solid #ddd;
    border-radius: 10px;
    outline: none;
    transition: border-color 0.3s ease-in-out;
    width: 100%; /* Full width */
}
  
.side-category-form input:focus {
    border-color: #00bfa6; /* Highlight input on focus */
}
  
.side-category-form .save-btn {
    background-color: #00bfa6;
    color: white;
    padding: 12px;
    font-size: 16px;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
    width: 100%; /* Full width */
}
  
.side-category-form .save-btn:hover {
    background-color: #008f79;
}

/* Full-width Footer */
.footer {
    text-align: center;
    border-top: 2px solid #fff;
    padding: 15px;
    background-color: #00bfa6;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    width: 100%; /* Full width */
    position: relative; /* Keeps footer at bottom */
    bottom: 0;
}
  
.footer-content {
    font-size: 14px;
    color: #fff;
    line-height: 1.8; /* Add spacing between lines */
}
  
/* Responsive Design */
@media (min-width: 768px) {
    .header h1 {
        font-size: 20px;
    }

    .tab-btn {
        font-size: 16px;
        padding: 12px 20px;
    }

    .side-category-form input {
        font-size: 16px;
        padding: 15px;
    }

    .side-category-form .save-btn {
        font-size: 18px;
        padding: 15px;
    }

    .footer-content {
        font-size: 16px;
    }
}
  
</style>
<body>

  <!-- Header outside content -->
  <header class="header">
    <button class="back-btn" onclick="window.history.back()"><i class="fas fa-arrow-left"></i></button>
    <h1>Create Side Category</h1>
  </header>

  <!-- Content Section -->
  <div class="container">
    <!-- Tabs -->
    <div class="tabs">
      <button class="tab-btn active">Create Side Category</button>
      <button class="tab-btn active" onclick="window.location.href='{{ route('sidecategory.list') }}'">Side Category List</button>
    </div>

    <!-- Form Section -->
    <div class="form-container">
      @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
      @endif

      <form class="side-category-form" method="POST" action="{{ route('sidecategory.store') }}">
        @csrf
        <input type="text" name="name" placeholder="Side Category Name" required>
        <button type="submit" class="btn save-btn">Save</button>
      </form>
    </div>
  </div>

  <!-- Full-Width Footer -->
  <footer class="footer">
    <div class="footer-content">
      <p>Powered by Magey HR</p>
      <p>&copy; 2024 e NEN Development</p>
    </div>
  </footer>

</body>
</html>
