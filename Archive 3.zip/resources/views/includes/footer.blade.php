<footer class="footer">
    <div class="footer-content">
        <img src="nen_logo.png" alt="Logo" class="footer-logo" />
        <p>Powered by Magey HR</p>
        <p>Copyright 2024 © NEN Development</p>
    </div>
</footer>
