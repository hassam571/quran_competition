<footer class="text-center py-3">
    <p>&copy; 2023 Admin Panel. All rights reserved.</p>
</footer>
