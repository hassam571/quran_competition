<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="{{ asset('assets/css/color.css') }}">

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Competition List</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="css/CompetitionList.css">
  <style>
    /* Reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    /* Add Flexbox for Body */
    body {
      position: relative;
      display: flex;
      flex-direction: column; /* Stack header, content, and footer */
      min-height: 100vh; /* Ensure body takes the full viewport height */
      font-family: Arial, sans-serif;
      background-color: #f9f9f9;
      padding: 0; /* No padding directly on the body to avoid shifting */
    }

    /* Container to push footer */
    .container {
      flex-grow: 1; /* Allows the container to grow and push the footer down */
      width: 100%; /* Full width */
      max-width: 1200px; /* Maximum width for large screens */
      margin: 20px auto;
      background-color: #fff;
      border: 1px solid #ddd;
      border-radius: 10px;
      box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
      padding: 20px; /* Adjusted padding for better layout */
    }

    /* Button Group */
    .button-group {
      display: flex;
      justify-content: space-around;
      padding: 10px;
      flex-wrap: wrap; /* Allow wrapping on smaller screens */
    }

    .btn {
      font-size: 14px;
      border-radius: 15px;
      padding: 8px 12px;
      border: 1px solid var(--secondary-color);
      background-color: var(--primary-color);
      color: var(--secondary-color);
      cursor: pointer;
      text-align: center;
      width: 100%; /* Full width on small screens */
      max-width: 200px; /* Limit the width of buttons */
      margin: 5px;
    }

    .active-btn {
      background-color: var(--secondary-color);
      color: var(--primary-color);
      border: 1px solid var(--secondary-color);
    }

    /* Competition List */
    .competition-list {
      padding: 15px;
      border: 1px solid #ddd;
      margin: 10px 0;
      border-radius: 10px;
    }

    .list-heading {
      background-color: var(--secondary-color);
      color: var(--primary-color);
      padding: 10px;
      text-align: center;
      border-radius: 10px;
      font-size: 14px;
    }

    .competitions-container {
      margin-top: 20px;
      max-height: 400px;
      overflow-y: auto; /* Enable vertical scrollbar when content overflows */
    }

    /* Competition Cards */
    .competition-card {
      background: white;
      margin: 10px 0;
      border: 1px solid #ddd;
      border-radius: 10px;
      padding: 10px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .competition-main-name p,
    .competition-sub-name p {
      font-size: 13px;
      margin-bottom: 5px;
      cursor: pointer; /* Add cursor pointer to indicate it is clickable */
    }

    .competition-main-name span,
    .competition-sub-name span {
      color: var(--secondary-color);
    }

    .competition-main-name i {
      float: right;
      color: #888;
    }

    /* Hide Sub Name and Buttons by Default */
    .competition-sub-name,
    .card-buttons {
      display: none;
    }

    /* Show Buttons and Sub Name when Active */
    .competition-main-name.active + .competition-sub-name,
    .competition-main-name.active + .competition-sub-name + .card-buttons {
      display: block;
    }

    .card-buttons {
      margin-top: 10px;
      display: flex;
      justify-content: space-between;
      flex-wrap: wrap;
    }

    .delete-btn,
    .edit-btn {
      width: 120px;
      padding: 8px 16px;
    }

    .delete-btn {
      background-color: #e74c3c;
      color: var(--primary-color);
      border: none;
      border-radius: 8px;
    }

    .edit-btn {
      background-color: #2ecc71;
      color: var(--primary-color);
      border: none;
      border-radius: 8px;
    }

  </style>
</head>
<body>

  <header class="header">
    <a class="back-btn" href="{{ route('welcome') }}"><i class="fas fa-home"></i></a>
    <h1>Competition List</h1>
  </header>

  <div class="container1">
    <div class="tabs">
      <button class="tab-btn" onclick="window.location.href='{{ route('competition.create') }}'">Create Competition</button>
      <button class="tab-btn active" onclick="window.location.href='{{ route('competition.list') }}'">Competition List</button>
    </div>
  </div>

  <div class="container">
    <!-- Competition List -->
    <div class="competition-list">
      <h2 class="list-heading">Competitions List</h2>

      <!-- Main Container for all Competitions -->
      <div class="competitions-container">
        @foreach($competitions as $competition)
          <div class="competition-card">
            <!-- Main Name with Dropdown Toggle -->
            <div class="competition-main-name" onclick="toggleDropdown(this)">
              <p>Competition Main Name: <span>{{ $competition->main_name }}</span> 
                <i class="fas fa-chevron-down"></i>
              </p>
            </div>
            <!-- Sub Name, initially hidden -->
            <div class="competition-sub-name">
              <p>Competition Sub Name: <span>{{ $competition->sub_name }}</span></p>
            </div>
            <!-- Buttons -->
            <div class="card-buttons">
              <form action="{{ route('competition.delete', $competition->id) }}" method="POST" style="display:inline-block;">
                @csrf
                <button type="submit" class="btn delete-btn">Delete</button>
              </form>
              <form action="{{ route('competition.setSession') }}" method="POST" style="display:inline-block;">
                @csrf
                <input type="hidden" name="competition_id" value="{{ $competition->id }}">
                <button type="submit" class="btn edit-btn">Edit</button>
              </form>
            </div>
          </div>
        @endforeach

        @if($competitions->isEmpty())
          <p>No competitions found. Click "Create Competition" to add one.</p>
        @endif
      </div>
    </div>
  </div>

  @include('includes.footer')

  <script>
    // JavaScript to toggle dropdown and change arrow direction
    function toggleDropdown(element) {
      var subName = element.nextElementSibling; // Get the sub-name div
      var icon = element.querySelector('i'); // Get the arrow icon
      var buttons = subName.nextElementSibling; // Get the button div

      // Toggle visibility of sub-name and buttons
      if (subName.style.display === "none" || subName.style.display === "") {
        subName.style.display = "block"; // Show the sub-name
        buttons.style.display = "flex"; // Show the buttons
        icon.classList.remove('fa-chevron-down');
        icon.classList.add('fa-chevron-up');
      } else {
        subName.style.display = "none"; // Hide the sub-name
        buttons.style.display = "none"; // Hide the buttons
        icon.classList.remove('fa-chevron-up');
        icon.classList.add('fa-chevron-down');
      }
    }

    // Ensure all dropdowns are closed on page load
    window.onload = function() {
      var allSubNames = document.querySelectorAll('.competition-sub-name');
      var allButtons = document.querySelectorAll('.card-buttons');
      allSubNames.forEach(function(subName) {
        subName.style.display = "none";
      });
      allButtons.forEach(function(button) {
        button.style.display = "none";
      });
    }
  </script>
</body>
</html>
