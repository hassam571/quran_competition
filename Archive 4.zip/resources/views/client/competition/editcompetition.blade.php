


























<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="{{ asset('assets/css/color.css') }}">

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create Competition</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="css/createcompetition.css">
  <style>
    /* Reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    /* Body Styling */
     body {
position:relative;
      font-family: 'Arial', sans-serif;
      background-color: #f9f9f9;
      display: flex;
      flex-direction: column;
      min-height: 100vw; /* Ensure full viewport height */
      padding: 0; /* Remove default padding */
    }

    /* Container */
    .container {
      flex-grow: 1; /* Make the container take up the available space between header and footer */
      width: 100%;
      max-width: 100%; /* Full width for container */
      text-align: center;
      margin: 0 auto; /* Center the container horizontally */

    }



    /* Tabs */
    .tabs {
      display: flex;
      justify-content: space-around;
      margin-bottom: 20px;

    }

    .tab-btn {
      font-size: 14px;
      padding: 10px 15px;
      border-radius: 20px;
      border: 2px solid var(--secondary-color);;
      background-color: var(--primary-color);
      color: var(--secondary-color);;
      cursor: pointer;
      transition: all 0.3s;

    }

    .tab-btn.active {
      background-color: var(--secondary-color);;
      color: var(--primary-color);


    }

    .tab-btn:hover {
      background-color: #008f79;
      color: var(--primary-color);
    }

    /* Form Container */
    .form-container {
      background-color: var(--primary-color);
      border-radius: 10px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      padding: 20px;
      margin-bottom: 30px;
    }

    .competition-form {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }

    .competition-form input {
      padding: 12px;
      font-size: 14px;
      border: 1px solid #ddd;
      border-radius: 10px;
      outline: none;
    }

    .competition-form .save-btn {
      background-color: var(--secondary-color);;
      color: var(--primary-color);
      padding: 12px;
      font-size: 16px;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .competition-form .save-btn:hover {
      background-color: #008f79;
    }



  </style>
</head>
<body>




  <div class="container">
    <!-- Header -->
    <header class="header">
        <a class="back-btn" href="{{ route('welcome') }}"><i class="fas fa-home"></i></a>
        <h1>Create Competition</h1>
      </header>


    <!-- Tabs -->
    <div class="tabs">
      <button class="tab-btn">Create Competition</button>
      <button class="tab-btn" onclick="window.location.href='{{ route('competition.list') }}'">Competition List</button>
    </div>

    <!-- Form Section -->
    <div class="form-container">
        <form class="competition-form" method="POST" action="{{ route('competition.update') }}">
            @csrf
            <input type="text" name="main_name" placeholder="Competition Main Name" required value="{{ $competition->main_name }}">
            <input type="text" name="sub_name" placeholder="Competition Sub Name" required value="{{ $competition->sub_name }}">
            <button type="submit" class="btn save-btn">Save</button>
        </form>

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
    </div>
  </div>

  @include('includes.footer')

</body>
</html>
