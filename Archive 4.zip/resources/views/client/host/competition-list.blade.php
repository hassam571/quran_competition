<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="{{ asset('assets/css/color.css') }}">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Host List</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Roboto', sans-serif;
        }


        .button-group {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            justify-content: center;
        }

        .button-group .btn {
            border-radius: 30px;
            font-size: 16px;
            transition: background-color 0.3s, color 0.3s;
            padding: 10px 20px;
        }

        .active-button {
            background-color: var(--secondary-color);
            color: #ffffff;
        }

        .list-container {
            padding: 15px;
            background-color: #ffffff;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            max-height: 400px;
            overflow-y: auto;
        }

        .list-item {
            background-color: #f7f8fa;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            position: relative;
            cursor: pointer;
        }

        .list-item .details {
            display: none;
            padding-top: 10px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-top: 10px;
            padding: 15px;
        }

        .list-item.active .details {
            display: block;
        }

        .arrow {
            font-size: 18px;
            color: var(--secondary-color);
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            transition: transform 0.3s;
        }

        .list-item.active .arrow {
            transform: translateY(-50%) rotate(180deg);
        }

        .button-group-inline {
            display: flex;
            gap: 10px;
            margin-top: 10px;
            justify-content: center;
        }

        .btn-complete, .btn-result {
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            padding: 10px 20px;
        }

        .btn-complete {
            background-color: var(--secondary-color);
            color: #ffffff;
        }

        .btn-result {
            background-color: #007bff;
            color: #ffffff;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                padding: 10px;
            }
            .header {
                font-size: 22px;
                padding: 15px;
            }
            .button-group {
                flex-direction: column;
                gap: 10px;
            }
            .list-container {
                padding: 10px;
            }
            .list-item {
                padding: 10px;
            }
        }

        @media (max-width: 480px) {
            .header {
                font-size: 20px;
                padding: 10px;
            }
            .button-group .btn {
                font-size: 14px;
                padding: 8px 16px;
            }
            .btn-complete, .btn-result {
                font-size: 12px;
                padding: 8px 15px;
            }
        }
        .container1{margin-top: 2rem !important;}



.button-group1 {
display: block;
gap: 10px;
margin-bottom: 20px;
}

.button-group1 .btn {
float: left;

border-radius: 30px;
font-size: 16px;
transition: background-color 0.3s, color 0.3s;
width: 45% !important;
padding: .3rem 0;
margin: .5rem .2rem;
}


    </style>
</head>
<body>

    <header class="header">
        <a class="back-btn" href="{{ route('welcome') }}"><i class="fas fa-home"></i></a>
        Competition List
    </header>
    <div class="button-group1">
        <a href="{{ route('host.create') }}" class="btn btn-outline-success ">Host Competition</a>
        <a href="{{ route('competitions.list') }}" class="btn btn-outline-success active-button">Competitions</a>
        <a href="{{ route('host.announce') }}" class="btn btn-outline-success">Announce Winners</a>
    </div>
    <div class="container">



        <div class="list-container">
            @foreach($hosts as $host)
            <div class="list-item" onclick="this.classList.toggle('active')">
                <p><strong>Competition Main Name:</strong> {{ $host->main_name }}</p>
                <span class="arrow">&#x25BC;</span>
                <div class="details">
                    <p><strong>Competition Sub Name:</strong> {{ $host->sub_name }}</p>
                    <p><strong>Host ID:</strong> {{ $host->host_id }}</p>
                    <p><strong>Password:</strong> **********</p>

                    @if($host->status == 'active')
                        <p><strong>Host Date:</strong> {{ \Carbon\Carbon::parse($host->created_at)->format('d-m-Y') }}</p>
                        <!-- Form for Continue button -->
                        <form action="{{ route('host.continue', $host->id) }}" method="POST" style="display: inline;">
                            @csrf
                            @method('POST')
                            <button type="submit" class="btn btn-complete">Continue</button>
                        </form>
                    @elseif($host->status == 'done')
                        <p><strong>Host Date:</strong> {{ \Carbon\Carbon::parse($host->created_at)->format('d-m-Y') }}</p>
                        <p><strong>Completed Date:</strong> {{ \Carbon\Carbon::parse($host->updated_at)->format('d-m-Y') }}</p>
                    @endif

                    <!-- Always show Result button -->
                    <div class="button-group-inline">
                        <button class="btn btn-result">Result</button>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>

    @include('includes.footer')


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
