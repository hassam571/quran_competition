@extends('layouts.app')

@section('content')

<header class="header">
    <a class="back-btn" href="{{ route('welcome') }}"><i class="fas fa-home"></i></a>
    <h1>Judge List</h1>
</header>

<div class="container1">
  <div class="tabs">
    <button class="tab-btn "  onclick="window.location.href='{{ route('judges.create') }}'">Create Judge</button>
    <button class="tab-btn active" onclick="window.location.href='{{ route('judges.index') }}'">Judge List</button>
  </div>
</div>

<div class="container my-5">
    <!-- Success Message -->
    @if(session('success'))
        <div class="alert alert-success alert-custom animate__animated animate__fadeInDown" role="alert">
            {{ session('success') }}
        </div>
    @endif

    <!-- Error Message -->
    @if(session('error'))
        <div class="alert alert-danger alert-custom animate__animated animate__fadeInDown" role="alert">
            {{ session('error') }}
        </div>
    @endif

    <!-- Judge List -->
    <div class="list-container">
        <div class="list-header">Judge List</div>
        @forelse($judges as $judge)
        <div class="list-item mb-3 p-3 border rounded" onclick="toggleDetails(event, this)">
            <p><strong>Name of the Judge:</strong> {{ $judge->full_name }} </span> <i class="fas fa-chevron-down"></i></p>
            {{-- <span class="arrow">&#x25BC;</span> <!-- Rotating Arrow --> --}}
            <div class="details mt-2" style="display: none;">
                <p><strong>ID Card Number:</strong> {{ $judge->id_card_number }}</p>
                <p><strong>Address:</strong> {{ $judge->address }}</p>
                <p><strong>Island / City:</strong> {{ $judge->island_city }}</p>
                <p><strong>Work Office:</strong> {{ $judge->work_office }}</p>
                <p><strong>Phone Number:</strong> {{ $judge->phone_number }}</p>
                <p><strong>Competition Name:</strong> {{ $judge->competition_id }}</p>
                <p><strong>Point Category:</strong> {{ $judge->pointCategory_id ?? 'Default' }}</p>
                <p><strong>Bell Option:</strong> {{ $judge->bell_option }}</p>
                <p><strong>Email Address:</strong> {{ $judge->email }}</p>
                <div class="button-group-inline mt-3">
                    <a href="{{ route('judges.edit', $judge->id) }}" class="btn btn-edit btn-warning">Edit</a>
                    <form action="{{ route('judges.destroy', $judge->id) }}" method="POST" style="display:inline-block;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-delete btn-danger" onclick="return confirm('Are you sure you want to delete this judge?')">Delete</button>
                    </form>
                </div>
            </div>
        </div>
        @empty
            <p>No judges found.</p>
        @endforelse
    </div>
</div>

<!-- JavaScript to toggle details -->
<script>
    function toggleDropdown(element) {
    var actions = element.nextElementSibling; // Get the .card-actions div
    var icon = element.querySelector('i'); // Get the icon for the arrow

    // Toggle visibility of buttons
    if (actions.style.display === "none" || actions.style.display === "") {
        actions.style.display = "flex"; // Show the buttons
        element.classList.add('open'); // Add class to rotate the arrow
    } else {
        actions.style.display = "none"; // Hide the buttons
        element.classList.remove('open'); // Remove class to rotate the arrow back
    }
}
    function toggleDetails(event, element) {
        // Prevent toggling when clicking on buttons or links
        if (event.target.tagName.toLowerCase() !== 'button' && event.target.tagName.toLowerCase() !== 'a') {
            const details = element.querySelector('.details');
            const isActive = element.classList.toggle('active');
            details.style.display = isActive ? 'block' : 'none';
        }
    }
</script>

@endsection
<style>
/* General Header Styles */
.card-header i {
  color: #888;
  cursor: pointer;
  position: absolute; /* Position the arrow in the top-right corner */
  right: 10px; /* Distance from the right edge */
  top: 50%; /* Center vertically */
  transform: translateY(-50%); /* Adjust vertical positioning to center the arrow */
  transition: transform 0.3s ease; /* Smooth rotation transition */
}
.card-header.open i {
  transform: translateY(-50%) rotate(180deg); /* Rotate the arrow when dropdown is open */
}
.header {
    background-color: var(--secondary-color);
    color: #ffffff;
    padding: 10px;
    text-align: center;
    font-size: 18px;
    font-weight: 500;
    position: relative;
}

.back-btn {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    background-color: transparent;
    border: none;
    color: #ffffff;
    font-size: 18px;
    cursor: pointer;
    transition: color 0.3s;
}

.back-btn:hover {
    color: #f7f8fa;
}

/* List Item Styling */
.list-item {
    background-color: #fff;
    border-radius: 10px;
    margin-bottom: 15px;
    padding: 15px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    position: relative;
    cursor: pointer;
    transition: all 0.3s ease;
}

.list-item:hover {
    background-color: #f9f9f9;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.list-item p {
    font-size: 14px;
    margin: 10px 0;
}

/* Arrow Styling */
.arrow {
    font-size: 18px;
    color: var(--secondary-color);
    position: absolute;
    right: 15px; /* Fixes the arrow to the right side */
    top: 50%;
    transform: translateY(-50%); /* Vertically center the arrow */
    transition: transform 0.3s ease; /* Smooth rotation */
}

/* Toggle Details - Show when Active */
.details {
    display: none;
    margin-top: 10px;
    padding-top: 10px;
    background-color: #ffffff;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    padding: 15px;
}

/* Details section toggle active class for showing */
.list-item.active .details {
    display: block;
}

/* Rotating the arrow when section is expanded */
.list-item.active .arrow {
    transform: translateY(-50%) rotate(180deg); /* Rotate the arrow when expanded */
}

/* Button Group Styling */
.button-group-inline {
    display: flex;
    gap: 10px;
    justify-content: center;
    margin-top: 15px;
}

.btn-edit {
    background-color: #0efc71;
    color: white;
    color: var(--secondary-color); /* Green color */

    padding: 8px 15px;
    border-radius: 5px;
    font-size: 14px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.btn-delete {
    background-color: #e74c3c;
    color: white;
    padding: 8px 15px;
    border-radius: 5px;
    font-size: 14px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.btn-edit:hover {
    background-color: #27ae60;
}

.btn-delete:hover {
    background-color: #c0392b;
}
/* Edit Button Styling */
.btn-edit {
    background-color: #28a745; /* Green color */
    color: white;
    padding: 8px 15px;
    border-radius: 5px;
    font-size: 14px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.btn-edit:hover {
    background-color: #218838; /* Darker green when hovering */
}


</style>
