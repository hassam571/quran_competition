<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="{{ asset('assets/css/color.css') }}">

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Point Category List</title>
  <link rel="stylesheet" href="css/PointCategoryList.css">
  <style>
    /* Reset */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    /* Body Styling */
    body {
        position: relative;
        font-family: 'Arial', sans-serif;
        background-color: #f9f9f9;
        min-height: 100vw;
        display: flex;
        flex-direction: column;
        padding: 10px;
    }

    /* Main Content Area */
    .content {
        margin-top: 30px;
        flex: 1;
        width: 100%;
        max-width: 1200px;
        margin: 40px auto 50px;
    }

    /* Tabs Styling */
    .tabs {
        display: flex;
        justify-content: center;
        width: 100%;
        margin-bottom: 20px;
    }

    .tab-btn {
        font-size: 14px;
        padding: 10px 20px;
        border-radius: 20px;
        border: 2px solid var(--secondary-color);
        background-color: var(--primary-color);
        color: var(--secondary-color);
        cursor: pointer;
        transition: all 0.3s ease-in-out;
    }

    .tab-btn.active {
        background-color: var(--secondary-color);
        color: var(--primary-color);
    }

    .tab-btn:hover {
        background-color: #008f79;
        color: var(--primary-color);
    }

    /* List Container */
    .list-container {
        background-color: var(--primary-color);
        border-radius: 10px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        padding: 20px;
        max-height: 500px;
        overflow-y: auto;
    }

    .list-title {
        background-color: var(--secondary-color);
        color: var(--primary-color);
        padding: 10px;
        text-align: center;
        border-radius: 10px;
        margin-bottom: 15px;
        font-size: 16px;
    }

    /* Category Cards */
    .category-card {
        background-color: #fff;
        border: 1px solid #ddd;
        border-radius: 10px;
        margin-bottom: 10px;
        padding: 10px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .card-header {
        display: flex;
        justify-content: space-between;
        align-items: left;
        cursor: pointer;
        position: relative;
        width: 100%;
    }

    .card-header p {
        font-size: 14px;
        margin-right: 10px;
        flex-grow: 1;
        text-align: center;
    }

    .card-header span {
        color: var(--secondary-color);
        font-weight: bold;
    }

    .card-header i {
        color: #888;
        cursor: pointer;
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
        transition: transform 0.3s;
    }

    /* Dropdown rotation */
    .card-header.open i {
        transform: translateY(-50%) rotate(180deg);
    }

    /* Action buttons (Edit and Delete) */
    .card-actions {
        display: none;
        margin-top: 10px;
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
    }

    .delete-btn, .edit-btn {
        border-radius: 13px;
        padding: 10px 20px;
        font-size: 14px;
        font-weight: bold;
        text-align: center;
        cursor: pointer;
        transition: all 0.3s ease;
        border: none;
        width: 140px;
    }

    .delete-btn {
        background-color: #e74c3c;
        color: white;
    }

    .edit-btn {
        background-color: #2ecc71;
        color: white;
    }

    .delete-btn:hover {
        background-color: #c0392b;
    }

    .edit-btn:hover {
        background-color: #27ae60;
    }

    /* Details Section */
    .details {
        display: none;
        margin-top: 10px;
        text-align: center;
        
    }

    
    .details p {
    display: block; /* Ensures that each <p> takes full width */
    margin-bottom: 10px; /* Adds spacing between the items */
    font-size: 14px; /* Optional: Adjust font size */
}

.details span {
    font-weight: bold; /* Optional: To make the point values stand out */
    color: var(--secondary-color); /* Optional: Color for the values */
}

    /* Custom Scrollbar */
    .list-container::-webkit-scrollbar {
        width: 12px;
    }

    .list-container::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }

    .list-container::-webkit-scrollbar-thumb {
        background-color: var(--secondary-color);
        border-radius: 10px;
        border: 3px solid #f1f1f1;
    }
  </style>
</head>
<body>

    <!-- Header -->
    <header class="header">
        <a class="back-btn" href="{{ route('welcome') }}"><i class="fas fa-home"></i></a>
        <h1>Point Category List</h1>
    </header>

    <div class="container1">
        <div class="tabs">
            <button class="tab-btn" onclick="window.location.href='{{ route('pointcategory.create') }}'">Create Point Category</button>
            <button class="tab-btn active" onclick="window.location.href='{{ route('pointcategory.list') }}'">Point Category List</button>
        </div>
    </div>

    <!-- Main Content Area -->
    <div class="content">
        <div class="list-container">
            @if(session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif

            <h2 class="list-title">Point Category List</h2>
            @foreach($pointCategories as $pointCategory)
                <div class="category-card">
                    <div class="card-header" onclick="toggleDropdown(this)">
                        <p>Point Category Name: <span>{{ $pointCategory->name }}</span> <i class="fas fa-chevron-down"></i></p>
                    </div>
                    <div class="details">
                        {{-- <p>Total Number of Points:{{ $pointCategory->total_points }}</p> --}}
                        <p>Total Number of Points:<span>{{$pointCategory->total_points  }}</span> </p>
                        {{-- <p>Deduction Amount per Click: {{ $pointCategory->deduction_amount }}</p> --}}
                        <p>Deduction Amount per Click: <span>{{ $pointCategory->deduction_amount  }}</span> </p>
                    </div>
                    <div class="card-actions">
                        <form action="{{ route('pointcategory.setSession') }}" method="POST" style="display:inline-block;">
                            @csrf
                            <input type="hidden" name="point_category_id" value="{{ $pointCategory->id }}">
                            <button type="submit" class="btn edit-btn">Edit</button>
                        </form>
                        <form action="{{ route('pointcategory.delete', $pointCategory->id) }}" method="POST" style="display:inline-block;">
                            @csrf
                            <button type="submit" class="btn delete-btn">Delete</button>
                        </form>
                    </div>
                </div>
            @endforeach

            @if($pointCategories->isEmpty())
                <p>No point categories found. Click "Create Point Category" to add one.</p>
            @endif
        </div>
    </div>

    @include('includes.footer')

    <script>
        // Toggle the dropdown visibility of the Edit/Delete buttons and rotate the arrow
        function toggleDropdown(element) {
            var actions = element.nextElementSibling; // Get the .card-actions div
            var icon = element.querySelector('i'); // Get the icon for the arrow
            var details = element.nextElementSibling.nextElementSibling; // Get the details div

            // Toggle visibility of buttons and details
            if (actions.style.display === "none" || actions.style.display === "") {
                actions.style.display = "flex"; // Show the buttons
                details.style.display = "block"; // Show the details
                element.classList.add('open'); // Add class to rotate the arrow
            } else {
                actions.style.display = "none"; // Hide the buttons
                details.style.display = "none"; // Hide the details
                element.classList.remove('open'); // Remove class to rotate the arrow back
            }
        }

        // Ensure all dropdowns are closed on page load
        window.onload = function() {
            var allActions = document.querySelectorAll('.card-actions');
            var allDetails = document.querySelectorAll('.details');
            allActions.forEach(function(actions) {
                actions.style.display = "none"; // Hide actions by default
            });
            allDetails.forEach(function(details) {
                details.style.display = "none"; // Hide details by default
            });
        }
    </script>
</body>
</html>
