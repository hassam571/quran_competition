<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="{{ asset('assets/css/color.css') }}">

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create Side Category</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="css/CreateSideCategory.css">
</head>
<style>
    /* Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Body Styling */
html,  body {
position:relative;
    height: 100%; /* Full height for body */
    width: 100%; /* Full width for body */
}

 body {
position:relative;
    font-family: 'Arial', sans-serif;
    background-color: #f9f9f9;
    display: flex; /* Flexbox layout */
    flex-direction: column; /* Stack content vertically */
    justify-content: space-between; /* Push footer to bottom */
    padding: 0; /* Remove padding */
}

/* Full-width container */
.container {
    width: 100%; /* Make container full width */
    max-width: 100%; /* Ensure it takes up full width */
    text-align: center;
    flex-grow: 1; /* Allow content to grow and push the footer down */
    padding: 20px; /* Add some padding */
}

/* Header */
.header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    background-color: var(--secondary-color);;
    color: var(--primary-color);
    padding: 15px 20px;
    border-radius: 10px;
    margin-bottom: 20px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    width: 100%; /* Full width */
}

.header h1 {
    font-size: 18px;
    text-align: center;
    margin: 0 auto; /* Center the header title */
    flex-grow: 1; /* Make sure it takes up available space */
}

.back-btn {
    background: none;
    border: none;
    color: var(--primary-color);
    font-size: 18px;
    cursor: pointer;
}



/* Form Container */
.form-container {
    background-color: var(--primary-color);
    border-radius: 10px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    padding: 20px;
    margin-bottom: 30px;
    border: 2px solid whitesmoke;
    width: 100%; /* Full width */
}

/* Side Category Form */
.side-category-form {
    display: flex;
    flex-direction: column;
    gap: 15px;
    width: 100%; /* Full width */
}

.side-category-form input {
    padding: 12px;
    font-size: 14px;
    border: 1px solid #ddd;
    border-radius: 10px;
    outline: none;
    transition: border-color 0.3s ease-in-out;
    width: 100%; /* Full width */
}

.side-category-form input:focus {
    border-color: var(--secondary-color);; /* Highlight input on focus */
}

.side-category-form .save-btn {
    background-color: var(--secondary-color);;
    color: var(--primary-color);
    padding: 12px;
    font-size: 16px;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
    width: 100%; /* Full width */
}

.side-category-form .save-btn:hover {
    background-color: #008f79;
}

</style>
<body>

    <header class="header">
        <a class="back-btn" href="{{ route('welcome') }}"><i class="fas fa-home"></i></a>
        <h1>Create Side Category</h1>
      </header>

      <div class="container1">
  <div class="tabs">
    <button class="tab-btn active" onclick="window.location.href='{{ route('sidecategory.create') }}'">Create Side Category</button>
    <button class="tab-btn" onclick="window.location.href='{{ route('sidecategory.list') }}'">Side Category List</button>
  </div>
      </div>

  <!-- Content Section -->
  <div class="container">


    <!-- Form Section -->
    <div class="form-container">
      @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
      @endif

      <form class="side-category-form" method="POST" action="{{ route('sidecategory.store') }}">
        @csrf
        <input type="text" name="name" placeholder="Side Category Name" required>
        <button type="submit" class="btn save-btn">Save</button>
      </form>
    </div>
  </div>

  @include('includes.footer')


</body>
</html>
