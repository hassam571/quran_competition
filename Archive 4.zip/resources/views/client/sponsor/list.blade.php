@extends('layouts.app')

@section('content')

<header class="header">
    <a class="back-btn" href="{{ route('welcome') }}"><i class="fas fa-home"></i></a>
    <h1>  Sponsor List</h1>
  </header>

  <div class="container1">
<div class="tabs">
<button class="tab-btn "  onclick="window.location.href='{{ route('sponsors.create') }}'">Create Sponsor</button>
<button class="tab-btn active" onclick="window.location.href='{{ route('sponsors.index') }}'">Sponsor List</button>
</div>
  </div>

    <div class="container my-5">


<style>
    .card-header.open i {
  transform: translateY(-50%) rotate(180deg); /* Rotate the arrow when dropdown is open */
}
.card-header i {
  color: #888;
  cursor: pointer;
  position: absolute; /* Position the arrow in the top-right corner */
  right: 10px; /* Distance from the right edge */
  top: 50%; /* Center vertically */
  transform: translateY(-50%); /* Adjust vertical positioning to center the arrow */
  transition: transform 0.3s ease; /* Smooth rotation transition */
}

</style>
        <!-- Sponsor List -->
        {{-- <div class="list-container"> --}}
            <div class="list-header">Sponsor List</div>
            @forelse($sponsors as $sponsor)
                <div class="list-item mb-3 p-3 border rounded" onclick="toggleDetails(event, this)">
                    <p><strong>Sponsor Name:</strong> {{ $sponsor->name }}<i class="fas fa-chevron-down"></i></p>
                   
                    <div class="details mt-2" style="display: none;">
                        <p><strong>Competition:</strong> {{ $sponsor->competition_id }}</p>
                        @if($sponsor->logo)
                        <p><strong>Logo:</strong></p>
                        <div class="logo-container">
                            <img src="{{ asset($sponsor->logo) }}" alt="Sponsor Logo">
                        </div>
                    @else
                        <p><strong>Logo:</strong> Not Uploaded</p>
                    @endif

                        <div class="button-group-inline mt-3">
                            <a href="{{ route('sponsors.edit', $sponsor->id) }}" class="btn btn-edit btn-warning">Edit</a>
                            <form action="{{ route('sponsors.destroy', $sponsor->id) }}" method="POST" style="display:inline-block;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-delete btn-danger" onclick="return confirm('Are you sure you want to delete this sponsor?')">Delete</button>
                            </form>
                            <a href="{{ route('sponsors.show', $sponsor->id) }}" class="btn btn-view btn-info">View</a>
                        </div>
                    </div>
                </div>
            @empty
                <p>No sponsors found.</p>
            @endforelse
        {{-- </div> --}}
    </div>

    <!-- JavaScript to toggle details -->
    <script>
        function toggleDetails(event, element) {
            // Prevent toggling when clicking on buttons or links
            if (event.target.tagName.toLowerCase() !== 'button' && event.target.tagName.toLowerCase() !== 'a') {
                const details = element.querySelector('.details');
                const isActive = element.classList.toggle('active');
                details.style.display = isActive ? 'block' : 'none';
            }
        }
    </script>
@endsection
