<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Competition List</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="css/CompetitionList.css">
  <style>
    /* Reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    /* Add Flexbox for Body */
    body {
      display: flex;
      flex-direction: column; /* Stack header, content, and footer */
      min-height: 100vh; /* Ensure body takes the full viewport height */
      font-family: Arial, sans-serif;
      background-color: #f9f9f9;
      padding: 0; /* No padding directly on the body to avoid shifting */
    }

    /* Header */
    .header {
      position: sticky; /* Stick header to the top */
      top: 0;
      display: flex;
      align-items: center;
      background-color: #00bfa6;
      padding: 10px;
      color: white;
      border-radius: 0px 0px 10px 10px;
      z-index: 10; /* Ensure it stays on top */
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Optional shadow */
    }

    .header h1 {
      flex-grow: 1;
      font-size: 16px;
      text-align: center;
    }

    .back-btn {
      background: none;
      border: none;
      color: white;
      font-size: 18px;
      cursor: pointer;
    }

    /* Container to push footer */
    .container {
      flex-grow: 1; /* Allows the container to grow and push the footer down */
      width: 100%; /* Full width */
      max-width: 1200px; /* Maximum width for large screens */
      margin: 20px auto;
      background-color: #fff;
      border: 1px solid #ddd;
      border-radius: 10px;
      box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
      padding: 20px; /* Adjusted padding for better layout */
    }

    /* Button Group */
    .button-group {
      display: flex;
      justify-content: space-around;
      padding: 10px;
      flex-wrap: wrap; /* Allow wrapping on smaller screens */
    }

    .btn {
      font-size: 14px;
      border-radius: 15px;
      padding: 8px 12px;
      border: 1px solid #00bfa6;
      background-color: white;
      color: #00bfa6;
      cursor: pointer;
      text-align: center;
      width: 100%; /* Full width on small screens */
      max-width: 200px; /* Limit the width of buttons */
      margin: 5px;
    }

    .active-btn {
      background-color: #00bfa6;
      color: white;
      border: 1px solid #00bfa6;
    }

    /* Competition List */
    .competition-list {
      padding: 15px;
      border: 1px solid #ddd;
      margin: 10px 0;
      border-radius: 10px;
    }

    .list-heading {
      background-color: #00bfa6;
      color: white;
      padding: 10px;
      text-align: center;
      border-radius: 10px;
      font-size: 14px;
    }

    .competitions-container {
      margin-top: 20px;
      max-height: 400px;
      overflow-y: auto; /* Enable vertical scrollbar when content overflows */
    }

    /* Competition Cards */
    .competition-card {
      background: white;
      margin: 10px 0;
      border: 1px solid #ddd;
      border-radius: 10px;
      padding: 10px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .competition-main-name p,
    .competition-sub-name p {
      font-size: 13px;
      margin-bottom: 5px;
    }

    .competition-main-name span,
    .competition-sub-name span {
      color: #00bfa6;
    }

    .competition-main-name i {
      float: right;
      color: #888;
    }

    .card-buttons {
      margin-top: 10px;
      display: flex;
      justify-content: space-between;
      flex-wrap: wrap; /* Allow buttons to wrap on small screens */
    }

    .delete-btn,
    .edit-btn {
      width: 120px;
      padding: 8px 16px;
    }

    .delete-btn {
      background-color: #e74c3c;
      color: white;
      border: none;
      border-radius: 8px;
    }

    .edit-btn {
      background-color: #2ecc71;
      color: white;
      border: none;
      border-radius: 8px;
    }

    /* Footer Styling */
    .footer {
      width: 100%;
      text-align: center;
      font-size: 14px;
      background-color: #00bfa6;
      color: white;
      padding: 15px 10px;
      margin-top: 30px;
      box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.1);
      border-radius: 0 0 10px 10px;
    }

    /* Responsive Styles */
    @media (max-width: 768px) {
      .header h1 {
        font-size: 14px; /* Smaller text for smaller screens */
      }

      .btn {
        font-size: 12px; /* Adjust button text size */
        width: 100%;
      }

      .competition-card {
        padding: 15px;
      }

      .card-buttons {
        flex-direction: column;
        align-items: center;
      }

      .delete-btn,
      .edit-btn {
        width: 100%;
        margin-bottom: 10px;
      }

      .footer {
        font-size: 12px; /* Adjust footer text size */
      }
    }
  </style>
</head>
<body>
  <!-- Header -->
  <header class="header">
    <button class="back-btn" onclick="window.history.back()"><i class="fas fa-arrow-left"></i></button>
    <h1>Competition List</h1>
  </header>

  <div class="container">
    <!-- Button Group -->
    <div class="button-group">
      <a href="{{ route('competition.create') }}" class="btn create-btn">Create Competition</a>
      <button class="btn active-btn">Competition List</button>
    </div>

    <!-- Competition List -->
    <div class="competition-list">
      <h2 class="list-heading">Competitions List</h2>

      <!-- Main Container for all Competitions -->
      <div class="competitions-container">
        @foreach($competitions as $competition)
          <div class="competition-card">
            <!-- Sub-container for Main Name -->
            <div class="competition-main-name">
              <p>Competition Main Name: <span>{{ $competition->main_name }}</span> <i class="fas fa-chevron-down"></i></p>
            </div>
            <!-- Sub-container for Sub Name -->
            <div class="competition-sub-name">
              <p>Competition Sub Name: <span>{{ $competition->sub_name }}</span></p>
            </div>
            <!-- Buttons -->
            <div class="card-buttons">
              <form action="{{ route('competition.delete', $competition->id) }}" method="POST" style="display:inline-block;">
                @csrf
                <button type="submit" class="btn delete-btn">Delete</button>
              </form>
              <form action="{{ route('competition.setSession') }}" method="POST" style="display:inline-block;">
                @csrf
                <input type="hidden" name="competition_id" value="{{ $competition->id }}">
                <button type="submit" class="btn edit-btn">Edit</button>
              </form>
            </div>
          </div>
        @endforeach

        @if($competitions->isEmpty())
          <p>No competitions found. Click "Create Competition" to add one.</p>
        @endif
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer class="footer">
    <p>Powered by Magey HR</p>
    <p>&copy; 2024 e NEN Development</p>
  </footer>
</body>
</html>
