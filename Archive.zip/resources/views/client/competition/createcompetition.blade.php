<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create Competition</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="css/createcompetition.css">
  <style>
    /* Reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    /* Body Styling */
    body {
      font-family: 'Arial', sans-serif;
      background-color: #f9f9f9;
      display: flex;
      flex-direction: column;
      min-height: 100vh; /* Ensure full viewport height */
      padding: 0; /* Remove default padding */
    }

    /* Container */
    .container {
      flex-grow: 1; /* Make the container take up the available space between header and footer */
      width: 100%;
      max-width: 100%; /* Full width for container */
      text-align: center;
      margin: 0 auto; /* Center the container horizontally */
    }

    /* Header */
    .header {
      display: flex;
      align-items: center;
      background-color: #00bfa6;
      color: white;
      padding: 15px 20px;
      border-radius: 10px;
      margin-bottom: 20px;
      width: 100%; /* Ensure the header spans the full width */
      box-sizing: border-box; /* Ensure padding doesn't affect the width calculation */
    }

    .header h1 {
      flex-grow: 1;
      font-size: 18px;
      text-align: center;
    }

    .back-btn {
      background: none;
      border: none;
      color: white;
      font-size: 18px;
      cursor: pointer;
    }

    /* Tabs */
    .tabs {
      display: flex;
      justify-content: space-around;
      margin-bottom: 20px;
     
    }

    .tab-btn {
      font-size: 14px;
      padding: 10px 15px;
      border-radius: 20px;
      border: 2px solid #00bfa6;
      background-color: white;
      color: #00bfa6;
      cursor: pointer;
      transition: all 0.3s;
      
    }

    .tab-btn.active {
      background-color: #00bfa6;
      color: white;
      
     
    }

    .tab-btn:hover {
      background-color: #008f79;
      color: white;
    }

    /* Form Container */
    .form-container {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      padding: 20px;
      margin-bottom: 30px;
    }

    .competition-form {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }

    .competition-form input {
      padding: 12px;
      font-size: 14px;
      border: 1px solid #ddd;
      border-radius: 10px;
      outline: none;
    }

    .competition-form .save-btn {
      background-color: #00bfa6;
      color: white;
      padding: 12px;
      font-size: 16px;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .competition-form .save-btn:hover {
      background-color: #008f79;
    }

    /* Footer */
    .footer {
      width: 100%; /* Ensure footer spans the full width of the page */
      padding: 15px 0; /* Padding top and bottom */
      background-color: white;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      position: relative; /* Ensure it's at the bottom */
      text-align: center;
      margin-top: auto; /* Ensure the footer is pushed to the bottom */
      background-color: #00bfa6;
    }

    .footer-content {
      font-size: 14px;
      line-height: 1.8;
      color: #fff;
    }

    @media (min-width: 768px) {
      .footer {
        padding: 20px 0; /* Add more padding for larger screens */
      }

      .footer-content {
        font-size: 16px; /* Slightly larger font on larger screens */
      }
    }

    @media (max-width: 480px) {
      .footer-content {
        font-size: 12px; /* Adjust font size for smaller screens */
      }
    }

  </style>
</head>
<body>
  <div class="container">
    <!-- Header -->
    <header class="header">
      <button class="back-btn"><i class="fas fa-arrow-left"></i></button>
      <h1>Create Competition</h1>
    </header>

    <!-- Tabs -->
    <div class="tabs">
      <button class="tab-btn active">Create Competition</button>
      <button class="tab-btn" onclick="window.location.href='{{ route('competition.list') }}'">Competition List</button>
    </div>

    <!-- Form Section -->
    <div class="form-container">
        <form class="competition-form" method="POST" action="{{ route('competition.store') }}">
            @csrf
            <input type="text" name="main_name" placeholder="Competition Main Name" required>
            <input type="text" name="sub_name" placeholder="Competition Sub Name" required>
            <button type="submit" class="btn save-btn">Save</button>
        </form>

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
    </div>
  </div>

  <!-- Footer -->
  <footer class="footer">
    <div class="footer-content">
      <p>Powered by Magey HR</p>
      <p>&copy; 2024 e NEN Development</p>
    </div>
  </footer>
</body>
</html>
