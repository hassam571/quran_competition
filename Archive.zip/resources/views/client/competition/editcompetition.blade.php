<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Side Category</title>
  <link rel="stylesheet" href="css/SideCategoryList.css">
  <style>
    /* Body Styling */
    body {
      font-family: 'Arial', sans-serif;
      background-color: #f9f9f9;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start; /* Ensure header stays at the top */
      min-height: 100vh;
      padding: 10px;
    }

    /* Container */
    .container {
      width: 100%;
      max-width: 400px;
      text-align: center;
    }
 
    /* Header (Moved Outside of .container for Full Width) */
    .header {
      display: flex;
      align-items: center;
      background-color: #00bfa6;
      color: white;
      padding: 15px 20px;
      border-radius: 10px;
      margin-bottom: 20px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      width: 100%; /* Ensure full width */
    }

    .header h1 {
      flex-grow: 1;
      font-size: 18px;
      text-align: center;
    }

    .back-btn {
      background: none;
      border: none;
      color: white;
      font-size: 18px;
      cursor: pointer;
    }

    /* Form Section */
    .form-container {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      padding: 20px;
      width: 100%;
      max-width: 400px;
    }

    .form-title {
      background-color: #00bfa6;
      color: white;
      padding: 10px;
      text-align: center;
      border-radius: 10px;
      margin-bottom: 20px;
      font-size: 16px;
    }

    label {
      display: block;
      margin: 10px 0 5px;
      font-size: 14px;
      text-align: left;
    }

    input[type="text"] {
      width: 100%;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 5px;
      font-size: 14px;
      margin-bottom: 20px;
    }

    .btn-container {
      display: flex;
      justify-content: space-between;
    }

    .save-btn {
      background-color: #00bfa6;
      color: white;
      border: none;
      border-radius: 8px;
      padding: 10px 20px;
      cursor: pointer;
      font-size: 14px;
      transition: background-color 0.3s ease-in-out;
    }

    .save-btn:hover {
      background-color: #008f79;
    }

    .cancel-btn {
      background-color: #e74c3c;
      color: white;
      border: none;
      border-radius: 8px;
      padding: 10px 20px;
      cursor: pointer;
      font-size: 14px;
      transition: background-color 0.3s ease-in-out;
    }

    .cancel-btn:hover {
      background-color: #c0392b;
    }

    /* Footer */
    .footer {
      text-align: center;
      border: 2px solid #00bfa6;
      border-radius: 10px;
      padding: 15px 10px;
      background-color: #00bfa6;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      margin-top: 30px;
      width: 90%;
      max-width: 400px;
    }

    .footer-content {
      font-size: 14px;
      color: #fff;
    }
  </style>
</head>
<body>
  <!-- Header moved outside of the container for full-width layout -->
  <header class="header">
    <button class="back-btn" onclick="window.history.back()"><i class="fas fa-arrow-left"></i></button>
    <h1>Edit Side Category</h1>
  </header>

  <div class="container">
    <!-- Form Section -->
    <div class="form-container">
      @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
      @endif

      <form method="POST" action="{{ route('sidecategory.update') }}">
        @csrf
        <h2 class="form-title">Edit Side Category</h2>

        <label for="name">Category Name</label>
        <input type="text" name="name" id="name" value="{{ $sideCategory->name }}" required>

        <div class="btn-container">
          <button type="submit" class="save-btn">Save</button>
          <a href="{{ route('sidecategory.list') }}" class="cancel-btn">Cancel</a>
        </div>
      </form>
    </div>
  </div>

  <!-- Footer -->
  <footer class="footer">
    <p>Powered by Magey HR</p>
    <p>&copy; 2024 e NEN Development</p>
  </footer>
</body>
</html>
