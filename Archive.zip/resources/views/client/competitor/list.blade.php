@extends('layouts.app')

@section('content')

    <div class="container my-5">
        <h2>Competitor List</h2>

        <!-- Button Group -->
        <div class="button-group mb-4">
            <a href="{{ route('competitors.create') }}" class="btn btn-outline-success">Create Competitor</a>
            <a href="{{ route('competitors.index') }}" class="btn btn-outline-success active-button">Competitor List</a>
        </div>

        <!-- Success Message -->
        @if(session('success'))
            <div class="alert alert-success alert-custom animate__animated animate__fadeInDown" role="alert">
                {{ session('success') }}
            </div>
        @endif

        <!-- Error Message -->
        @if(session('error'))
            <div class="alert alert-danger alert-custom animate__animated animate__fadeInDown" role="alert">
                {{ session('error') }}
            </div>
        @endif

        <!-- Competitor List -->
        <div class="list-container">
            <div class="list-header">Competitor List</div>
            @forelse($competitors as $competitor)
                <div class="list-item mb-3 p-3 border rounded" onclick="this.classList.toggle('active')">
                    <p><strong>Name:</strong> {{ $competitor->full_name }}                     <span class="arrow" >&#x25BC;</span>
                    </p>
                    <div class="details mt-2" style="display: none;">
                        <p><strong>ID Card Number:</strong> {{ $competitor->id_card_number }}</p>
                        <p><strong>Address:</strong> {{ $competitor->address }}</p>
                        <p><strong>Island / City:</strong> {{ $competitor->island_city }}</p>
                        <p><strong>School:</strong> {{ $competitor->school_name ?? 'N/A' }}</p>
                        <p><strong>Parent:</strong> {{ $competitor->parent_name }}</p>
                        <p><strong>Phone Number:</strong> {{ $competitor->phone_number }}</p>
                        <p><strong>Competition Name:</strong> {{ $competitor->competition_id }}</p>
                        <p><strong>Side Category:</strong> {{ $competitor->sideCategory_id }}</p>
                        <p><strong>Read Category:</strong> {{ $competitor->readCategory_id }}</p>
                        <p><strong>Age Category:</strong> {{ $competitor->ageCategory_id }}</p>
                        <p><strong>Number of Questions:</strong> {{ $competitor->number_of_questions }}</p>
                        <div class="button-group-inline mt-3">
                            <a href="{{ route('competitors.edit', $competitor->id) }}" class="btn btn-edit btn-warning">Edit</a>
                            <form action="{{ route('competitors.destroy', $competitor->id) }}" method="POST" style="display:inline-block;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-delete btn-danger" onclick="return confirm('Are you sure you want to delete this competitor?')">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            @empty
                <p>No competitors found.</p>
            @endforelse
        </div>
    </div>

    <!-- JavaScript to toggle details -->
    <script>
        document.querySelectorAll('.list-item').forEach(item => {
            item.addEventListener('click', function(e) {
                // Prevent toggling when clicking on buttons
                if (e.target.tagName.toLowerCase() !== 'button' && e.target.tagName.toLowerCase() !== 'a') {
                    this.querySelector('.details').style.display = this.classList.contains('active') ? 'block' : 'none';
                }
            });
        });
    </script>

@endsection
