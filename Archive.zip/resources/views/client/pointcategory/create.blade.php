<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Point Category</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Roboto', sans-serif;
        }

        body {
            background-color: #f7f8fa;
            display: flex;
            flex-direction: column;
            height: 100vh;  /* Full viewport height */
            margin: 0;
        }

        .wrapper {
            display: flex;
            flex-direction: column;
            height: 100%;
        }

        header {
            background-color: #4dbb94;  /* Green background */
            color: white;  /* White text color */
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;  /* Centering the heading */
            border-radius: 0 0 15px 15px;  /* Rounded bottom corners */
        }

        .back-button {
            background: none;
            border: none;
            font-size: 24px;
            color: white;
            position: absolute;  /* Positioning it outside the flexbox */
            left: 20px;  /* Aligning it to the left */
        }

        header h1 {
            font-size: 20px;
            font-weight: 500;
        }

        .main-content {
            flex-grow: 1;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        .button-group {
            display: flex;
            margin-bottom: 20px;
        }

        .button-group button {
            flex: 1;
            border-radius: 30px;
            padding: 10px;
            border: 2px solid #4dbb94;
            font-size: 16px;
            cursor: pointer;
        }

        .active-button {
            background-color: #4dbb94;
            color: #ffffff;
        }

        .inactive-button {
            background-color: #ffffff;
            color: #4dbb94;
        }

        .form-container {
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        input {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #e1e4e8;
            border-radius: 5px;
            font-size: 16px;
        }

        .save-btn {
            width: 100%;
            background-color: #4dbb94;
            color: #ffffff;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            cursor: pointer;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        footer {
            background-color: #4dbb94;  /* Green background */
            color: white;
            padding: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            margin-top: auto; /* Push footer to the bottom */
            border-radius: 15px 15px 0 0;  /* Rounded top corners */
        }

        .footer-content {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            font-size: 14px;
        }

        .footer-logo {
            height: 25px;
            width: 25px;
        }

        /* Responsive design */
        @media (max-width: 768px) {
            .button-group {
                flex-direction: column;
            }

            .button-group button {
                width: 100%;
                margin-bottom: 10px;
            }

            header h1 {
                font-size: 18px;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <header class="header">
            <button class="back-button">←</button>
            <h1>Create Point Category</h1>
        </header>
        <div class="main-content">
            <div class="button-group">
                <button class="active-button">Create Point Category</button>
                <button class="inactive-button" onclick="window.location.href='{{ route('pointcategory.list') }}'">Point Category List</button>
            </div>
            <div class="form-container">
                <form method="POST" action="{{ route('pointcategory.store') }}">
                    @csrf
                    <input type="text" name="name" placeholder="Point Category Name" required>
                    <input type="number" name="total_points" placeholder="Total Points" required>
                    <input type="number" step="0.01" name="deduction_amount" placeholder="Deduction Amount Per Click" required>
                    <button type="submit" class="btn save-btn">Save</button>
                </form>
            </div>
        </div>
        <footer class="footer">
            <div class="footer-content">
                <img src="nen_logo.png" alt="Logo" class="footer-logo">
                <p>Powered by Magey HR</p>
                <p>Copyright 2024 © NEN Development</p>
            </div>
        </footer>
    </div>
</body>
</html>
