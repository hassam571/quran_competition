<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Point Category List</title>
    <link rel="stylesheet" href="css/PointCategoryList.css">
</head>
<style>
    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
        font-family: 'Roboto', sans-serif;
    }

    body {
        background-color: #f7f8fa;
        display: flex;
        flex-direction: column;
        height: 100vh; /* Ensure the body takes up the full height of the viewport */
    }

    .header {
        background-color: #4dbb94;
        color: #ffffff;
        padding: 10px;
        text-align: center;
        font-size: 18px;
        font-weight: 500;
        position: relative; /* Position relative to allow absolute positioning for the back button */
    }

    .back-btn {
        position: absolute;
        left: 15px;
        top: 50%;
        transform: translateY(-50%);
        background-color: transparent;
        border: none;
        color: #ffffff;
        font-size: 18px;
        cursor: pointer;
        transition: color 0.3s;
    }

    .back-btn:hover {
        color: #f7f8fa; /* Lighten the color when hovering */
    }

    .container {
        flex: 1; /* Take up remaining space */
        width: 100%;
        max-width: 100%;
        background-color: #ffffff;
        border-radius: 15px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        padding: 20px;
        overflow: auto;
    }

    .button-group {
    display: flex;
    justify-content: center; /* Center the buttons horizontally */
    gap: 20px; /* Space between the buttons */
    margin-bottom: 25px; /* Add space below the button group */
    width: 100%; /* Ensure it takes up full width of the parent container */
}

.button-group button {
    flex: 1;
    border-radius: 30px;
    padding: 10px;
    border: 2px solid #4dbb94;
    font-size: 16px;
    cursor: pointer;
    display: inline-flex; /* Ensure buttons are laid out in a row */
    justify-content: center; /* Center content within each button */
    align-items: center; /* Align content vertically within the button */
    text-align: center; /* Ensure text is centered within the button */
    min-width: 120px; /* Set a minimum width for buttons if needed */
}


     

        .active-button {
            background-color: #4dbb94;
            color: #ffffff;
        }

        .inactive-button {
            background-color: #ffffff;
            color: #4dbb94;
        }
    .list-container {
        max-height: 400px;
        overflow-y: auto;
        padding: 10px;
        background-color: #ffffff;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        margin-bottom: 20px;
    }

    .list-header {
        background-color: #4dbb94;
        color: #ffffff;
        padding: 10px;
        border-radius: 10px;
        font-size: 16px;
        margin-bottom: 15px;
        text-align: center;
    }

    .list-item {
        background-color: #f7f8fa;
        border-radius: 10px;
        padding: 15px;
        margin-bottom: 15px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        cursor: pointer;
        position: relative;
        transition: background-color 0.3s;
    }

    .list-item:hover {
        background-color: #e0f7f3;
    }

    .list-item .details {
        display: none;
        padding-top: 10px;
        background-color: #ffffff;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        margin-top: 10px;
        padding: 15px;
    }

    .list-item.active .details {
        display: block;
    }

    .arrow {
        font-size: 18px;
        color: #4dbb94;
        position: absolute;
        right: 15px;
        top: 50%;
        transform: translateY(-50%);
        transition: transform 0.3s;
    }

    .list-item.active .arrow {
        transform: translateY(-50%) rotate(180deg);
    }

    .button-group-inline {
        display: flex;
        gap: 10px;
        margin-top: 10px;
        justify-content: center;
    }

    .btn-delete, .btn-edit {
        border-radius: 5px;
        cursor: pointer;
        font-size: 14px;
        padding: 8px 15px;
        transition: background-color 0.3s, transform 0.3s;
    }

    .btn-delete {
        background-color: #ff4c4c;
        color: #ffffff;
    }

    .btn-edit {
        background-color: #4dbb94;
        color: #ffffff;
    }

    .btn-delete:hover {
        background-color: #e04848;
        transform: scale(1.05);
    }

    .btn-edit:hover {
        background-color: #3c9b7b;
        transform: scale(1.05);
    }

    .footer {
        text-align: center;
        padding: 20px;
        background-color: #4dbb94;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .footer-content {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        font-size: 12px;
        color: #fff
    }

    .footer-logo {
        height: 25px;
        width: 25px;
    }

    /* Custom Scrollbar */
    .list-container::-webkit-scrollbar {
        width: 12px;
    }

    .list-container::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }

    .list-container::-webkit-scrollbar-thumb {
        background-color: #4dbb94;
        border-radius: 10px;
        border: 3px solid #f1f1f1;
    }
</style>
<body>
    <header class="header">
        <button class="back-btn" onclick="window.history.back()">←</button>
        <h1>Point Category List</h1>
    </header>
    <div class="container">
        <div class="button-group">
            <button class="inactive-button" onclick="window.location.href='{{ route('pointcategory.create') }}'">Create Point Category</button>
            <button class="active-button">Point Category List</button>
        </div>
        <div class="list-container">
            @if(session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif
            @foreach($pointCategories as $pointCategory)
                <div class="list-item" onclick="this.classList.toggle('active')">
                    <p><strong>Point Category Name:</strong> {{ $pointCategory->name }}</p>
                    <span class="arrow">&#x25BC;</span>
                    <div class="details">
                        <p><strong>Total Number of Points:</strong> {{ $pointCategory->total_points }}</p>
                        <p><strong>Deduction Amount per Click:</strong> {{ $pointCategory->deduction_amount }}</p>
                        <div class="button-group-inline">
                            <form action="{{ route('pointcategory.setSession') }}" method="POST">
                                @csrf
                                <input type="hidden" name="point_category_id" value="{{ $pointCategory->id }}">
                                <button type="submit" class="btn-edit">Edit</button>
                            </form>
                            <form action="{{ route('pointcategory.delete') }}" method="POST">
                                @csrf
                                <input type="hidden" name="point_category_id" value="{{ $pointCategory->id }}">
                                <button type="submit" class="btn-delete">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            @endforeach
            @if($pointCategories->isEmpty())
                <p>No point categories found. Click "Create Point Category" to add one.</p>
            @endif
        </div>
    </div>
    <footer class="footer">
        <div class="footer-content">
            <p>Powered by Magey HR</p>
            <p>Copyright 2024
