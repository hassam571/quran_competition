@extends('layouts.app')
@section('content')

    <div class="container">
        <div class="header">Question List</div>

        <div class="button-group">
            <a href="{{ route('questions.create') }}" class="btn btn-outline-success">
                Create Questions
            </a>
            <a href="{{ route('questions.list') }}" class="btn btn-outline-success  active-button">Question List</a>
        </div>

        <div class="list-container">
            @foreach($questions as $question)
                <div class="question-card" onclick="this.classList.toggle('active')">
                    <div class="question-header">
                        <span><strong>Question Name:</strong> {{ $question->question_name }}</span>
                        <span class="arrow">&#x25BC;</span>
                    </div>
                    <div class="question-details">
                        <p><strong>Competition Name:</strong> {{ $question->competition_name }}</p>
                        <p><strong>Age Category:</strong> {{ $question->age_category }}</p>
                        <p><strong>Side Category:</strong> {{ $question->side_category }}</p>
                        <p><strong>Read Category:</strong> {{ $question->read_category }}</p>
                        <p><strong>Surah:</strong> {{ $question->surah_no }} - {{ $question->surah_name_ar }} ({{ $question->surah_name_roman }})</p>

                        <p><strong>Book #:</strong> {{ $question->book_number }}</p>
                        <p><strong>From #:</strong> {{ $question->from_ayat_number }}</p>
                        <p><strong>To #:</strong> {{ $question->to_ayat_number }}</p>
                        <div class="question-actions">
                            <form action="{{ route('questions.delete', $question->id) }}" method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button class="btn-action btn-delete" type="submit">Delete</button>
                            </form>
                            <a href="{{ route('questions.edit', $question->id) }}" class="btn btn-primary btn-sm mr-2">Edit</a>
                            <a href="{{ route('questions.view', $question->id) }}" class="btn btn-info btn-sm">View</a>

                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>


@endsection
