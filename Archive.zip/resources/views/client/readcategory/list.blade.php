<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Read Category List</title>
  <link rel="stylesheet" href="css/ReadCategoryList.css">
  <style>
    /* Reset */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    /* Body Styling */
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f9f9f9;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
        padding: 10px;
    }

    /* Header Styling */
    .header {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        background-color: #00bfa6;
        color: white;
        padding: 15px 20px;
        border-radius: 10px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        z-index: 10;
    }

    .header h1 {
        font-size: 18px;
        text-align: center;
    }

    .back-btn {
        position: absolute;
        left: 20px;
        top: 15px;
        background: none;
        border: none;
        color: white;
        font-size: 18px;
        cursor: pointer;
    }

    /* Main Content Area */
    .content {
        margin-top: 80px; /* Space for fixed header */
        flex: 1;
        width: 100%;
        max-width: 1200px;
        margin: 80px auto 50px; /* Center the content */
    }

    /* Tabs Styling */
    .tabs {
        display: block;
        margin-bottom: 20px;
        text-align: center; /* Center the tab buttons */
    }

    .tab-btn {
        font-size: 14px;
        padding: 10px 15px;
        border-radius: 20px;
        border: 2px solid #00bfa6;
        background-color: white;
        color: #00bfa6;
        cursor: pointer;
        transition: all 0.3s ease-in-out;
        display: inline-block;
        margin: 10px;
    }

    .tab-btn.active {
        background-color: #00bfa6;
        color: white;
    }

    .tab-btn:hover {
        background-color: #008f79;
        color: white;
    }

    /* List Container */
    .list-container {
        background-color: white;
        border-radius: 10px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        padding: 20px;
        max-height: 400px;
        overflow-y: auto;
    }

    .list-title {
        background-color: #00bfa6;
        color: white;
        padding: 10px;
        text-align: center;
        border-radius: 10px;
        margin-bottom: 15px;
        font-size: 16px;
    }

    /* Category Cards */
    .category-card {
        background-color: #fff;
        border: 1px solid #ddd;
        border-radius: 10px;
        margin-bottom: 10px;
        padding: 10px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .card-header p {
        font-size: 14px;
    }

    .card-header span {
        color: #00bfa6;
        font-weight: bold;
    }

    .card-header i {
        float: right;
        color: #888;
    }

    .card-actions {
        text-align: center; /* Center the action buttons */
        margin-top: 10px;
    }

    .delete-btn {
        background-color: #e74c3c;
        color: white;
        border: none;
        border-radius: 8px;
        padding: 8px 12px;
        cursor: pointer;
        transition: background-color 0.3s ease-in-out;
        display: inline-block;
        margin: 5px;
    }

    .delete-btn:hover {
        background-color: #c0392b;
    }

    .edit-btn {
        background-color: #00bfa6;
        color: white;
        border: none;
        border-radius: 8px;
        padding: 8px 12px;
        cursor: pointer;
        transition: background-color 0.3s ease-in-out;
        display: inline-block;
        margin: 5px;
    }

    .edit-btn:hover {
        background-color: #008f79;
    }

    /* Footer */
    .footer {
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        text-align: center;
        border: 2px solid #fff;
        border-radius: 10px;
        padding: 20px 15px;
        background-color: #00bfa6;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        margin-top: 30px;
    }

    .footer-content {
        font-size: 14px;
        color: #fff;
        line-height: 1.8;
    }

    /* Responsive Design for Footer */
    @media (min-width: 768px) {
        .footer {
            padding: 25px 20px;
        }

        .footer-content {
            font-size: 16px;
        }
    }
  </style>
</head>
<body>
  <!-- Header -->
  <header class="header">
    <button class="back-btn" onclick="window.history.back()"><i class="fas fa-arrow-left"></i></button>
    <h1>Read Category List</h1>
  </header>

  <!-- Main Content Area -->
  <div class="content">
    <!-- Tabs -->
    <div class="tabs">
      <a href="{{ route('readcategory.create') }}" class="tab-btn">Create Read Category</a>
      <button class="tab-btn active">Read Category List</button>
    </div>

    <!-- Read Category List -->
    <div class="list-container">
      @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
      @endif

      <h2 class="list-title">Read Category List</h2>
      @foreach($readCategories as $readCategory)
        <div class="category-card">
          <div class="card-header">
            <p>Read Category: <span>{{ $readCategory->name }}</span></p>
          </div>
          <div class="card-actions">
            <form action="{{ route('readcategory.setSession') }}" method="POST" style="display:inline-block;">
              @csrf
              <input type="hidden" name="read_category_id" value="{{ $readCategory->id }}">
              <button type="submit" class="btn edit-btn">Edit</button>
            </form>
            <form action="{{ route('readcategory.delete') }}" method="POST" style="display:inline-block;">
              @csrf
              <input type="hidden" name="read_category_id" value="{{ $readCategory->id }}">
              <button type="submit" class="btn delete-btn">Delete</button>
            </form>
          </div>
        </div>
      @endforeach

      @if($readCategories->isEmpty())
        <p>No read categories found. Click "Create Read Category" to add one.</p>
      @endif
    </div>
  </div>

  <!-- Footer -->
  <footer class="footer">
    <div class="footer-content">
      <p>Powered by Magey HR</p>
      <p>&copy; 2024 e NEN Development</p>
    </div>
  </footer>
</body>
</html>
