<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Side Category</title>
  <style>
    /* Reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    /* Body Styling */
    body {
      font-family: 'Arial', sans-serif;
      background-color: #f9f9f9;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      min-height: 100vh;
      padding: 0;
    }

    /* Header */
    header {
      display: flex;
      justify-content: center; /* Center header title */
      align-items: center;
      background-color: #00bfa6;
      color: white;
      padding: 10px;
      font-size: 18px;
    }

    /* Main Content */
    .container {
      flex-grow: 1;
      padding: 20px;
      text-align: center;
    }

    .container h1 {
      margin-bottom: 20px;
      font-size: 24px;
    }

    form {
      display: flex;
      flex-direction: column; /* Stack form elements vertically */
      align-items: center; /* Center form elements */
    }

    label {
      font-size: 16px;
      display: block;
      margin-bottom: 10px;
      text-align: left;
      width: 100%;
      max-width: 300px;
    }

    input {
      font-size: 14px;
      padding: 10px;
      width: 100%;
      max-width: 300px;
      border: 1px solid #ddd;
      border-radius: 8px;
      margin-bottom: 20px;
    }

    button {
      background-color: #00bfa6;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-size: 16px;
      transition: background-color 0.3s ease-in-out;
      width: 100%; /* Make the button take full width */
      max-width: 300px;
    }

    button:hover {
      background-color: #008f79;
    }

    /* Footer */
    footer {
      background-color: #00bfa6;
      color: white;
      padding: 15px;
      text-align: center;
    }
  </style>
</head>
<body>
  <!-- Header -->
  <header>
    <h1>Edit Side Category</h1>
  </header>

  <!-- Main Content -->
  <div class="container">
    <form method="POST" action="{{ route('sidecategory.update') }}">
      @csrf
      <label for="name">Category Name</label>
      <input type="text" name="name" id="name" value="{{ $sideCategory->name }}" required>
      <button type="submit">Update</button>
    </form>
  </div>

  <!-- Footer -->
  <footer>
    <p>Powered by Magey HR</p>
    <p>&copy; 2024 e NEN Development</p>
  </footer>
</body>
</html>
