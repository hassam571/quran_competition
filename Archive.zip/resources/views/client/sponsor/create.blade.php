@extends('layouts.app')

@section('content')
    <div class="container my-5">
        <h2>Create Sponsor</h2>

        <!-- Button Group -->
        <div class="button-group mb-4">
            <a href="{{ route('sponsors.create') }}" class="btn btn-outline-success active-button">Create Sponsor</a>
            <a href="{{ route('sponsors.index') }}" class="btn btn-outline-success">Sponsor List</a>
        </div>

        <!-- Success Message -->
        @if(session('success'))
            <div class="alert alert-success alert-custom animate__animated animate__fadeInDown" role="alert">
                {{ session('success') }}
            </div>
        @endif

        <!-- Error Message -->
        @if(session('error'))
            <div class="alert alert-danger alert-custom animate__animated animate__fadeInDown" role="alert">
                {{ session('error') }}
            </div>
        @endif

        <!-- The Form -->
        <form action="{{ route('sponsors.store') }}" method="POST" enctype="multipart/form-data" class="form-container mt-4">
            @csrf
            <div class="form-group mb-3">
                <input type="text" class="form-control" name="name" placeholder="Sponsor Name" value="{{ old('name') }}" required>
            </div>
            <div class="form-group mb-3">
                <label for="competition_id" class="form-label">Competition</label>
                <select class="form-control" id="competition_id" name="competition_id" required>
                    <option value="">Select Competition</option>
                    @foreach($competitions as $competition)
                        <option value="{{ $competition->id }}" {{ old('competition_id') == $competition->id ? 'selected' : '' }}>
                            {{ $competition->main_name }}
                        </option>
                    @endforeach
                </select>
                
            </div>
            <div class="form-group mb-3">
                <label for="logo" class="form-label">Sponsor Logo</label>
                <input type="file" class="form-control" id="logo" name="logo" accept="image/*">
            </div>
            <button type="submit" class="btn btn-primary">Save</button>
        </form>
    </div>
@endsection
