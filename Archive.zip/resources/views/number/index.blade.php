@php

    use App\Models\Competitor;
    use App\Models\QuestionChild;
@endphp
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Card Template</title>
    @include('includes.head')

    <style>
        body {
            font-family: Arial, sans-serif;
            min-height: 100vh;
            background-color: #f4f4f4;
            margin: 0;
        }

        .competition-main, .welcome-box {
            border-radius: 25px;
            padding: 15px;
            text-align: center;
            font-weight: 500;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .competition-main {
            background-color: #2ab795;
            color: white;
        }

        .welcome-box {
            background-color: white;
            color: #2ab795;
            margin-bottom: 30px;
        }

        .card-container {
            display: flex;
            gap: 20px;
            overflow-x: auto;
            padding: 20px;
            scrollbar-width: thin;
            scrollbar-color: #ccc #f4f4f4;
        }

        .card-container::-webkit-scrollbar {
            height: 8px;
        }

        .card-container::-webkit-scrollbar-thumb {
            background-color: #ccc;
            border-radius: 10px;
        }

        .card-container::-webkit-scrollbar-track {
            background-color: #f4f4f4;
        }

        .card {
            flex: 0 0 auto;
            width: 150px;
            height: 250px;
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            position: relative;
            cursor: pointer;
            transition: transform 0.6s ease, z-index 0.2s ease;
            transform-style: preserve-3d;
        }

        .card .front, .card .back {
            position: absolute;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 15px;
            text-align: center;
        }

        .card .front {
            background-color: #4caf50;
            color: white;
            font-size: 24px;
            font-weight: bold;
        }

        .card .back {
            background-color: #f9f9f9;
            color: #333;
            transform: rotateY(180deg);
            font-size: 18px;
            padding: 10px;
        }

        .card .back input[type="checkbox"] {
            position: absolute;
            top: 10px;
            right: 10px;
            transform: scale(1.5);
        }

        .card:hover {
            transform: scale(1.05);
            z-index: 5;
        }

        .card.last {
            transform: scale(1.2);
            z-index: 10;
        }

        .card.show {
            transform: rotateY(180deg);
        }

        .form1 {
            margin: 0;
            padding: 0;
            width: 100%;
            display: flex;
            justify-content: center;
        }
    </style>

</head>

<body>
    @if (session('success'))
        <div class="alert alert-success alert-custom animate__animated animate__fadeInDown" role="alert">
            {{ session('success') }}
        </div>
    @endif

    @if (session('error'))
        <div class="alert alert-danger alert-custom animate__animated animate__fadeInDown" role="alert">
            {{ session('error') }}
        </div>
    @endif







    @php
    // Fetch the first question's competitor and competition IDs
    $competitor_id = $questions->first()->competitor_id ?? null;
    $competition_id = $questions->first()->competition_id ?? null;

    // Fetch the number of questions already answered by the competitor
    $number_of_questions_done = \App\Models\QuestionChild::where('competitor_id', $competitor_id)
        ->where('competition_id', $competition_id)
        ->count();

    $competitor = \App\Models\Competitor::find($competitor_id);
    $number_of_questions = $competitor->number_of_questions ?? 0;
@endphp
@if ($number_of_questions_done >= $number_of_questions)
<div class="alert  text-center" role="alert">
    <div class="competition-main">
        <h4 class="mb-1">No Questions Found | No Records to Display</h4>
    </div>
    <div class="container mt-5">
        <div class="alert alert-warning text-center competition-main" role="alert">
            <h4 class="alert-heading">Why!</h4>
            <p>Questions cannot be displayed at the moment. This may be because the candidate has reached the maximum question limit, or there are no questions available that match the competitor's requirements, such as reading level, side, or age category.</p>
            <hr>
            <p class="mb-0">If you need assistance, please contact the competition organizer.</p>
        </div>
    </div>
</div>

@else
    @if ($questions->isNotEmpty())
        <div class="container mt-5">
            <!-- Competition Main Box -->
            <div class="competition-main">
                <h4 class="mb-1">Competition Main Name</h4>
                <h5>Competition Sub Name</h5>
            </div>

            <!-- Welcome Box -->
            <div class="welcome-box">
                <h5 class="mb-1">Welcome, {{ $questions->first()->full_name }}</h5>
                <h6>Best Of Luck...</h6>
            </div>

            <!-- Cards Section -->
            <form action="{{ route('question.store') }}" method="POST" class="form1">
                @csrf
                <div class="card-container">
                    @foreach ($questions as $question)
                        <div class="card {{ $loop->last ? 'last' : '' }}" data-question="{{ $question->question_name }}">
                            <div class="front">{{ $loop->iteration }}</div>
                            <div class="back">
                                {{ $question->question_name }}
                                <input type="checkbox" name="question_id[]" value="{{ $question->question_id }}" id="card-{{ $loop->iteration }}" class="checkbox" data-question="{{ $question->id }}">
                                <input type="hidden" value="{{ $question->competitor_id }}" name="competitor_id">
                                <input type="hidden" value="{{ $question->competition_id }}" name="competition_id">
                            </div>
                        </div>
                    @endforeach
                </div>
            </form>

        </div>
    @else
        <div class="competition-main">
            <h4 class="mb-1">No Question Matched</h4>
        </div>
        <div class="container mt-5">
            <div class="alert alert-warning text-center competition-main" role="alert">
                <h4 class="alert-heading">No Record Found!</h4>
                <p>Questions cannot be displayed at the moment. Please wait and try again later.</p>
                <hr>
                <p class="mb-0">If you need assistance, please contact the competition organizer.</p>
            </div>
        </div>
    @endif
@endif


    <script>
        document.querySelectorAll('.card').forEach((card) => {
            const front = card.querySelector('.front');
            const back = card.querySelector('.back');
            const checkbox = back.querySelector('input[type="checkbox"]');

            // Initialize visibility
            front.style.display = 'flex';
            back.style.display = 'none';

            // Click event for flipping the card
            card.addEventListener('click', (e) => {
                const isFlipped = card.classList.contains('show');

                // Flip the card if not already flipped
                if (!isFlipped) {
                    // Reset all other cards
                    document.querySelectorAll('.card').forEach((c) => {
                        c.classList.remove('show');
                        c.querySelector('.front').style.display = 'flex';
                        c.querySelector('.back').style.display = 'none';
                    });

                    card.classList.add('show');
                } else {
                    // If already flipped, toggle the checkbox when clicking anywhere
                    if (e.target !== checkbox) {
                        checkbox.checked = !checkbox.checked;

                        // Submit the form only if the checkbox is checked
                        if (checkbox.checked) {
                            checkbox.form.submit();
                        }
                    }
                }
            });

            // Manage visibility during and after animation
            card.addEventListener('transitionend', () => {
                if (card.classList.contains('show')) {
                    front.style.display = 'none'; // Hide front after flip
                    back.style.display = 'flex'; // Show back after flip
                } else {
                    front.style.display = 'flex'; // Show front after flip back
                    back.style.display = 'none'; // Hide back after flip back
                }
            });

            // Checkbox change event to submit the form on check
            checkbox.addEventListener('change', function() {
                // Only submit if the checkbox is checked (not unchecked)
                if (this.checked) {
                    this.form.submit();
                }
            });
        });
    </script>

</body>

</html>
