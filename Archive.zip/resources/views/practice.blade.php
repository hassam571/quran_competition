@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Fetch Quran Verses</h2>

    <!-- Form for input -->
    <form action="{{ route('quran.ayats') }}" method="GET">
        @csrf
        <div class="form-group">
            <label for="juz_number">Juz Number (1-30):</label>
            <input type="number" name="juz_number" class="form-control" min="1" max="30" required>
        </div>

        <div class="form-group">
            <label for="from_verse">From Verse:</label>
            <input type="number" name="from_verse" class="form-control" min="1" required>
        </div>

        <div class="form-group">
            <label for="to_verse">To Verse:</label>
            <input type="number" name="to_verse" class="form-control" min="1" required>
        </div>

        <button type="submit" class="btn btn-primary">Fetch Ayats</button>
    </form>
</div>
@endsection
