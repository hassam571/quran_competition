<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Competition Questions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            text-align: center;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .header {
            margin-bottom: 20px;
        }

        .header h2 {
            color: #44a089;
            margin-bottom: 5px;
            font-size: 28px;
        }

        .header h3 {
            color: #666;
            font-weight: normal;
            font-size: 18px;
        }


        .question-title {
            color: #44a089;
            font-weight: bold;
            font-size: 20px;
            margin-bottom: 10px;
        }

        .detail {
            margin-top: 10px;
            font-size: 16px;
            color: #333;
        }

        .detail span {
            color: #44a089;
            font-weight: bold;
        }

        .no-questions {
            background: #fff5f5;
            border: 1px solid #f5c2c2;
            border-radius: 10px;
            padding: 30px;
            color: #e74c3c;
            font-size: 18px;
        }

        .footer {
            margin-top: 20px;
            font-size: 14px;
            color: #666;
        }

        .footer a {
            color: #44a089;
            text-decoration: none;
        }

        #question-tab-buttons button {
            margin: 5px;
            padding: 10px 15px;
            background: #44a089;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        /* Disabled buttons styling if needed */
        #question-tab-buttons button:disabled {
            background: #aaa;
            cursor: not-allowed;
            opacity: 0.7;
        }
    </style>
      <style>
        .detail-container {
            text-align: right; /* Align text to the right for RTL languages */
            direction: rtl; /* Ensure proper RTL direction */
            font-family: 'Amiri', serif; /* Arabic calligraphy-friendly font */
            font-size: 22px; /* Adjust font size */
            line-height: 1.8; /* Line height for readability */
            margin: 15px 0; /* Add spacing between elements */
            background: #fdf8e1; /* Subtle background for elegance */
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Slight shadow for depth */
            color: #333; /* Text color */
        }

        .detail-container .text-label {
            display: inline-block;
            font-weight: bold;
            font-size: 18px;
            margin-left: 5px; /* Add spacing between label and text */
            color: #00bfa5; /* Highlighted color for labels */
        }

        .detail-container .text-content {
            font-family: 'Amiri', serif; /* Consistent Arabic font */
            font-weight: normal;
            color: #000; /* Text color */
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h2>Competition Questions</h2>
            <h3>View Active Questions One by One</h3>
        </div>

        <!-- Question Display Container -->
        <div id="question-content">
            @if($questions->isEmpty())
                <div class="no-questions">No more active questions available.</div>
            @else
                <!-- If you initially want to show buttons or some initial data -->
                @foreach($questions as $question)
                <div id="question-tab-buttons">
                    @foreach($questions as $question)
                        <button class="question-tab-button"
                                data-question-id="{{ $question->question_id }}"
                                data-competitor-id="{{ $question->competitor_id }}"
                                disabled>
                            {{ $question->question_name }}
                        </button>
                    @endforeach
                </div>
                    <div class="question-box">
                        {{-- <div class="detail"><span>Status:</span> {{ $question->status }}</div>
                        <div class="detail"><span>Competitor:</span> {{ $question->competitor_name }}</div> --}}


                        <div class="detail-container">
                            <span class="text-content">{{ $question->text }}</span>
                        </div>
                                            </div>
                @endforeach
            @endif
        </div>

        <!-- Footer -->
        <div class="footer">
            Powered by <a href="#">Magey HR</a><br>
            &copy; 2024 NEN Development
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Regular expression to match Arabic numerals (٠ to ٩)
            const arabicNumeralsRegex = /[٠-٩]+/g;

            // Select all elements with the .text-content class
            const textElements = document.querySelectorAll('.text-content');

            textElements.forEach(element => {
                // Replace Arabic numbers in the text with styled spans
                element.innerHTML = element.innerHTML.replace(
                    arabicNumeralsRegex,
                    match => `<span class="ayat-number">${match}</span>`
                );
            });
        });
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            function fetchLiveData() {
                fetch("{{ route('questions.live.data') }}")
                    .then(response => response.json())
                    .then(data => {
                        const container = document.getElementById('question-content');
                        container.innerHTML = '';
                        if (data.length === 0) {
                            container.innerHTML = '<div class="no-questions">No more active questions available.</div>';
                        } else {
                            data.forEach(question => {
                                let questionBox = document.createElement('div');
                                questionBox.className = 'question-box';
                                questionBox.innerHTML = ` <div class="detail-container">
                            <span class="text-content">${question.text}</span>
                        </div>
                                `;
                                container.appendChild(questionBox);
                            });
                        }
                    })
                    .catch(error => console.error('Error fetching live data:', error));
            }

            // Initial fetch
            fetchLiveData();

            // Fetch data every 4 seconds
            setInterval(fetchLiveData, 3000);
        });
    </script>
</body>
</html>
