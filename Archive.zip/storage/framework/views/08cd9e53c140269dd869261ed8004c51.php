<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show Questions</title>
    <link href="https://fonts.googleapis.com/css2?family=Amiri&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Amiri&display=swap" rel="stylesheet">

    <style>
        /* Existing Styles */

        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            text-align: center;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .header {
            margin-bottom: 20px;
        }

        .header h2 {
            color: #44a089;
            margin-bottom: 5px;
        }

        .header h3 {
            color: #666;
            font-weight: normal;
        }

        .question-box {
            display: none;
            background: #f4f4f4;
            border-radius: 10px;
            padding: 20px;
            text-align: left;
            margin: 20px 0;
            border: 1px solid #ddd;
        }

        .ayat-text {
            display: inline-block;
            margin: 0 5px;
        }

        #question-tab-buttons button {
            margin: 5px;
            padding: 10px 15px;
            background: #44a089;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        #show-question-button {
            padding: 10px 30px;
            background: #44a089;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        .message {
            margin-top: 20px;
            color: green;
        }

        /* Hide the form and submit button completely since we submit automatically */
        form {
            display: none;
        }

        /* New Styles for Pagination Controls */
        .pagination-controls {
            margin-top: 15px;
            text-align: center;
        }

        .pagination-controls button {
            margin: 0 5px;
            padding: 5px 10px;
            background: #44a089;
            color: #fff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            /* Explicitly set type to button */
            type: button;
        }

        .pagination-controls button:disabled {
            background: #ccc;
            cursor: not-allowed;
        }

        .pagination-info {
            margin: 0 10px;
            font-weight: bold;
        }

    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>Show Questions</h2>
            <h3>Competition ID: <?php echo e(session('competition_id')); ?></h3>
        </div>

        <!-- Buttons to switch questions -->
        <div id="question-tab-buttons">
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button class="question-tab-button"
                        data-question-id="<?php echo e($question->question_id); ?>"
                        data-competitor-id="<?php echo e($question->competitor_id); ?>">
                    <?php echo e($question->question_name); ?>

                </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Container for questions -->
        <div id="question-container" data-competition-id="<?php echo e(session('competition_id')); ?>">
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="question-box"
                     id="question-<?php echo e($question->question_id); ?>"
                     data-question-id="<?php echo e($question->question_id); ?>"
                     data-competitor-id="<?php echo e($question->competitor_id); ?>">

                    <h5>Question: <?php echo e($question->question_name); ?></h5>
                    <style>
                        .ayat-container {
                            text-align: right; /* Align text to the right for RTL */
                            direction: rtl; /* Set the direction to Right-to-Left */
                            font-family: 'Amiri', serif; /* Use a font that supports Arabic calligraphy (e.g., Amiri or Traditional Arabic) */
                            font-size: 24px; /* Adjust font size for Quranic text */
                            line-height: 2; /* Add line spacing for readability */
                            margin: 10px 0;
                            color: #333; /* Set the text color */
                            background: #fdf8e1; /* Subtle background color for elegance */
                            padding: 15px;
                            border-radius: 10px;
                            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                        }

                        .ayat-text {
                            display: inline-block;
                            margin: 0 5px;
                            font-weight: normal;
                        }

                        .ayat-number {
    display: inline-block;
    margin-left: 5px;
    width: 2rem;
    height: 2rem;
    font-size: 18px;
    font-weight: bold;
    background: #00bfa5; /* Use a color for Ayat number */
    color: #fff;
    border-radius: 50%;
    text-align: center;
    line-height: 2rem; /* Vertically center the number */
    line-height: 2rem; /* Ensure the number is vertically centered */
    font-family: 'Amiri', 'Scheherazade', serif; /* Arabic numeral font */
    unicode-bidi: bidi-override; /* Ensure Arabic numbering */
    direction: rtl; /* Ensure correct numeral direction */
}

                    </style>
<div class="ayat-container">
    <?php $__currentLoopData = $question->ayat_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ayat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span class="ayat-text">
            <?php echo e($ayat->ayah_ar); ?>

            <span class="ayat-number">
                <?php
                    $arabicNumerals = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
                    $ayahNoArabic = implode('', array_map(fn($digit) => $arabicNumerals[$digit], str_split($ayat->ayah_no_surah)));
                ?>
                <?php echo e($ayahNoArabic); ?>

            </span>
            <?php if(!$loop->last): ?>
                ,
            <?php endif; ?>
        </span>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>




                    <!-- Added Pagination Controls -->
                    <div class="pagination-controls" style="display: none;">
                        <button type="button" class="prev-page">Previous</button>
                        <span class="pagination-info">Page <span class="current-page">1</span> of <span class="total-pages">1</span></span>
                        <button type="button" class="next-page">Next</button>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <button id="show-question-button">Prepare Question Data</button>


        <?php if(session('message')): ?>
            <div class="message"><?php echo e(session('message')); ?></div>
        <?php endif; ?>
    </div>

    
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const questionTabButtons = document.getElementById('question-tab-buttons');
            const questionContainer = document.getElementById('question-container');
            const showQuestionButton = document.getElementById('show-question-button');

            let currentQuestionId = "<?php echo e(session('current_question_id') ?? ''); ?>"; // Store the ID of the currently visible question
            let currentPage = parseInt("<?php echo e(session('current_page') ?? 1); ?>"); // Current page

            // Object to store current pages for each question
            const questionPages = {};

            // Function to setup pagination for a given question box
            function setupPagination(questionBox) {
                const ayatContainer = questionBox.querySelector('.ayat-container');
                const ayatTexts = ayatContainer.querySelectorAll('.ayat-text');
                const paginationControls = questionBox.querySelector('.pagination-controls');

                const itemsPerPage = 5; // Set to 3 as per original request
                const totalItems = ayatTexts.length;
                const totalPages = Math.ceil(totalItems / itemsPerPage);

                if (totalPages <= 1) {
                    // No need for pagination if items are 3 or less
                    paginationControls.style.display = 'none';
                    return;
                }

                let currentPageLocal = questionPages[questionBox.dataset.questionId] || 1;

                // Show pagination controls
                paginationControls.style.display = 'block';
                paginationControls.querySelector('.total-pages').innerText = totalPages;

                function showPage(page) {
                    currentPageLocal = page;
                    questionPages[questionBox.dataset.questionId] = currentPageLocal; // Store current page
                    const start = (page - 1) * itemsPerPage;
                    const end = start + itemsPerPage;

                    ayatTexts.forEach((ayat, index) => {
                        if (index >= start && index < end) {
                            ayat.style.display = 'inline-block';
                        } else {
                            ayat.style.display = 'none';
                        }
                    });

                    // Update pagination info
                    paginationControls.querySelector('.current-page').innerText = currentPageLocal;

                    // Disable buttons if on first or last page
                    paginationControls.querySelector('.prev-page').disabled = (currentPageLocal === 1);
                    paginationControls.querySelector('.next-page').disabled = (currentPageLocal === totalPages);
                }

                // Initial display
                showPage(currentPageLocal);

                // Event listeners for pagination buttons
                const prevButton = paginationControls.querySelector('.prev-page');
                const nextButton = paginationControls.querySelector('.next-page');

                prevButton.addEventListener('click', function (event) {
                    event.preventDefault();
                    if (currentPageLocal > 1) {
                        showPage(currentPageLocal - 1);
                    }
                });

                nextButton.addEventListener('click', function (event) {
                    event.preventDefault();
                    if (currentPageLocal < totalPages) {
                        showPage(currentPageLocal + 1);
                    }
                });
            }

            // Function to initialize pagination for all existing question boxes
            function initializePagination() {
                const allQuestionBoxes = document.querySelectorAll('.question-box');
                allQuestionBoxes.forEach((questionBox) => {
                    setupPagination(questionBox);
                });
            }

            // Initialize pagination on initial load
            initializePagination();

            // Function to display a specific question and page
            function displayQuestion(questionId, page = 1) {
                // Hide all questions
                const allQuestions = document.querySelectorAll('.question-box');
                allQuestions.forEach(q => q.style.display = 'none');

                // Show the selected question
                const selectedQuestion = document.getElementById(`question-${questionId}`);
                if (selectedQuestion) {
                    selectedQuestion.style.display = 'block';
                    currentQuestionId = questionId;

                    // Initialize or restore pagination
                    setupPagination(selectedQuestion);

                    // Set to the desired page
                    const paginationControls = selectedQuestion.querySelector('.pagination-controls');
                    if (paginationControls.style.display !== 'none') {
                        const ayatTexts = selectedQuestion.querySelectorAll('.ayat-text');
                        const itemsPerPage = 5;
                        const totalPages = Math.ceil(ayatTexts.length / itemsPerPage);

                        // Ensure the page is within bounds
                        const desiredPage = Math.min(Math.max(page, 1), totalPages);

                        // Update pagination info
                        paginationControls.querySelector('.current-page').innerText = desiredPage;
                        paginationControls.querySelector('.total-pages').innerText = totalPages;

                        // Show appropriate Ayat texts
                        ayatTexts.forEach((ayat, index) => {
                            if (index >= (desiredPage - 1) * itemsPerPage && index < desiredPage * itemsPerPage) {
                                ayat.style.display = 'inline-block';
                            } else {
                                ayat.style.display = 'none';
                            }
                        });

                        // Disable buttons accordingly
                        paginationControls.querySelector('.prev-page').disabled = (desiredPage === 1);
                        paginationControls.querySelector('.next-page').disabled = (desiredPage === totalPages);
                    }
                }
            }

            // Display the current question and page if available
            if (currentQuestionId) {
                displayQuestion(currentQuestionId, currentPage);
            } else {
                // Show the first question by default if available
                let firstQuestion = document.querySelector('.question-box');
                if (firstQuestion) {
                    firstQuestion.style.display = 'block';
                    currentQuestionId = firstQuestion.dataset.questionId;

                    // Initialize current page for the first question
                    if (!questionPages[currentQuestionId]) {
                        questionPages[currentQuestionId] = 1;
                    }
                }
            }

            // Event delegation for question tab buttons
            questionTabButtons.addEventListener('click', function (event) {
                if (event.target && event.target.matches('button.question-tab-button')) {
                    const questionId = event.target.getAttribute('data-question-id');
                    displayQuestion(questionId);
                }
            });

            // Handle "Prepare Question Data" button click using AJAX
            showQuestionButton.addEventListener('click', function () {
                const visibleQuestion = Array.from(document.querySelectorAll('.question-box'))
                    .find(box => box.style.display === 'block');

                if (!visibleQuestion) {
                    alert('No question is currently visible.');
                    return;
                }

                const questionId = visibleQuestion.getAttribute('data-question-id');
                const competitorId = visibleQuestion.getAttribute('data-competitor-id');
                const competitionId = document.getElementById('question-container').getAttribute('data-competition-id');

                // Find current page
                const paginationControls = visibleQuestion.querySelector('.pagination-controls');
                let currentPage = 1;
                if (paginationControls.style.display !== 'none') {
                    currentPage = parseInt(paginationControls.querySelector('.current-page').innerText);
                }

                // Gather the text
                let questionText = visibleQuestion.querySelector('h5').innerText;
                const ayatSpans = visibleQuestion.querySelectorAll('.ayat-text');
                ayatSpans.forEach(span => {
                    if (span.style.display !== 'none') { // Include only visible Ayat
                        questionText += ' ' + span.innerText;
                    }
                });

                // Prepare the data to send
                const data = {
                    question_id: questionId,
                    competitor_id: competitorId,
                    competition_id: competitionId,
                    text: questionText,
                    current_page: currentPage
                };

                // Send the data via Fetch API
                fetch("<?php echo e(route('show-question-to-user')); ?>", {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' // Include CSRF token
                    },
                    body: JSON.stringify(data)
                })
                .then(response => response.json())
                .then(data => {
                    console.log('Response data:', data); // Log the response for debugging
                    if(data.success){
                        // Show the server-provided success message
                        alert(data.message);
                    } else {
                        // Handle errors
                        if (data.errors) {
                            // Show validation errors
                            let errorMessages = '';
                            for (const [field, messages] of Object.entries(data.errors)) {
                                errorMessages += `${field}: ${messages.join(', ')}\n`;
                            }
                            alert(`Validation Errors:\n${errorMessages}`);
                        }
                    }
                })

            });

            // Function to fetch live questions and update the UI
            function fetchLiveQuestions() {
                fetch("<?php echo e(route('questions.live')); ?>")
                    .then((response) => response.json())
                    .then((data) => {
                        // Preserve the current question and its page
                        const preservedQuestionId = currentQuestionId;
                        const preservedPage = questionPages[preservedQuestionId] || 1;

                        data.forEach((question) => {
                            // Check if the question already exists
                            const existingButton = document.querySelector(`button.question-tab-button[data-question-id="${question.question_id}"]`);
                            const existingQuestionBox = document.getElementById(`question-${question.question_id}`);

                            if (!existingButton && !existingQuestionBox) {
                                // Create a new button for the question
                                const button = document.createElement('button');
                                button.className = 'question-tab-button';
                                button.innerText = question.question_name;
                                button.setAttribute('data-question-id', question.question_id);
                                button.setAttribute('data-competitor-id', question.competitor_id);
                                questionTabButtons.appendChild(button);

                                // Create the corresponding question box
                                const questionBox = document.createElement('div');
                                questionBox.className = 'question-box';
                                questionBox.id = `question-${question.question_id}`;
                                questionBox.setAttribute('data-question-id', question.question_id);
                                questionBox.setAttribute('data-competitor-id', question.competitor_id);

                                let ayatDetails = '';
                                if (question.ayat_details) {
                                    question.ayat_details.forEach((ayat, index) => {
                                        ayatDetails += `<span class="ayat-text">${ayat.ayah_ar} <strong>${ayat.surah_no}:${ayat.ayah_no_surah}</strong>${index < question.ayat_details.length - 1 ? ',' : ''}</span>`;
                                    });
                                }

                                questionBox.innerHTML = `
                                    <h5>Question: ${question.question_name}</h5>
                                    <div class="ayat-container">${ayatDetails}</div>
                                    <!-- Added Pagination Controls -->
                                    <div class="pagination-controls" style="display: none;">
                                        <button type="button" class="prev-page">Previous</button>
                                        <span class="pagination-info">Page <span class="current-page">1</span> of <span class="total-pages">1</span></span>
                                        <button type="button" class="next-page">Next</button>
                                    </div>
                                `;
                                questionContainer.appendChild(questionBox);

                                // Setup pagination for the new question box
                                setupPagination(questionBox);
                            }
                        });

                        // Restore the currently visible question and page
                        if (preservedQuestionId) {
                            displayQuestion(preservedQuestionId, preservedPage);
                        }
                    })

            }

            // Initial fetch and periodic refresh
            fetchLiveQuestions();
            setInterval(fetchLiveQuestions, 3000);
        });
    </script>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/quran-a/resources/views/showquestion/showquestionadmin.blade.php ENDPATH**/ ?>