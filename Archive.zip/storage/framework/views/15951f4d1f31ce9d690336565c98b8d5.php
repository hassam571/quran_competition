<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Magey Competition - Menu</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="css/menupage.css">
</head>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  /* Body Styling */
  body {
    font-family: 'Arial', sans-serif;
    background-color: #f9f9f9;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    padding: 10px;
  }

  /* Container */
  .container {
    width: 100%;
    max-width: 400px; /* Limit the width on larger devices */
    text-align: center;
    padding: 20px;
  }

  /* Header Styling */
  .header {
    background-color: #00bfa6;
    color: white;
    border-radius: 10px;
    margin-bottom: 20px;
  }

  .header h1 {
    font-size: 22px;
    line-height: 1.6;
  }




  /* Menu Buttons */
  .button-group {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .btn {
    font-size: 16px;
    color: #00bfa6;
    background-color: white;
    border: 2px solid #00bfa6;
    padding: 12px;
    border-radius: 25px;
    cursor: pointer;
    transition: all 0.3s;
  }

  .btn:hover {
    background-color: #00bfa6;
    color: white;
  }

  /* Footer */
  .footer {
    margin-top: 30px;
    text-align: center;
    border: 2px solid #00bfa6;
    border-radius: 10px;
    padding: 15px;
    background-color: white;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  }

  .footer-content {
    font-size: 14px;
    color: #00bfa6;
  }

  @media (min-width: 768px) {
    .header h1 {
      font-size: 26px;
    }

    .btn {
      font-size: 18px;
      padding: 14px;
    }

    .main-btn .btn-main {
      font-size: 18px;
      padding: 14px;
    }

    .footer-content {
      font-size: 16px;
    }
  }

</style>
<body>
  <div class="container">
    <!-- Header -->
    <header class="header">
      <h1>Welcome to,<br>Magey Competition</h1>
    </header>




    <!-- Menu Buttons -->
    <div class="button-group">
        <button class="btn btn-main" onclick="window.location.href='<?php echo e(route('competition.create')); ?>'">Competition</button>

        <button class="btn" onclick="window.location.href='<?php echo e(route('sidecategory.create')); ?>'">Side Category</button>

        <button class="btn" onclick="window.location.href='<?php echo e(route('readcategory.create')); ?>'">Read Category</button>

        <button class="btn" onclick="window.location.href='<?php echo e(route('agecategory.create')); ?>'">Age Category</button>

        <button class="btn" onclick="window.location.href='<?php echo e(route('pointcategory.create')); ?>'">Point Category</button>
        <button class="btn" onclick="window.location.href='<?php echo e(route('judges.create')); ?>'">Judge</button>
        <button class="btn" onclick="window.location.href='<?php echo e(route('questions.create')); ?>'">Questions</button>
        <button class="btn" onclick="window.location.href='<?php echo e(route('competitors.create')); ?>'">Competitors</button>
        <button class="btn" onclick="window.location.href='<?php echo e(route('sponsors.create')); ?>'">Sponsors</button>

      <button class="btn" onclick="window.location.href='<?php echo e(route('host.create')); ?>'">Host Competition</button>
    </div>
  </div>

  <!-- Footer -->
  <footer class="footer">
    <div class="footer-content">
      <p>Powered by Magey HR</p>
      <p>&copy; 2024 e NEN Development</p>
    </div>
  </footer>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/quran-a/resources/views/client/menu.blade.php ENDPATH**/ ?>