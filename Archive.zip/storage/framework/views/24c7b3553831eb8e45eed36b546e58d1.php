<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="header">Competitor List</div>

        <!-- Filter Dropdowns -->
        <?php if(session('alert')): ?>
            <div class="alert alert-warning">
                <?php echo e(session('alert')); ?>

            </div>
        <?php endif; ?>


        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>


        <div class="button-group">
            <a href="<?php echo e(route('host.create')); ?>" class="btn btn-outline-success">Host a Competition</a>
            <a href="<?php echo e(route('competitions.list')); ?>" class="btn btn-outline-success">Competitions</a>
            <a href="<?php echo e(route('host.announce')); ?>" class="btn btn-outline-success  active-button">Announce Winners</a>
        </div>

        <div class="button-group">
            <select id="sideCategoryFilter" class="btn btn-outline-success">
                <option value="">Select Side Category</option>
                <?php $__currentLoopData = $sideCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sideCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($sideCategory->id); ?>"><?php echo e($sideCategory->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <select id="readCategoryFilter" class="btn btn-outline-success">
                <option value="">Select Read Category</option>
                <?php $__currentLoopData = $readCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $readCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($readCategory->id); ?>"><?php echo e($readCategory->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <select id="ageCategoryFilter" class="btn btn-outline-success">
                <option value="">Select Age Category</option>
                <?php $__currentLoopData = $ageCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ageCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ageCategory->id); ?>"><?php echo e($ageCategory->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Competitor List -->
        <div id="competitorList">
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-custom animate__animated animate__fadeInDown" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-custom animate__animated animate__fadeInDown" role="alert">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

            <?php $__currentLoopData = $sortedCompetitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    // Check if competitor is already ranked
                    $alreadyRanked = \App\Models\Ranking::where('competitor_id', $competitor->id)->exists();
                ?>
                <form action="<?php echo e(route('rank.create', $competitor->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="rank" value="<?php echo e($competitor->position); ?>">
                    <div class="question-card"
                         data-side-category-id="<?php echo e($competitor->sideCategory->id ?? ''); ?>"
                         data-side-category-name="<?php echo e($competitor->sideCategory->name ?? ''); ?>"
                         data-read-category-id="<?php echo e($competitor->readCategory->id ?? ''); ?>"
                         data-read-category-name="<?php echo e($competitor->readCategory->name ?? ''); ?>"
                         data-age-category-id="<?php echo e($competitor->ageCategory->id ?? ''); ?>"
                         data-age-category-name="<?php echo e($competitor->ageCategory->name ?? ''); ?>">
                        <div class="question-header" onclick="toggleDetails(this)">
                            <span><strong>Position:</strong> <?php echo e($competitor->position); ?></span>
                            <span><strong>Candidate Name:</strong> <?php echo e($competitor->full_name); ?></span>
                            <span class="arrow">&#x25BC;</span>
                        </div>
                        <div class="question-details">
                            <p><strong>ID Card Number:</strong> <?php echo e($competitor->id_card_number); ?></p>
                            <p><strong>Address:</strong> <?php echo e($competitor->address); ?></p>
                            <p><strong>Island/City:</strong> <?php echo e($competitor->island_city); ?></p>
                            <p><strong>School Name:</strong> <?php echo e($competitor->school_name ?? 'N/A'); ?></p>
                            <p><strong>Parent Name:</strong> <?php echo e($competitor->parent_name); ?></p>
                            <p><strong>Phone Number:</strong> <?php echo e($competitor->phone_number); ?></p>

                            <!-- Print names of categories -->
                            <p><strong>Side Category:</strong> <?php echo e($competitor->sideCategory->name ?? 'N/A'); ?></p>
                            <p><strong>Read Category:</strong> <?php echo e($competitor->readCategory->name ?? 'N/A'); ?></p>
                            <p><strong>Age Category:</strong> <?php echo e($competitor->ageCategory->name ?? 'N/A'); ?></p>

                            <p><strong>Number of Questions:</strong> <?php echo e($competitor->number_of_questions); ?></p>

                            <!-- Displaying the result's point data -->
                            <?php
                                $totalPoints = 0;
                                $gainedPoints = 0;
                            ?>
                            <?php $__currentLoopData = $competitor->results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p><strong><?php echo e($result->pointCategory->name ?? 'N/A'); ?>:</strong>
                                   <?php echo e($result->total_points); ?> / <?php echo e($result->gained_points); ?></p>

                                <?php
                                    $totalPoints += $result->total_points;
                                    $gainedPoints += $result->gained_points;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <p><strong>Total:</strong> <?php echo e($totalPoints); ?> / <?php echo e($gainedPoints); ?></p>

                            <?php if($alreadyRanked): ?>
                                <button class="btn btn-secondary" type="button" disabled>Already Sent</button>
                            <?php else: ?>
                                <button class="btn btn-success send-btn" type="submit">Save Ranking</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>








    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .filter-group {
            margin-bottom: 20px;
        }

        .filter-group select {
            margin-right: 15px;
        }

        .question-card {
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin: 15px 0;
            border-radius: 8px;
            overflow: hidden;
        }

        .question-header {
            background-color: #f4f4f4;
            padding: 10px;
            font-size: 1.2em;
            font-weight: bold;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
        }

        .question-header .arrow {
            cursor: pointer;
        }

        .question-details {
            padding: 15px;
            background-color: #fafafa;
        }

        .btn {
            font-size: 1em;
            padding: 8px 20px;
            border-radius: 5px;
        }

        .send-btn {
            font-size: 1.2em;
            padding: 10px 25px;
            border-radius: 6px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }

        .send-btn:hover {
            background-color: #45a049;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        // Filter competitors based on selected criteria
        function filterCompetitors() {
            const sideCategory = document.getElementById('sideCategoryFilter').value.toLowerCase();
            const readCategory = document.getElementById('readCategoryFilter').value.toLowerCase();
            const ageCategory = document.getElementById('ageCategoryFilter').value.toLowerCase();

            // Get all competitor cards
            const competitors = document.querySelectorAll('.question-card');

            competitors.forEach(function(card) {
                // Fetch data attributes
                const cardSideCategoryId = card.getAttribute('data-side-category-id');
                const cardSideCategoryName = card.getAttribute('data-side-category-name').toLowerCase();
                const cardReadCategoryId = card.getAttribute('data-read-category-id');
                const cardReadCategoryName = card.getAttribute('data-read-category-name').toLowerCase();
                const cardAgeCategoryId = card.getAttribute('data-age-category-id');
                const cardAgeCategoryName = card.getAttribute('data-age-category-name').toLowerCase();

                // Determine matches for each category
                const matchesSideCategory = sideCategory ?
                    (cardSideCategoryId == sideCategory || cardSideCategoryName.includes(sideCategory)) :
                    true;
                const matchesReadCategory = readCategory ?
                    (cardReadCategoryId == readCategory || cardReadCategoryName.includes(readCategory)) :
                    true;
                const matchesAgeCategory = ageCategory ?
                    (cardAgeCategoryId == ageCategory || cardAgeCategoryName.includes(ageCategory)) :
                    true;

                // Show or hide the card based on matches
                if (matchesSideCategory && matchesReadCategory && matchesAgeCategory) {
                    card.style.display = 'block'; // Show the card
                } else {
                    card.style.display = 'none'; // Hide the card
                }
            });
        }

        // Add event listeners to dropdowns to filter competitors dynamically
        document.getElementById('sideCategoryFilter').addEventListener('change', filterCompetitors);
        document.getElementById('readCategoryFilter').addEventListener('change', filterCompetitors);
        document.getElementById('ageCategoryFilter').addEventListener('change', filterCompetitors);
    </script>




    <script>
        // Handle Send button click
        function sendCompetitor(competitorId) {
            alert('Competitor with ID ' + competitorId + ' sent!');
            // Here you can send the competitor data to the server via AJAX or redirect as needed
        }

        // Toggle the dropdown and the Send button's position
        function toggleDetails(headerElement) {
            const detailsElement = headerElement.nextElementSibling;
            const sendButton = detailsElement.querySelector('.send-btn');

            if (detailsElement.style.display === "none" || detailsElement.style.display === "") {
                detailsElement.style.display = "block";
                sendButton.classList.remove('d-none');
            } else {
                detailsElement.style.display = "none";
                sendButton.classList.add('d-none');
            }
        }
    </script>
<?php $__env->stopSection(); ?>


















<?php $__env->startSection('styles'); ?>
    <style>
        .question-card {
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin: 15px 0;
            border-radius: 8px;
            overflow: hidden;
        }

        .question-header {
            background-color: #f4f4f4;
            padding: 10px;
            font-size: 1.2em;
            font-weight: bold;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
        }

        .question-header .arrow {
            cursor: pointer;
        }

        .question-details {
            padding: 15px;
            background-color: #fafafa;
        }

        .question-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .btn {
            font-size: 1em;
            padding: 8px 20px;
            border-radius: 5px;
        }

        .send-btn {
            font-size: 1.2em;
            padding: 10px 25px;
            border-radius: 6px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }

        .send-btn:hover {
            background-color: #45a049;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .send-btn.d-none.d-md-block {
                display: none;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/quran-a/resources/views/client/host/announce.blade.php ENDPATH**/ ?>