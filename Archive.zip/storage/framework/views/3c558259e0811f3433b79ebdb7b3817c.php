<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Competition Page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }

        .main-title {
            background-color: #00bfa5;
            color: white;
            text-align: center;
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 20px;
        }


        .details-container {
            background-color: white;
            border: 2px solid #00bfa5;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 80%;
            /* Set a specific width to make it narrower */
            margin-left: auto;
            margin-right: auto;
        }

        .details-container h3 {
            color: #00bfa5;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
        }

        .details {
            font-size: 16px;
            line-height: 1.8;
            display: grid;
            grid-template-columns: 1fr 1fr;
            /* Make columns equally spaced */
            gap: 10px;

        }

        .details p {
            margin: 0;
        }

        .details p:last-child {
            text-align: right;
            /* Aligns the content of the last child (strong tag) to the right */
        }

        .details p strong {
            display: block;
            text-align: right;
            /* Aligns the strong content to the right */
            color: #00bfa5;
        }

        .action-buttons {
            display: flex;
            justify-content: space-around;
            margin-top: 20px;
        }

        .action-button {
            border: none;
            border-radius: 15px;
            padding: 10px 20px;
            font-size: 16px;
            color: white;
            cursor: pointer;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .announce-button {
            background-color: #00bfa5;
        }

        .recheck-button {
            background-color: #ff9800;
        }

        .footer {
            background-color: white;
            text-align: center;
            padding: 10px 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
            width: 100%;
            border-radius: 0;
            background-color: #00bfa5;
        }

        .footer-logo {
            width: 30px;
            height: 30px;
            margin-right: 10px;
        }

        .footer-text {
            color: #fff;
            font-size: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>

<body>

    <div class="container">
        <!-- Main Title -->
        <div class="main-title">
            <h2>Competition Main Title</h2>
            <h2>Competition Main Title</h2>
        </div>

        <!-- Competition Details -->
        <div class="details-container">
            <h3>Competition Details</h3>

            <div id="competitors-list">
                <p>Loading winners...</p>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function () {
            const fetchWinners = () => {
                $.ajax({
                    url: '<?php echo e(route('winning.fetch-winners')); ?>', // Fetch data from this route
                    method: 'GET',
                    success: function (competitors) {
                        const container = $('#competitors-list');
                        container.empty(); // Clear existing content

                        if (competitors.length === 0) {
                            container.html('<p>No winners announced yet.</p>');
                            return;
                        }

                        competitors.forEach(competitor => {
                            const rankSuffix = competitor._rank == 1 ? 'st' : (competitor._rank == 2 ? 'nd' : (competitor._rank == 3 ? 'rd' : 'th'));

                            const competitorHtml = `
                                <div class="details">
                                    <p>Place:</p>
                                    <p><strong>${competitor._rank}${rankSuffix}</strong></p>

                                    <p>Name:</p>
                                    <p><strong>${competitor.full_name}</strong></p>

                                    <p>ID Card Number:</p>
                                    <p><strong>${competitor.id_card_number}</strong></p>

                                    <p>Competition Name:</p>
                                    <p><strong>${competitor.competition?.name || 'N/A'}</strong></p>

                                    <p>Age Category:</p>
                                    <p><strong>${competitor.ageCategory?.name || 'N/A'}</strong></p>

                                    <p>Reading Side:</p>
                                    <p><strong>${competitor.readCategory?.name || 'N/A'}</strong></p>

                                    <p>Reading Type:</p>
                                    <p><strong>${competitor.sideCategory?.name || 'N/A'}</strong></p>

                                    ${competitor.results.map(result => `
                                        <p>Point Category Name:</p>
                                        <p><strong>${result.pointCategory?.name || 'N/A'}: ${result.total_points}/${result.gained_points}</strong></p>
                                    `).join('')}

                                    <p>Total # of Points:</p>
                                    <p><strong>${competitor.results.reduce((sum, r) => sum + r.total_points, 0)}/${competitor.results.reduce((sum, r) => sum + r.gained_points, 0)}</strong></p>
                                </div>

                                <div class="action-buttons">
                                    <form action="<?php echo e(route('competitor.announce', '')); ?>/${competitor.id}" method="POST" style="display:inline-block; cursor:pointer">
                                        <?php echo csrf_field(); ?>
                                        <button class="action-button announce-button" type="submit">Announce</button>
                                    </form>

                                    <form action="<?php echo e(route('competitor.recheck', '')); ?>/${competitor.id}" method="POST" style="display:inline-block; cursor:pointer">
                                        <?php echo csrf_field(); ?>
                                        <button class="action-button recheck-button" type="submit">ReCheck</button>
                                    </form>
                                </div>
                            `;

                            container.append(competitorHtml);
                        });
                    },
                    error: function (xhr, status, error) {
                        console.error('Error fetching winners:', error);
                        $('#competitors-list').html('<p>Error loading winners. Please try again later.</p>');
                    }
                });
            };

            // Fetch winners initially and every 5 seconds
            fetchWinners();
            setInterval(fetchWinners, 500);
        });
    </script>

    <!-- Footer -->
    <div class="footer">
        <div class="footer-text">
            <img src="https://img.icons8.com/ios-filled/50/00bfa5/n.png" alt="Logo" class="footer-logo">
            Powered by Magey HR Copyright 2024 © NEN Development
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/quran-a/resources/views/winning-announcement/index.blade.php ENDPATH**/ ?>