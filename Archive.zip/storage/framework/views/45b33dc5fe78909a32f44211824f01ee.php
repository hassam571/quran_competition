<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - Magey Competition</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="css/login.css">
</head>
<style>
    /* Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  /* Body Styling */
  body {
    font-family: 'Arial', sans-serif;
    background-color: #f9f9f9;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    padding: 10px; /* For proper spacing on smaller devices */
  }

  /* Container */
  .container {
    width: 100%;
    max-width: 400px; /* Responsive max width */
    text-align: center;
    padding: 20px;
  }

  /* Logo */
  .logo img {
    width: 80px;
    height: 80px;
    margin-bottom: 20px;
  }

  @media (min-width: 768px) {
    .logo img {
      width: 100px;
      height: 100px;
    }
  }

  /* Welcome Text */
  .welcome-text {
    font-size: 18px;
    color: #00bfa6;
    margin-bottom: 30px;
    line-height: 1.5;
  }

  @media (min-width: 768px) {
    .welcome-text {
      font-size: 22px;
    }
  }

  /* Login Form */
  .login-form {
    display: flex;
    flex-direction: column;
    gap: 15px;
  }

  .login-form input {
    width: 100%;
    padding: 12px;
    font-size: 14px;
    border: 1px solid #ddd;
    border-radius: 10px;
    outline: none;
  }

  @media (min-width: 768px) {
    .login-form input {
      font-size: 16px;
      padding: 15px;
    }
  }

  .login-form .btn {
    background-color: #00bfa6;
    color: white;
    padding: 12px;
    font-size: 16px;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    transition: background-color 0.3s;
  }

  .login-form .btn:hover {
    background-color: #008f79;
  }

  @media (min-width: 768px) {
    .login-form .btn {
      padding: 15px;
      font-size: 18px;
    }
  }

 /* Footer */
.footer {
    margin-top: 30px;
    text-align: center;
    border: 2px solid #00bfa6; /* Add border */
    border-radius: 10px; /* Add rounded corners */
    padding: 15px; /* Add padding inside the footer */
    background-color: #ffffff; /* White background for contrast */
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Optional shadow for better look */
  }

  .footer-content {
    font-size: 14px;
    color: #00bfa6;
  }

  @media (min-width: 768px) {
    .footer-content {
      font-size: 16px;
    }
  }



</style>
<body>
  <div class="container">
    <!-- Logo -->
    <div class="logo">
      <img src="https://via.placeholder.com/100x100?text=Logo" alt="Magey Competition Logo">
    </div>

    <!-- Welcome Text -->
    <h1 class="welcome-text">Welcome to,<br>Magey Competition</h1>

    <!-- Login Form -->
    <form class="login-form" method="POST" action="<?php echo e(route('winning.login.submit')); ?>">
        <?php echo csrf_field(); ?>
        <input type="text" name="host_id" placeholder="Enter Host ID" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" class="btn">Login</button>
    </form>

    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>


    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
          <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
    <?php endif; ?>
  </div>

  <!-- Footer -->
  <footer class="footer">
    <div class="footer-content">
      <p>Powered by Magey HR</p>
      <p>&copy; 2024 e NEN Development</p>
    </div>
  </footer>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/quran-a/resources/views/winning-announcement/login.blade.php ENDPATH**/ ?>