<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome to Magey Competition</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="resources/css/welcome.css">
</head>
<style>
    /* Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  /* Body Styling */
  body {
    font-family: 'Arial', sans-serif;
    background-color: #f9f9f9;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
  }

  /* Container */
  .container {
    max-width: 300px; /* Increased width for larger content area */
    width: 100%;
    text-align: center;
  }

  /* Header Styling */
  .header {
    background-color: #00bfa6;
    color: white;
    border-radius: 20px;
    margin-bottom: 30px; /* More space below the header */
  }

  .header h1 {
    font-size: 24px; /* Increased font size */
    line-height: 1.6;
  }

  /* Button Group */
  .button-group {
    display: flex;
    flex-direction: column;
    gap: 15px; /* Increased gap between buttons */
  }

  .btn {
    font-size: 18px; /* Increased font size */
    color: #00bfa6;
    background-color: white;
    border: 2px solid #00bfa6;
    padding: 15px; /* Increased padding */
    border-radius: 30px; /* Keep the rounded edges */
    cursor: pointer;
    transition: all 0.3s;
  }


  .btn:hover {
    background-color: #00bfa6;
    color: white;
  }

/* Footer Styling */
.footer {
    width: 100%;
    text-align: center;
    font-size: 14px;
    background-color: #00bfa6; /* Matching header color for consistency */
    color: white;
    padding: 15px 10px; /* Adequate padding for spacing */
    margin-top: 30px; /* Ensures footer stays at the bottom */
    box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.1);
    border-radius: 0 0 10px 10px; /* Match container’s border style */
  }




</style>
<body>
  <div class="container">
    <!-- Header -->
    <header class="header">
      <h1>Welcome to,<br>Magey Competition</h1>
    </header>

    <!-- Button Group -->
    <div class="button-group">

      <button class="btn active" onclick="window.location.href='<?php echo e(route('client.login')); ?>'">Client Panel</button>
      <button class="btn"  onclick="window.location.href='<?php echo e(route('calling.login')); ?>'">Calling Screen</button>

      <button class="btn"  onclick="window.location.href='<?php echo e(route('announcement.login')); ?>'">Announcement Screen</button>
      <button class="btn" onclick="window.location.href='<?php echo e(route('number.login')); ?>'">Number Screen</button>
      <button class="btn" onclick="window.location.href='<?php echo e(route('judges.login')); ?>'">Judge Panel</button>
      <button class="btn" onclick="window.location.href='<?php echo e(route('showquestion.login')); ?>'">Competitor Screen for Host</button>
      <button class="btn" onclick="window.location.href='<?php echo e(route('showquestion.user.login')); ?>'">Competitor Screen for Competitor</button>
      <button class="btn" onclick="window.location.href='<?php echo e(route('winning.login')); ?>'" >Winner Announce Confirmation</button>
    </div>
  </div>

  <!-- Footer -->
  <footer class="footer">
    <div class="footer-content">
      <p>Powered by Magey HR</p>
      <p>&copy; 2024 e NEN Development</p>
    </div>
  </footer>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/quran-a/resources/views/welcome.blade.php ENDPATH**/ ?>