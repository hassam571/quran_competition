<!DOCTYPE html>
<html lang="en">

<head>

    <title>Create Questions</title>
<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('styles'); ?>

</head>

<body>



            <!-- Success Message -->
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-custom animate__animated animate__fadeInDown" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <!-- Error Message -->
            <?php if(session('error')): ?>
                <div class="alert alert-danger alert-custom animate__animated animate__fadeInDown" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

   <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('scripts'); ?>

</body>

</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/quran-a/resources/views/layouts/app.blade.php ENDPATH**/ ?>