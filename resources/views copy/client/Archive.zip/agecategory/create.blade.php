@extends('layouts.app')

@section('content')
<style>
    * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  /* Body Styling */
  body {
    font-family: 'Arial', sans-serif;
    background-color: #f9f9f9;
    min-height: 100vh;
    padding: 10px;
    text-align: center;
  }

  /* Container */
  .container {
    width: 100%;
    max-width: 400px;
    margin: 0 auto; /* Center the container */
  }

  /* Header Styling */
  .header {
    display: flex;
    align-items: center;
    background-color: #00bfa6;
    color: white;
    padding: 15px 20px;
    border-radius: 10px;
    margin-bottom: 20px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  }

  .header h1 {
    flex-grow: 1;
    font-size: 18px;
    text-align: center;
  }

  .back-btn {
    background: none;
    border: none;
    color: white;
    font-size: 18px;
    cursor: pointer;
  }

  /* Tabs Styling */
  .tabs {
    display: flex;
    justify-content: space-around;
    margin-bottom: 20px;
  }

  .tab-btn {
    font-size: 14px;
    padding: 10px 15px;
    border-radius: 20px;
    border: 2px solid #00bfa6;
    background-color: white;
    color: #00bfa6;
    cursor: pointer;
    transition: all 0.3s ease-in-out;
  }

  .tab-btn.active {
    background-color: #00bfa6;
    color: white;
  }

  .tab-btn:hover {
    background-color: #008f79;
    color: white;
  }

  /* Form Container */
  .form-container {
    background-color: white;
    border-radius: 10px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    padding: 20px;
    margin-bottom: 30px;
  }

  .age-category-form {
    display: flex;
    flex-direction: column;
    gap: 15px;
  }

  .age-category-form input {
    width: 100%; /* Make input full width */
    padding: 12px;
    font-size: 14px;
    border: 1px solid #ddd;
    border-radius: 10px;
    outline: none;
    transition: border-color 0.3s ease-in-out;
  }

  .age-category-form input:focus {
    border-color: #00bfa6; /* Highlight input on focus */
  }

  .age-category-form .save-btn {
    background-color: #00bfa6;
    color: white;
    padding: 12px;
    font-size: 16px;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
  }

  .age-category-form .save-btn:hover {
    background-color: #008f79;
  }

  /* Footer Styling */
  .footer {
    text-align: center; /* Center-align text */
    border: 2px solid #00bfa6;
    border-radius: 10px;
    padding: 15px 10px;
    background-color: white;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    margin-top: 30px;
    width: 90%; /* Stretch the footer width */
    max-width: 400px; /* Limit footer width */
    margin-left: auto; /* Center horizontally */
    margin-right: auto; /* Center horizontally */
  }

  .footer-content {
    font-size: 14px;
    color: #00bfa6;
    line-height: 1.8; /* Add line spacing */
  }

  /* Responsive Design */
  @media (min-width: 768px) {
    .header h1 {
      font-size: 20px;
    }

    .tab-btn {
      font-size: 16px;
      padding: 12px 20px;
    }

    .age-category-form input {
      font-size: 16px;
      padding: 15px;
    }

    .age-category-form .save-btn {
      font-size: 18px;
      padding: 15px;
    }

    .footer-content {
      font-size: 16px;
    }
  }
  
</style>
  <div class="container">
    <!-- Header -->
    <header class="header">
      <button class="back-btn"><i class="fas fa-arrow-left"></i></button>
      <h1>Create Age Category</h1>
    </header>

    <!-- Tabs -->
    <div class="tabs">
      <button class="tab-btn active">Create Age Category</button>
      <button class="tab-btn" onclick="window.location.href='{{ route('agecategory.index') }}'">Age Category List</button>

    </div>

    <!-- Form Section -->
    <div class="form-container">
        <header>
            <h1>Create Age Category</h1>
          </header>

          @if (session('success'))
            <div>{{ session('success') }}</div>
          @endif

          <form method="POST" action="{{ route('agecategory.store') }}">
            @csrf
            <label for="name">Age Category</label>
            <input type="text" id="name" name="name" placeholder="Age Category" required>
            <button type="submit" class="btn save-btn">Save</button>
          </form>
    </div>
  </div>

  @endsection
