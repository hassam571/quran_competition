@extends('layouts.app')

@section('content')
  <div class="container">
    <!-- Header -->
    <header class="header">
      <button class="back-btn" onclick="window.history.back()"><i class="fas fa-arrow-left"></i></button>
      <h1>Edit Age Category</h1>
    </header>

    <!-- Tabs -->
    <div class="tabs">
      <button class="tab-btn" onclick="window.location.href='{{ route('agecategory.create') }}'">Create Age Category</button>
      <button class="tab-btn active">Edit Age Category</button>
    </div>

    <!-- Form Section -->
    <div class="form-container">
      @if (session('success'))
        <div>{{ session('success') }}</div>
      @endif

      <form method="POST" action="{{ route('agecategory.update') }}">
        @csrf
        <label for="name">Age Category</label>
        <input type="text" id="name" name="name" value="{{ $ageCategory->name }}" placeholder="Age Category" required>
        <button type="submit" class="btn save-btn">Save</button>
      </form>
    </div>
  </div>


  @endsection
