@extends('layouts.app')

@section('content')
  <div class="container">
    <!-- Header -->
    <header class="header">
      <button class="back-btn" onclick="window.history.back()"><i class="fas fa-arrow-left"></i></button>
      <h1>Age Category List</h1>
    </header>

    <!-- Tabs -->
    <div class="tabs">
      <button class="tab-btn" onclick="window.location.href='{{ route('agecategory.create') }}'">Create Age Category</button>
      <button class="tab-btn active">Age Category List</button>
    </div>

    <!-- Age Category List -->
    <div class="list-container">
      <h2 class="list-title">Age Category List</h2>
      @foreach ($ageCategories as $ageCategory)
        <div class="category-card">
          <div class="card-header">
            <p>Age Category: <span>{{ $ageCategory->name }}</span></p>
          </div>
          <div class="card-actions">
            <form action="{{ route('agecategory.setSession') }}" method="POST" style="display:inline-block;">
                @csrf
                <input type="hidden" name="age_category_id" value="{{ $ageCategory->id }}">
                <button type="submit" class="btn edit-btn">Edit</button>
              </form>
              <form action="{{ route('agecategory.delete') }}" method="POST" style="display:inline-block;">
                @csrf
                <input type="hidden" name="age_category_id" value="{{ $ageCategory->id }}">
                <button type="submit" class="btn delete-btn">Delete</button>
              </form>
          </div>
        </div>
      @endforeach

      @if ($ageCategories->isEmpty())
        <p>No age categories found. Click "Create Age Category" to add one.</p>
      @endif
    </div>
  </div>


  @endsection
