@extends('layouts.app')

@section('content')
  <div class="container">
    <!-- Header -->
    <header class="header">
      <button class="back-btn" onclick="window.history.back()"><i class="fas fa-arrow-left"></i></button>
      <h1>Competition List</h1>
    </header>

    <!-- Button Group -->
    <div class="button-group">
      <a href="{{ route('competition.create') }}" class="btn create-btn">Create Competition</a>
      <button class="btn active-btn">Competition List</button>
    </div>

    <!-- Competition List -->
    <div class="competition-list">
      <h2 class="list-heading">Competitions List</h2>

      <!-- Main Container for all Competitions -->
      <div class="competitions-container">
        @foreach($competitions as $competition)
          <div class="competition-card">
            <!-- Sub-container for Main Name -->
            <div class="competition-main-name">
              <p>Competition Main Name: <span>{{ $competition->main_name }}</span> <i class="fas fa-chevron-down"></i></p>
            </div>
            <!-- Sub-container for Sub Name -->
            <div class="competition-sub-name">
              <p>Competition Sub Name: <span>{{ $competition->sub_name }}</span></p>
            </div>
            <!-- Buttons -->
            <div class="card-buttons">
              <form action="{{ route('competition.delete', $competition->id) }}" method="POST" style="display:inline-block;">
                @csrf
                <button type="submit" class="btn delete-btn">Delete</button>
              </form>
              <form action="{{ route('competition.setSession') }}" method="POST" style="display:inline-block;">
                @csrf
                <input type="hidden" name="competition_id" value="{{ $competition->id }}">
                <button type="submit" class="btn edit-btn">Edit</button>
              </form>
            </div>
          </div>
        @endforeach

        @if($competitions->isEmpty())
          <p>No competitions found. Click "Create Competition" to add one.</p>
        @endif
      </div>
    </div>
  </div>


  @endsection
