@extends('layouts.app')

@section('content')
  <div class="container">
    <!-- Header -->
    <header class="header">
      <button class="back-btn"><i class="fas fa-arrow-left"></i></button>
      <h1>Create Competition</h1>
    </header>

    <!-- Tabs -->
    <div class="tabs">
      <button class="tab-btn active">Create Competition</button>
      <button class="tab-btn" onclick="window.location.href='{{ route('competition.list') }}'">Competition List</button>

    </div>

    <!-- Form Section -->
    <div class="form-container">
        <form class="competition-form" method="POST" action="{{ route('competition.store') }}">
            @csrf
            <input type="text" name="main_name" placeholder="Competition Main Name" required>
            <input type="text" name="sub_name" placeholder="Competition Sub Name" required>
            <button type="submit" class="btn save-btn">Save</button>
        </form>

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

    </div>
  </div>


  @endsection

