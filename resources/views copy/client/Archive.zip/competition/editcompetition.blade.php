@extends('layouts.app')

@section('content')
  <div class="container">
    <!-- Header -->
    <header class="header">
      <button class="back-btn" onclick="window.history.back()"><i class="fas fa-arrow-left"></i></button>
      <h1>Edit Side Category</h1>
    </header>

    <!-- Form Section -->
    <div class="form-container">
      @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
      @endif

      <form method="POST" action="{{ route('sidecategory.update') }}">
        @csrf
        <h2 class="form-title">Edit Side Category</h2>

        <label for="name">Category Name</label>
        <input type="text" name="name" id="name" value="{{ $sideCategory->name }}" required>

        <div class="btn-container">
          <button type="submit" class="save-btn">Save</button>
          <a href="{{ route('sidecategory.list') }}" class="cancel-btn">Cancel</a>
        </div>
      </form>
    </div>
  </div>


  @endsection

