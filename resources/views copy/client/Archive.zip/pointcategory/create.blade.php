@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="header">
            <button class="back-button">←</button>
            <h1>Create Point Category</h1>
        </div>
        <div class="button-group">
            <button class="active-button">Create Point Category</button>
            <button class="inactive-button" onclick="window.location.href='{{ route('pointcategory.list') }}'">Point Category List</button>

        </div>
        <div class="form-container">
            <form method="POST" action="{{ route('pointcategory.store') }}">
                @csrf
                <input type="text" name="name" placeholder="Point Category Name" required>
                <input type="number" name="total_points" placeholder="Total Points" required>
                <input type="number" step="0.01" name="deduction_amount" placeholder="Deduction Amount Per Click" required>
                <button type="submit" class="btn save-btn">Save</button>
            </form>
        </div>
    </div>
    <footer class="footer" style="position: fixed; bottom: 0; left: 50%; transform: translateX(-50%);">
        <div class="footer-content">
            <img src="nen_logo.png" alt="Logo" class="footer-logo">
            <p>Powered by Magey HR</p>
            <p>Copyright 2024 © NEN Development</p>
        </div>

        @endsection
