@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="header">
            <button class="back-button" onclick="window.history.back()">←</button>
            <h1>Edit Point Category</h1>
        </div>
        <div class="button-group">
            <button class="inactive-button" onclick="window.location.href='{{ route('pointcategory.create') }}'">Create Point Category</button>
            <button class="active-button">Edit Point Category</button>
        </div>
        <div class="form-container">
            @if (session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif
            <form method="POST" action="{{ route('pointcategory.update') }}">
                @csrf
                <div>
                    <label for="name">Point Category Name</label>
                    <input type="text" id="name" name="name" value="{{ $pointCategory->name }}" required>
                </div>
                <div>
                    <label for="total_points">Total Points</label>
                    <input type="number" id="total_points" name="total_points" value="{{ $pointCategory->total_points }}" required>
                </div>
                <div>
                    <label for="deduction_amount">Deduction Amount</label>
                    <input type="number" step="0.01" id="deduction_amount" name="deduction_amount" value="{{ $pointCategory->deduction_amount }}" required>
                </div>
                <button type="submit">Update</button>
            </form>

        </div>
    </div>
    <footer class="footer" style="position: fixed; bottom: 0; left: 50%; transform: translateX(-50%);">
        <div class="footer-content">
            <img src="nen_logo.png" alt="Logo" class="footer-logo">
            <p>Powered by Magey HR</p>
            <p>Copyright 2024 © NEN Development</p>
        </div>
    </footer>

    @endsection
