@extends('layouts.app')

@section('content')
    <div class="container">
        <header class="header">
            <button class="back-btn" onclick="window.history.back()">←</button>
            <h1>Point Category List</h1>
        </header>
        <div class="button-group">
            <button class="inactive-button" onclick="window.location.href='{{ route('pointcategory.create') }}'">Create Point Category</button>
            <button class="active-button">Point Category List</button>
        </div>
        <div class="list-container">
            @if(session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif
            @foreach($pointCategories as $pointCategory)
                <div class="list-item" onclick="this.classList.toggle('active')">
                    <p><strong>Point Category Name:</strong> {{ $pointCategory->name }}</p>
                    <span class="arrow">&#x25BC;</span>
                    <div class="details">
                        <p><strong>Total Number of Points:</strong> {{ $pointCategory->total_points }}</p>
                        <p><strong>Deduction Amount per Click:</strong> {{ $pointCategory->deduction_amount }}</p>
                        <div class="button-group-inline">
                            <form action="{{ route('pointcategory.setSession') }}" method="POST">
                                @csrf
                                <input type="hidden" name="point_category_id" value="{{ $pointCategory->id }}">
                                <button type="submit" class="btn-edit">Edit</button>
                            </form>
                            <form action="{{ route('pointcategory.delete') }}" method="POST">
                                @csrf
                                <input type="hidden" name="point_category_id" value="{{ $pointCategory->id }}">
                                <button type="submit" class="btn-delete">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            @endforeach
            @if($pointCategories->isEmpty())
                <p>No point categories found. Click "Create Point Category" to add one.</p>
            @endif
        </div>
    </div>

    @endsection
