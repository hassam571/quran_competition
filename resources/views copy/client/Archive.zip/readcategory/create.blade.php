@extends('layouts.app')

@section('content')
  <div class="container">
    <!-- Header -->
    <header class="header">
      <button class="back-btn" onclick="window.history.back()"><i class="fas fa-arrow-left"></i></button>
      <h1>Create Read Category</h1>
    </header>

    <!-- Tabs -->
    <div class="tabs">
      <button class="tab-btn active">Create Read Category</button>
      <a href="{{ route('readcategory.list') }}" class="tab-btn">Read Category List</a>
    </div>

    <!-- Form Section -->
    <div class="form-container">
      @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
      @endif

      <form class="read-category-form" method="POST" action="{{ route('readcategory.store') }}">
        @csrf
        <input type="text" name="name" placeholder="Read Category Name" required>
        <button type="submit" class="btn save-btn">Save</button>
      </form>
    </div>
  </div>


  @endsection
