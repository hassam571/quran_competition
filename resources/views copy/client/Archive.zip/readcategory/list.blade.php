@extends('layouts.app')

@section('content')
  <div class="container">
    <!-- Header -->
    <header class="header">
      <button class="back-btn" onclick="window.history.back()"><i class="fas fa-arrow-left"></i></button>
      <h1>Read Category List</h1>
    </header>

    <!-- Tabs -->
    <div class="tabs">
      <a href="{{ route('readcategory.create') }}" class="tab-btn">Create Read Category</a>
      <button class="tab-btn active">Read Category List</button>
    </div>

    <!-- Read Category List -->
    <div class="list-container">
      @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
      @endif

      <h2 class="list-title">Read Category List</h2>
      @foreach($readCategories as $readCategory)
        <div class="category-card">
          <div class="card-header">
            <p>Read Category: <span>{{ $readCategory->name }}</span></p>
          </div>
          <div class="card-actions">
            <form action="{{ route('readcategory.setSession') }}" method="POST" style="display:inline-block;">
              @csrf
              <input type="hidden" name="read_category_id" value="{{ $readCategory->id }}">
              <button type="submit" class="btn edit-btn">Edit</button>
            </form>
            <form action="{{ route('readcategory.delete') }}" method="POST" style="display:inline-block;">
              @csrf
              <input type="hidden" name="read_category_id" value="{{ $readCategory->id }}">
              <button type="submit" class="btn delete-btn">Delete</button>
            </form>
          </div>
        </div>
      @endforeach

      @if($readCategories->isEmpty())
        <p>No read categories found. Click "Create Read Category" to add one.</p>
      @endif
    </div>
  </div>


  @endsection
