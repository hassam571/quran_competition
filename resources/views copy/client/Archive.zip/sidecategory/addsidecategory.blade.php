@extends('layouts.app')

@section('content')
    <div class="container">
        <!-- Header -->
        <header class="header">
            <button class="back-btn" onclick="window.history.back()"><i class="fas fa-arrow-left"></i></button>
            <h1>Create Side Category</h1>
        </header>

        <!-- Tabs -->
        <div class="tabs">
            <button class="tab-btn active">Create Side Category</button>
            <button class="tab-btn active" onclick="window.location.href='{{ route('sidecategory.list') }}'">Side
                Category List</button>

        </div>

        <!-- Form Section -->
        <div class="form-container">
            @if (session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif

            <form class="side-category-form" method="POST" action="{{ route('sidecategory.store') }}">
                @csrf
                <input type="text" name="name" placeholder="Side Category Name" required>
                <button type="submit" class="btn save-btn">Save</button>
            </form>
        </div>
    </div>


    @endsection
