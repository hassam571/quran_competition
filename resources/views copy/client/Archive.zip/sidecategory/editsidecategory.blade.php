@extends('layouts.app')

@section('content')
  <div class="container">
    <h1>Edit Side Category</h1>
    <form method="POST" action="{{ route('sidecategory.update') }}">
      @csrf
      <label for="name">Category Name</label>
      <input type="text" name="name" id="name" value="{{ $sideCategory->name }}" required>
      <button type="submit">Update</button>
    </form>
  </div>

  @endsection
