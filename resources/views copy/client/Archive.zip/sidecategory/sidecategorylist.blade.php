@extends('layouts.app')

@section('content')
  <div class="container">
    <!-- Header -->
    <header class="header">
      <button class="back-btn" onclick="window.history.back()"><i class="fas fa-arrow-left"></i></button>
      <h1>Side Category List</h1>
    </header>

    <!-- Tabs -->
    <div class="tabs">
      <a href="{{ route('sidecategory.create') }}" class="tab-btn">Create Side Category</a>
      <button class="tab-btn active" onclick="window.location.href='{{ route('sidecategory.list') }}'">Side Category List</button>

    </div>

    <!-- Side Category List -->
    <div class="list-container">
      @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
      @endif

      <h2 class="list-title">Side Category List</h2>
      @foreach($sideCategories as $sideCategory)
        <div class="category-card">
          <div class="card-header">
            <p>Side Category: <span>{{ $sideCategory->name }}</span></p>
          </div>
          <div class="card-actions">
            <form action="{{ route('sidecategory.setSession') }}" method="POST" style="display:inline-block;">
              @csrf
              <input type="hidden" name="side_category_id" value="{{ $sideCategory->id }}">
              <button type="submit" class="btn edit-btn">Edit</button>
            </form>
            <form action="{{ route('sidecategory.delete') }}" method="POST" style="display:inline-block;">
              @csrf
              <input type="hidden" name="side_category_id" value="{{ $sideCategory->id }}">
              <button type="submit" class="btn delete-btn">Delete</button>
            </form>
          </div>
        </div>
      @endforeach

      @if($sideCategories->isEmpty())
        <p>No side categories found. Click "Create Side Category" to add one.</p>
      @endif
    </div>
  </div>

  @endsection
